<?php
/**
 * Обязательный ввод телефона — страница БЕЗ header/theme,
 * чтобы никакой стиль не спрятал поле.
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$__user = require_login();

// уже есть телефон
try {
  if (!empty($__user['phone'])) {
    redirect('/dashboard.php');
  }
  // перечитать из БД
  $st = db()->prepare('SELECT phone FROM users WHERE id = ?');
  $st->execute([(int)$__user['id']]);
  $ph = $st->fetchColumn();
  if ($ph) {
    redirect('/dashboard.php');
  }
} catch (Throwable $e) {}

$error = '';
$phoneVal = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  if (function_exists('csrf_verify')) {
    try { csrf_verify(); } catch (Throwable $e) {}
  }
  $phoneVal = trim((string)($_POST['phone'] ?? ''));
  $phone = null;
  if ($phoneVal !== '') {
    $phone = function_exists('normalize_phone') ? normalize_phone($phoneVal) : preg_replace('/[^\d+]/', '', $phoneVal);
  }
  if (!$phone || strlen(preg_replace('/\D/', '', (string)$phone)) < 10) {
    $error = 'Введите номер, например +79991234567';
  } else {
    try {
      try { db()->exec("ALTER TABLE users ADD COLUMN phone VARCHAR(32) NULL"); } catch (Throwable $e) {}
      $chk = db()->prepare('SELECT id FROM users WHERE phone = ? AND id != ? LIMIT 1');
      $chk->execute([$phone, (int)$__user['id']]);
      if ($chk->fetch()) {
        $error = 'Этот номер уже занят другим аккаунтом';
      } else {
        db()->prepare('UPDATE users SET phone = ? WHERE id = ?')->execute([$phone, (int)$__user['id']]);
        if (function_exists('flash_set')) {
          flash_set('success', 'Номер сохранён');
        }
        $next = '/dashboard.php';
        if (!empty($_GET['next']) && is_string($_GET['next']) && str_starts_with($_GET['next'], '/')) {
          $next = $_GET['next'];
        }
        redirect($next);
      }
    } catch (Throwable $e) {
      $error = 'Не удалось сохранить: ' . $e->getMessage();
    }
  }
}

$csrf = function_exists('csrf_field') ? csrf_field() : '';
$esc = static function ($s) {
  return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
};
?><!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title>Укажите номер телефона</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
      background: #0b0b10;
      color: #f3f4f6;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      width: 100%;
      max-width: 420px;
      background: #16161c;
      border: 1px solid rgba(255,255,255,.12);
      border-radius: 16px;
      padding: 28px 22px;
    }
    h1 { margin: 0 0 10px; font-size: 1.35rem; }
    p { margin: 0 0 18px; color: #9ca3af; font-size: 14px; line-height: 1.5; }
    label { display: block; margin: 0 0 8px; font-size: 13px; font-weight: 600; color: #d1d5db; }
    input[type="tel"] {
      display: block !important;
      width: 100% !important;
      height: 52px !important;
      min-height: 52px !important;
      padding: 14px 16px !important;
      font-size: 18px !important;
      line-height: 1.2 !important;
      border-radius: 12px !important;
      border: 2px solid #818cf8 !important;
      background: #ffffff !important;
      color: #111827 !important;
      -webkit-text-fill-color: #111827 !important;
      caret-color: #111 !important;
      opacity: 1 !important;
      visibility: visible !important;
      outline: none;
    }
    input[type="tel"]::placeholder {
      color: #9ca3af !important;
      -webkit-text-fill-color: #9ca3af !important;
    }
    button[type="submit"] {
      display: block;
      width: 100%;
      margin-top: 16px;
      height: 50px;
      border: 0;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      color: #fff;
      background: linear-gradient(90deg, #6366f1, #a855f7);
    }
    .err {
      background: rgba(239,68,68,.15);
      border: 1px solid rgba(239,68,68,.45);
      color: #fecaca;
      padding: 12px;
      border-radius: 10px;
      margin-bottom: 14px;
      font-size: 13px;
    }
    .links { margin-top: 16px; text-align: center; font-size: 13px; }
    .links a { color: #93c5fd; }
  </style>
</head>
<body>
  <div class="card">
    <h1>📱 Укажите номер телефона</h1>
    <p>Нужен для восстановления доступа. SMS не отправляем — только проверка формата.</p>
    <?php if ($error !== ''): ?>
      <div class="err"><?= $esc($error) ?></div>
    <?php endif; ?>
    <form method="post" action="/auth/add_phone.php" autocomplete="on">
      <?= $csrf ?>
      <label for="phone">Номер телефона</label>
      <input
        id="phone"
        type="tel"
        name="phone"
        required
        autofocus
        inputmode="tel"
        autocomplete="tel"
        placeholder="+79991234567"
        value="<?= $esc($phoneVal) ?>"
      >
      <button type="submit">Сохранить и продолжить</button>
    </form>
    <div class="links">
      <a href="/auth/logout.php">Выйти</a>
      ·
      <a href="/catalog.php">На главную</a>
    </div>
  </div>
</body>
</html>
