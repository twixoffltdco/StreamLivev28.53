<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/mailer.php';
require_once dirname(__DIR__) . '/includes/magic_link.php';

if (current_user()) redirect('/');

$error = '';
$sent = false;
$debugFrom = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim((string)($_POST['email'] ?? ''));
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Укажите корректный email';
  } else {
    $uid = null;
    try {
      $st = db()->prepare('SELECT id FROM users WHERE email=? OR LOWER(email)=LOWER(?) LIMIT 1');
      $st->execute([$email, $email]);
      $uid = (int)($st->fetchColumn() ?: 0) ?: null;
    } catch (Throwable $e) {}
    if ($uid) {
      $token = magic_link_create($uid, $email);
      if ($token) {
        $url = site_base_url() . '/auth/magic_confirm.php?token=' . urlencode($token);
        $html = mailer_template(
          'Вход в StreamLive',
          'Вы запросили вход без пароля. Нажмите кнопку — попадёте в аккаунт. Ссылка действует 30 минут.',
          'Войти в аккаунт',
          $url
        );
        $ok = mailer_send($email, 'Вход в StreamLive — ссылка', $html);
        if (!$ok) {
          $error = 'Не удалось отправить письмо. Проверьте mail_from на хостинге (ящик на вашем домене).';
        }
      }
    }
    if ($error === '') $sent = true;
    try { $debugFrom = mailer_from()[0] ?? ''; } catch (Throwable $e) {}
  }
}
$pageTitle = 'Вход по почте';
require_once dirname(__DIR__) . '/includes/header.php';
[$previewFrom] = array_pad(function_exists('mailer_from') ? mailer_from() : ['',''], 1, '');
?>
<div class="container" style="max-width:420px;margin:40px auto;padding:0 16px">
  <h1 style="font-size:22px">Вход по почте</h1>
  <p style="opacity:.7;font-size:14px">Письмо уйдёт с адреса домена сайта. Если не пришло — проверьте «Спам».</p>
  <?php if ($previewFrom): ?><p style="font-size:12px;opacity:.5">From: <?= htmlspecialchars($previewFrom, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
  <?php if ($sent): ?>
    <div class="form-card" style="padding:16px;margin-top:16px">
      <p>Если аккаунт с таким email есть — письмо отправлено.</p>
      <p style="margin-top:12px"><a href="/auth/login.php">Логин + пароль + 2FA</a></p>
    </div>
  <?php else: ?>
    <?php if ($error): ?><p style="color:#f87171"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
    <form method="post" class="form-card" style="padding:16px;margin-top:12px">
      <label>Email</label>
      <input type="email" name="email" required autocomplete="email" style="width:100%">
      <button class="btn btn-primary" style="margin-top:14px;width:100%" type="submit">Получить ссылку</button>
    </form>
  <?php endif; ?>
</div>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
