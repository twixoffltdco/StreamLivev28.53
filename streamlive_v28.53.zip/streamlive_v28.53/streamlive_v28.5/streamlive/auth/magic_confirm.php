<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/magic_link.php';
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }

$token = trim((string)($_GET['token'] ?? ''));
$uid = $token !== '' ? magic_link_consume($token) : null;
if ($uid) {
  // если у пользователя 2FA — после magic link тоже спросить код
  $need2fa = false;
  try {
    $st = db()->prepare('SELECT totp_enabled, totp_secret FROM users WHERE id=?');
    $st->execute([$uid]);
    $u = $st->fetch();
    $need2fa = $u && !empty($u['totp_enabled']) && !empty($u['totp_secret']);
  } catch (Throwable $e) {}
  if ($need2fa) {
    $_SESSION['pending_2fa_user_id'] = $uid;
    $t = make_2fa_token($uid);
    redirect('/auth/2fa_verify.php?t=' . urlencode($t));
  }
  login_user($uid);
  if (function_exists('safe_after_login_redirect')) redirect(safe_after_login_redirect());
  redirect('/');
}
$pageTitle = 'Ссылка недействительна';
require_once dirname(__DIR__) . '/includes/header.php';
?>
<div class="container" style="max-width:420px;margin:40px auto;text-align:center;padding:0 16px">
  <h1>Ссылка недействительна или устарела</h1>
  <p style="opacity:.7">Запросите новую или войдите логином и 2FA.</p>
  <p style="margin-top:16px">
    <a class="btn btn-primary" href="/auth/magic_request.php">Новая ссылка</a>
    <a class="btn btn-outline" href="/auth/login.php">Логин</a>
  </p>
</div>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
