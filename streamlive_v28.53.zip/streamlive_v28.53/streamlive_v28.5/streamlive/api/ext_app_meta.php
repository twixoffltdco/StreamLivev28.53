<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . (isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '*'));
header('Access-Control-Allow-Credentials: true');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
$name = 'StreamLive';
$userOut = null;
try {
  $root = dirname(__DIR__);
  if (is_file($root . '/includes/functions.php')) require_once $root . '/includes/functions.php';
  if (is_file($root . '/includes/auth.php')) require_once $root . '/includes/auth.php';
  if (defined('SITE_NAME') && SITE_NAME) $name = (string)SITE_NAME;
  if (function_exists('current_user')) {
    $u = current_user();
    if ($u) {
      $userOut = [
        'id' => (int)($u['id'] ?? 0),
        'username' => (string)($u['username'] ?? ''),
        'avatar' => (string)($u['avatar'] ?? $u['avatar_url'] ?? ''),
      ];
    }
  }
} catch (Throwable $e) {}
echo json_encode(['ok' => true, 'name' => $name, 'script' => 'streamlive', 'user' => $userOut], JSON_UNESCAPED_UNICODE);
