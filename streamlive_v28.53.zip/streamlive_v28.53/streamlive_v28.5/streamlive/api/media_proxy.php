<?php
/**
 * Поток с нашего домена. Браузер НЕ ходит на заблокированный хост.
 */
require_once dirname(__DIR__) . '/includes/embed_proxy.php';

$url = trim((string)($_GET['u'] ?? ''));
if ($url === '' || !preg_match('#^https?://#i', $url)) {
  http_response_code(400);
  exit('bad');
}
// allow allowlist OR direct media file on any https (optional tight: only allowlist)
$okHost = embed_proxy_host_allowed($url) || preg_match('#\.(mp4|webm|m3u8)(\?|$)#i', $url);
if (!$okHost) {
  http_response_code(403);
  exit('forbidden');
}
if (!function_exists('curl_init')) {
  http_response_code(500);
  exit('curl');
}

$headers = ['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'];
if (!empty($_SERVER['HTTP_RANGE'])) {
  $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
}

$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_TIMEOUT => 90,
  CURLOPT_CONNECTTIMEOUT => 12,
  CURLOPT_HTTPHEADER => $headers,
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_HEADER => true,
  CURLOPT_ENCODING => '',
]);
$resp = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$hs = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'application/octet-stream';
curl_close($ch);
if ($resp === false) {
  http_response_code(502);
  exit('proxy error');
}
$body = substr($resp, $hs);
http_response_code($code >= 100 ? $code : 200);
// если HTML вместо видео — не отдаём как video/mp4
if (stripos($ctype, 'text/html') !== false) {
  header('Content-Type: text/plain; charset=utf-8');
  http_response_code(415);
  echo 'no media stream';
  exit;
}
header('Content-Type: ' . $ctype);
header('Access-Control-Allow-Origin: *');
header('Accept-Ranges: bytes');
header('Cache-Control: public, max-age=120');
echo $body;
