<?php
header('Content-Type: application/json; charset=utf-8');
$root = dirname(__DIR__);
require_once $root . '/includes/functions.php';
require_once $root . '/includes/auth.php';
if (is_file($root . '/includes/content_articles.php')) require_once $root . '/includes/content_articles.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  echo json_encode(['ok' => false, 'error' => 'id'], JSON_UNESCAPED_UNICODE);
  exit;
}
$a = content_article_get($id);
if (!$a) {
  echo json_encode(['ok' => false, 'error' => 'Не найдено'], JSON_UNESCAPED_UNICODE);
  exit;
}
$user = function_exists('current_user') ? current_user() : null;
$isOwner = $user && (int)$user['id'] === (int)$a['user_id'];
$isAdmin = $user && !empty($user['role']) && $user['role'] === 'admin';
if ($a['status'] !== 'published' && !$isOwner && !$isAdmin) {
  echo json_encode(['ok' => false, 'error' => 'Статья на модерации'], JSON_UNESCAPED_UNICODE);
  exit;
}
if ($a['status'] === 'published') {
  if (is_file($root . '/includes/content_views.php')) require_once $root . '/includes/content_views.php';
  if (function_exists('content_view_register')) {
    $a['views'] = content_view_register('article', $id);
  } else {
    content_article_bump_views($id);
    $a['views'] = (int)$a['views'] + 1;
  }
}
echo json_encode(['ok' => true, 'article' => [
  'id' => (int)$a['id'],
  'title' => (string)$a['title'],
  'body' => (string)$a['body'],
  'cover_url' => (string)($a['cover_url'] ?? ''),
  'username' => (string)($a['username'] ?? ''),
  'channel_title' => (string)($a['channel_title'] ?? ''),
  'created_at' => (string)($a['created_at'] ?? ''),
  'views' => (int)($a['views'] ?? 0),
  'status' => (string)$a['status'],
]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
