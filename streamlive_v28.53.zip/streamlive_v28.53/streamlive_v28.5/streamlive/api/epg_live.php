<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-store');

$root = dirname(__DIR__);
if (is_file($root . '/includes/functions.php')) {
  try { require_once $root . '/includes/functions.php'; } catch (Throwable $e) {}
}
require_once $root . '/includes/epg_live.php';

$name = trim((string)($_GET['channel'] ?? $_GET['q'] ?? $_GET['name'] ?? ''));
// доп. подсказки: stream / source / title
$extra = trim((string)($_GET['stream'] ?? $_GET['source'] ?? ''));
if ($name === '' && $extra !== '') $name = $extra;

if ($name === '') {
  echo json_encode(['ok' => false, 'error' => 'channel required', 'items' => []], JSON_UNESCAPED_UNICODE);
  exit;
}

$result = epg_live_schedule_for($name);

// если не нашли — пробуем stream-подсказку отдельно
if (empty($result['ok']) && $extra !== '' && $extra !== $name) {
  $result2 = epg_live_schedule_for($extra);
  if (!empty($result2['ok'])) $result = $result2;
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
