<?php
header('Content-Type: application/json; charset=utf-8');
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/epg_live.php';
$u = function_exists('current_user') ? current_user() : null;
if (!$u || ($u['role'] ?? '') !== 'admin') {
  echo json_encode(['ok' => false, 'error' => 'admin only']);
  exit;
}
@unlink(epg_live_sources_file()); // force
$extra = epg_live_discover_sources();
$all = array_unique(array_merge(epg_live_bootstrap_sources(), $extra));
epg_live_save_sources($all);
echo json_encode(['ok' => true, 'count' => count($all), 'sources' => $all], JSON_UNESCAPED_UNICODE);
