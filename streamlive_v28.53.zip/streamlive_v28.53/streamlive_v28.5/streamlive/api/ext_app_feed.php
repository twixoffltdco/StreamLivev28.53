<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
$videos = []; $channels = []; $threads = []; $err = null;
try {
  $root = dirname(__DIR__);
  if (is_file($root . '/includes/functions.php')) {
    ob_start(); require_once $root . '/includes/functions.php'; ob_end_clean();
  }
  if (function_exists('db')) {
    try { $videos = db()->query('SELECT id, slug, title, thumbnail_url FROM videos ORDER BY id DESC LIMIT 40')->fetchAll() ?: []; }
    catch (Throwable $e) {
      try { $videos = db()->query('SELECT id, slug, title FROM videos ORDER BY id DESC LIMIT 40')->fetchAll() ?: []; }
      catch (Throwable $e2) { $err = $e2->getMessage(); }
    }
    try { $channels = db()->query('SELECT id, slug, title FROM channels ORDER BY id DESC LIMIT 24')->fetchAll() ?: []; }
    catch (Throwable $e) {
      try { $channels = db()->query('SELECT id, slug, name AS title FROM channels ORDER BY id DESC LIMIT 24')->fetchAll() ?: []; } catch (Throwable $e2) {}
    }
  }
} catch (Throwable $e) { $err = $e->getMessage(); }
echo json_encode(['ok' => true, 'videos' => $videos, 'channels' => $channels, 'threads' => $threads, 'error' => $err], JSON_UNESCAPED_UNICODE);
