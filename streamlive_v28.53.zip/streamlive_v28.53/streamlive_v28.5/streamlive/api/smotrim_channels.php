<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=60');
header('Access-Control-Allow-Origin: *');
$root = dirname(__DIR__);
try {
  if (is_file($root . '/includes/functions.php')) require_once $root . '/includes/functions.php';
} catch (Throwable $e) {}

$out = ['ok' => true, 'channels' => [], 'videos' => []];
try {
  if (!function_exists('db')) {
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
  }
  $limit = min(80, max(1, (int)($_GET['limit'] ?? 40)));

  // channels
  try {
    $sql = "SELECT id, slug, title, logo_url, type, views
            FROM channels WHERE status = 'approved'
            ORDER BY views DESC, id DESC LIMIT " . (int)$limit;
    $rows = db()->query($sql)->fetchAll();
  } catch (Throwable $e) {
    $rows = [];
  }
  foreach ($rows as $r) {
    $out['channels'][] = [
      'id' => (int)$r['id'],
      'slug' => (string)$r['slug'],
      'title' => (string)$r['title'],
      'logo' => (string)($r['logo_url'] ?? ''),
      'type' => (string)($r['type'] ?? 'tv'),
      'views' => (int)($r['views'] ?? 0),
      'url' => '/channel-pc.php?slug=' . rawurlencode((string)$r['slug']),
    ];
  }

  // videos — тоже в выпадающем списке
  try {
    $sql = "SELECT id, slug, title, thumbnail_url, views_count
            FROM videos WHERE status = 'published'
            ORDER BY views_count DESC, id DESC LIMIT " . (int)$limit;
    $vrows = db()->query($sql)->fetchAll();
  } catch (Throwable $e) {
    try {
      $sql = "SELECT id, slug, title, thumbnail_url, views AS views_count
              FROM videos WHERE status = 'published'
              ORDER BY id DESC LIMIT " . (int)$limit;
      $vrows = db()->query($sql)->fetchAll();
    } catch (Throwable $e2) {
      $vrows = [];
    }
  }
  foreach ($vrows as $r) {
    $out['videos'][] = [
      'id' => (int)$r['id'],
      'slug' => (string)$r['slug'],
      'title' => (string)$r['title'],
      'logo' => (string)($r['thumbnail_url'] ?? ''),
      'type' => 'video',
      'views' => (int)($r['views_count'] ?? 0),
      'url' => '/video.php?slug=' . rawurlencode((string)$r['slug']),
    ];
  }
} catch (Throwable $e) {
  $out['ok'] = false;
  $out['error'] = $e->getMessage();
}
echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
