<?php
require_once dirname(__DIR__) . '/includes/embed_proxy.php';

$url = trim((string)($_GET['u'] ?? ''));
$mode = (string)($_GET['mode'] ?? '');
if ($url === '' || !preg_match('#^https?://#i', $url)) {
  http_response_code(400);
  echo 'bad url';
  exit;
}

$base = embed_proxy_base();
$media = null;

if ($mode === 'media' || preg_match('#\.(mp4|webm|m3u8)(\?|$)#i', $url)) {
  $media = $url;
} elseif (embed_proxy_host_allowed($url)) {
  $media = embed_proxy_resolve_media($url);
}

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=60');
header('X-Frame-Options: SAMEORIGIN');

$proxy = $base . '/api/media_proxy.php?u=' . rawurlencode($media ?: $url);
$proxyJ = json_encode($proxy, JSON_UNESCAPED_SLASHES);
$urlJ = json_encode($url, JSON_UNESCAPED_SLASHES);
$hasMedia = $media ? 'true' : 'false';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
html,body{margin:0;height:100%;background:#000;color:#9ca3af;font-family:system-ui,sans-serif}
.wrap{position:relative;width:100%;height:100%;min-height:240px}
video{position:absolute;inset:0;width:100%;height:100%;background:#000}
.msg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:20px;text-align:center;line-height:1.5}
</style>
</head>
<body>
<div class="wrap" id="box">
  <div class="msg" id="msg">Подготовка плеера через сервер…</div>
</div>
<script>
(function(){
  var hasMedia = <?php echo $hasMedia; ?>;
  var proxy = <?php echo $proxyJ; ?>;
  var src = <?php echo $urlJ; ?>;
  var box = document.getElementById('box');
  var msg = document.getElementById('msg');

  function playProxied(u) {
    var v = document.createElement('video');
    v.controls = true;
    v.playsInline = true;
    v.autoplay = false;
    v.src = u;
    v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%';
    box.appendChild(v);
    msg.style.display = 'none';
    v.addEventListener('error', function(){
      msg.style.display = 'flex';
      msg.innerHTML = 'Поток временно недоступен. <a style="color:#93c5fd" href="'+src+'" target="_blank" rel="noopener">Открыть источник</a>';
    });
  }

  if (hasMedia) {
    playProxied(proxy);
    return;
  }

  // Нет прямого media — просим resolve на сервере через media_proxy с оригиналом (может отдать HTML; тогда ошибка)
  // Пробуем всё равно video с proxy
  playProxied(proxy);
})();
</script>
</body>
</html>
