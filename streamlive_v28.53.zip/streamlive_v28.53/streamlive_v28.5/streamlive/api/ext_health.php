<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
echo json_encode(['ok' => true, 't' => time(), 'name' => 'StreamLive', 'script' => 'streamlive']);
