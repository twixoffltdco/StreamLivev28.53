<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

header('Content-Type: application/json; charset=utf-8');

$user = current_user();
if (!$user) {
    echo json_encode(['ok' => false, 'error' => 'Не авторизован']);
    exit;
}

try {
    // Проверяем существование таблиц (на случай если миграция не применена)
    $check = db()->query("SHOW TABLES LIKE 'partner_activations'");
    if (!$check->rowCount()) {
        echo json_encode(['ok' => false, 'error' => 'Система промокодов ещё не установлена']);
        exit;
    }
    $check = db()->query("SHOW TABLES LIKE 'partner_promos'");
    if (!$check->rowCount()) {
        echo json_encode(['ok' => false, 'error' => 'Нет доступных промокодов']);
        exit;
    }

    $today = date('Y-m-d');
    $stmt = db()->prepare("
        SELECT pa.id, pp.code, u.username as partner_name, pa.access_until
        FROM partner_activations pa
        JOIN partner_promos pp ON pp.id = pa.promo_id
        JOIN users u ON u.id = pp.user_id
        WHERE pa.user_id = ? AND DATE(pa.activated_at) = ?
        LIMIT 1
    ");
    $stmt->execute([(int)$user['id'], $today]);
    $existing = $stmt->fetch();

    if ($existing) {
        echo json_encode([
            'ok' => false,
            'already' => true,
            'error' => 'Вы уже получали промокод сегодня',
            'code' => $existing['code'],
            'partner' => $existing['partner_name'],
            'access_until' => $existing['access_until']
        ]);
        exit;
    }

    $stmt = db()->prepare("
        SELECT pp.id, pp.code, pp.user_id as partner_id, u.username as partner_name
        FROM partner_promos pp
        JOIN users u ON u.id = pp.user_id
        ORDER BY RAND()
        LIMIT 1
    ");
    $stmt->execute();
    $promo = $stmt->fetch();

    if (!$promo) {
        echo json_encode(['ok' => false, 'error' => 'Промокоды временно недоступны']);
        exit;
    }

    $accessUntil = date('Y-m-d H:i:s', strtotime('+30 days'));
    $stmt = db()->prepare("
        INSERT INTO partner_activations (promo_id, user_id, activated_at, access_until)
        VALUES (?, ?, NOW(), ?)
    ");
    $stmt->execute([(int)$promo['id'], (int)$user['id'], $accessUntil]);

    try {
        $stmt = db()->prepare("
            INSERT IGNORE INTO partner_referrals (partner_user_id, referred_user_id)
            VALUES (?, ?)
        ");
        $stmt->execute([(int)$promo['partner_id'], (int)$user['id']]);
    } catch (Throwable $e) {}

    echo json_encode([
        'ok' => true,
        'code' => $promo['code'],
        'partner' => $promo['partner_name'],
        'access_until' => $accessUntil
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Ошибка: ' . $e->getMessage()]);
}