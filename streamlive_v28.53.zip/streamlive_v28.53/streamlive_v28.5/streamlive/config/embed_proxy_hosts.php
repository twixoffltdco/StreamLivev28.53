<?php
return [
  'rumble.com','www.rumble.com','v.rumble.com',
  'instagram.com','www.instagram.com',
  'vk.com','vk.ru','vkvideo.ru','ok.ru',
  'tiktok.com','twitch.tv','player.twitch.tv','kick.com',
  'dropbox.com','dl.dropboxusercontent.com',
];
