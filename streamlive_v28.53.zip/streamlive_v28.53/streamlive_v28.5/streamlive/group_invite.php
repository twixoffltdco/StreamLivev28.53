<?php
require_once __DIR__.'/includes/functions.php';require_once __DIR__.'/includes/auth.php';require_once __DIR__.'/includes/group_chats_schema.php';if(!group_chat_schema_ensure()){http_response_code(503);exit('Приглашения временно недоступны');}$token=trim((string)($_GET['token']??''));if(!preg_match('/^[a-f0-9]{48}$/i',$token)){http_response_code(404);exit('Приглашение недействительно');}$s=db()->prepare('SELECT id,title,invite_token FROM group_chats WHERE invite_token=? LIMIT 1');$s->execute([$token]);$g=$s->fetch();if(!$g){http_response_code(404);exit('Группа не найдена или ссылка устарела');}$u=current_user();if($_SERVER['REQUEST_METHOD']==='POST'){if(!$u)redirect('/auth/login.php?next='.rawurlencode('/group_invite.php?token='.$token));csrf_verify();$a=(string)($_POST['invite_action']??'');if($a==='accept'){if(!group_chat_add_member((int)$g['id'],(int)$u['id'])){flash_set('error','Не удалось присоединиться к группе');redirect('/group_invite.php?token='.$token);}redirect('/group_chats.php?id='.(int)$g['id']);}if($a==='decline'){header('Content-Type:text/html;charset=utf-8');echo '<!doctype html><meta charset="utf-8"><title>Приглашение</title><script>try{window.close()}catch(e){}setTimeout(function(){location.href="/messages.php"},250)</script><div style="font-family:sans-serif;text-align:center;padding:50px">Приглашение отклонено. Вкладку можно закрыть.</div>';exit;}}
$next='/group_invite.php?token='.rawurlencode($token);$pageTitle='Приглашение в группу';require_once __DIR__.'/includes/header.php';?>
<div class="container" style="max-width:620px;margin:60px auto">
<div id="invite-overlay" style="position:relative;display:flex;align-items:center;justify-content:center;padding:10px">
  <div class="form-card" style="width:min(560px,100%);margin:0;padding:32px;text-align:center;box-shadow:0 18px 60px rgba(0,0,0,.28)">
    <div style="font-size:64px">👥</div>
    <div style="font-size:12px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.08em">Приглашение</div>
    <h2 style="margin:8px 0 6px">Вас пригласили в группу</h2>
    <div style="font-size:22px;font-weight:700;margin-bottom:10px"><?= e($g['title']) ?></div>
    <?php if (!$u): ?>
      <p style="color:var(--text-dim)">Войдите или зарегистрируйтесь, чтобы принять приглашение.</p>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:22px;flex-wrap:wrap">
        <a class="btn btn-primary" href="/auth/login.php?next=<?= rawurlencode($next) ?>">Войти</a>
        <a class="btn btn-outline" href="/auth/register.php">Зарегистрироваться</a>
      </div>
    <?php else: ?>
      <p style="color:var(--text-dim)">Вы вошли как <b><?= e($u['username']) ?></b>. Принять приглашение?</p>
      <form method="POST" style="display:flex;gap:10px;justify-content:center;margin-top:22px;flex-wrap:wrap">
        <?= csrf_field() ?>
        <button class="btn btn-primary" name="invite_action" value="accept">Присоединиться</button>
        <button class="btn btn-outline" name="invite_action" value="decline">Отклонить</button>
      </form>
      <div style="margin-top:12px;font-size:11px;color:var(--text-dim)">«Отклонить» закроет приглашение и не добавит вас в группу.</div>
    <?php endif; ?>
  </div>
</div>
</div>
<?php require_once __DIR__.'/includes/footer.php';?>
