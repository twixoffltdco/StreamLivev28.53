<?php
/** Алиас → video_embed.php (cinema + raw) */
require __DIR__ . '/video_embed.php';
