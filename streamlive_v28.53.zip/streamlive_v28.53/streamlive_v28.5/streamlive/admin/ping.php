<?php
header('Content-Type: text/plain; charset=utf-8');
echo "admin_ping_ok\n";
echo "php=".PHP_VERSION."\n";
echo "session=".session_status()."\n";
try {
  require_once __DIR__.'/../includes/panel_boot.php';
  $u = panel_user();
  echo "user=".($u ? $u['username'].' role='.($u['role']??'') : 'null')."\n";
  echo "admin=".(panel_is_admin($u)?'1':'0')."\n";
  echo "db=".(function_exists('db')?'yes':'no')."\n";
} catch (Throwable $e) {
  echo "err=".$e->getMessage()."\n";
}
