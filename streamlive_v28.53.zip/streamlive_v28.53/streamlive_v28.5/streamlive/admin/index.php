<?php
/**
 * Оригинальный обзор админки + безопасный бут (functions до COUNT).
 */
$__root = dirname(__DIR__);
if (!function_exists('db')) {
  if (is_file($__root . '/includes/functions.php')) require_once $__root . '/includes/functions.php';
  if (is_file($__root . '/includes/auth.php')) require_once $__root . '/includes/auth.php';
}

$totalVideos = 0; $totalResources = 0; $pendingContent = 0;
try { $totalVideos = (int)db()->query('SELECT COUNT(*) FROM videos')->fetchColumn(); } catch (Throwable $e) {}
try { $totalResources = (int)db()->query('SELECT COUNT(*) FROM resources')->fetchColumn(); } catch (Throwable $e) {}
try { $pendingContent = (int)db()->query("SELECT COUNT(*) FROM content_moderation_queue WHERE status='pending'")->fetchColumn(); } catch (Throwable $e) {}

require_once __DIR__ . '/_layout_start.php';

$pending = 0; $totalChannels = 0; $approvedChannels = 0; $users = 0;
$forumThreads = 0; $forumPosts = 0; $bcChannels = 0; $bcSubs = 0;
try { $pending = (int)db()->query("SELECT COUNT(*) FROM channels WHERE status='pending'")->fetchColumn(); } catch (Throwable $e) {}
try { $totalChannels = (int)db()->query('SELECT COUNT(*) FROM channels')->fetchColumn(); } catch (Throwable $e) {}
try { $approvedChannels = (int)db()->query("SELECT COUNT(*) FROM channels WHERE status='approved'")->fetchColumn(); } catch (Throwable $e) {
  try { $approvedChannels = (int)db()->query("SELECT COUNT(*) FROM channels WHERE status='published'")->fetchColumn(); } catch (Throwable $e2) {}
}
try { $users = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn(); } catch (Throwable $e) {}
try { $forumThreads = (int)db()->query('SELECT COUNT(*) FROM forum_threads')->fetchColumn(); } catch (Throwable $e) {}
try { $forumPosts = (int)db()->query('SELECT COUNT(*) FROM forum_posts')->fetchColumn(); } catch (Throwable $e) {}
try { $bcChannels = (int)db()->query('SELECT COUNT(*) FROM broadcast_channels')->fetchColumn(); } catch (Throwable $e) {}
try { $bcSubs = (int)db()->query('SELECT COUNT(*) FROM broadcast_subscribers')->fetchColumn(); } catch (Throwable $e) {}

$stats = [
  'recent_views' => 0, 'unique_visitors' => 0, 'avg_daily' => 0,
  'today_views' => 0, 'total_views' => 0, 'by_day' => [],
];
try {
  if (is_file($__root . '/includes/stats.php')) {
    require_once $__root . '/includes/stats.php';
    if (function_exists('stats_summary')) {
      $s = stats_summary(30);
      if (is_array($s)) $stats = array_merge($stats, $s);
    }
  }
} catch (Throwable $e) {}

$recentUsers = []; $recentChannels = [];
try { $recentUsers = db()->query('SELECT username, email, created_at FROM users ORDER BY id DESC LIMIT 8')->fetchAll() ?: []; } catch (Throwable $e) {}
try { $recentChannels = db()->query('SELECT title, status, created_at FROM channels ORDER BY id DESC LIMIT 8')->fetchAll() ?: []; } catch (Throwable $e) {}
?>
<h2>Обзор</h2>
<div class="stat-grid">
  <div class="stat-card"><div class="num"><?= (int)$users ?></div><div class="lbl">Пользователей</div></div>
  <div class="stat-card"><div class="num"><?= (int)$totalChannels ?></div><div class="lbl">Каналов</div></div>
  <div class="stat-card"><div class="num"><?= (int)$pending ?></div><div class="lbl">Каналов на модерации</div></div>
  <div class="stat-card"><div class="num"><?= (int)$approvedChannels ?></div><div class="lbl">Одобренных каналов</div></div>
  <div class="stat-card"><div class="num"><?= (int)$totalVideos ?></div><div class="lbl">Видео</div></div>
  <div class="stat-card"><div class="num"><?= (int)$totalResources ?></div><div class="lbl">Ресурсов</div></div>
  <div class="stat-card"><div class="num"><?= (int)$pendingContent ?></div><div class="lbl">Очередь контента</div></div>
  <div class="stat-card"><div class="num"><?= (int)$forumThreads ?></div><div class="lbl">Тем форума</div></div>
  <div class="stat-card"><div class="num"><?= (int)$forumPosts ?></div><div class="lbl">Постов</div></div>
  <div class="stat-card"><div class="num"><?= (int)($stats['today_views'] ?? 0) ?></div><div class="lbl">Просмотров сегодня</div></div>
  <div class="stat-card"><div class="num"><?= (int)($stats['recent_views'] ?? 0) ?></div><div class="lbl">Просмотров 30 дн.</div></div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:20px" class="admin-activity-grid">
  <div class="form-card" style="background:#1e293b;border-radius:12px;padding:14px">
    <h4 style="margin-top:0">Новые пользователи</h4>
    <?php if (!$recentUsers): ?><p style="opacity:.6">Нет данных</p><?php endif; ?>
    <?php foreach ($recentUsers as $ru): ?>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-top:1px solid #333;font-size:12.5px">
        <span><?= htmlspecialchars((string)$ru['username']) ?></span>
        <span style="opacity:.6"><?= htmlspecialchars((string)($ru['created_at'] ?? '')) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="form-card" style="background:#1e293b;border-radius:12px;padding:14px">
    <h4 style="margin-top:0">Новые каналы</h4>
    <?php if (!$recentChannels): ?><p style="opacity:.6">Нет данных</p><?php endif; ?>
    <?php foreach ($recentChannels as $rc): ?>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-top:1px solid #333;font-size:12.5px">
        <span><?= htmlspecialchars((string)$rc['title']) ?> <small><?= htmlspecialchars((string)($rc['status'] ?? '')) ?></small></span>
        <span style="opacity:.6"><?= htmlspecialchars((string)($rc['created_at'] ?? '')) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<style>@media (max-width:720px){ .admin-activity-grid{grid-template-columns:1fr!important} }</style>
<?php require_once __DIR__ . '/_layout_end.php'; ?>
