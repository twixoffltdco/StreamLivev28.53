<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/support_tickets.php';
$__user = require_login();
if (!support_is_staff($__user)) { http_response_code(403); exit('Только модераторы и администраторы'); }
support_tickets_ensure();

$status = $_GET['status'] ?? '';
$rows = [];
try {
  if (in_array($status, ['open','answered','closed'], true)) {
    $st = db()->prepare(
      'SELECT t.*, u.username FROM support_tickets t LEFT JOIN users u ON u.id=t.user_id
       WHERE t.status=? ORDER BY COALESCE(t.last_reply_at, t.created_at) DESC LIMIT 100'
    );
    $st->execute([$status]);
    $rows = $st->fetchAll() ?: [];
  } else {
    $rows = db()->query(
      'SELECT t.*, u.username FROM support_tickets t LEFT JOIN users u ON u.id=t.user_id
       ORDER BY FIELD(t.status,\'open\',\'answered\',\'closed\'), COALESCE(t.last_reply_at, t.created_at) DESC LIMIT 100'
    )->fetchAll() ?: [];
  }
} catch (Throwable $e) {}

$pageTitle = 'Тикеты поддержки';
if (is_file(dirname(__DIR__) . '/admin/_layout_start.php')) {
  require dirname(__DIR__) . '/admin/_layout_start.php';
} else {
  require dirname(__DIR__) . '/includes/header.php';
}
?>
<h1>Тикеты поддержки</h1>
<p style="opacity:.7">
  <a href="?">Все</a> ·
  <a href="?status=open">Открытые</a> ·
  <a href="?status=answered">С ответом</a> ·
  <a href="?status=closed">Закрытые</a>
</p>
<table class="admin-table" style="width:100%">
  <thead><tr><th>#</th><th>Тема</th><th>Пользователь</th><th>Статус</th><th>Обновлён</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $t): ?>
    <tr>
      <td><?= (int)$t['id'] ?></td>
      <td><a href="/support/ticket.php?id=<?= (int)$t['id'] ?>"><?= htmlspecialchars($t['subject'], ENT_QUOTES, 'UTF-8') ?></a></td>
      <td><?= htmlspecialchars($t['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
      <td><?= htmlspecialchars(support_status_label($t['status']), ENT_QUOTES, 'UTF-8') ?></td>
      <td style="font-size:12px;opacity:.65"><?= htmlspecialchars($t['last_reply_at'] ?? $t['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
if (is_file(dirname(__DIR__) . '/admin/_layout_end.php')) require dirname(__DIR__) . '/admin/_layout_end.php';
else require dirname(__DIR__) . '/includes/footer.php';
?>
