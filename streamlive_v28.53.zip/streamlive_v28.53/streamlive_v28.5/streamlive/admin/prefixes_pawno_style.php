<?php
http_response_code(200);
$__root = dirname(__DIR__);
require_once $__root . '/includes/functions.php';
require_once $__root . '/includes/auth.php';
if (function_exists('require_admin')) require_admin();
if (is_file($__root . '/includes/prefix_pawno_banners.php')) {
  require_once $__root . '/includes/prefix_pawno_banners.php';
}
$n = function_exists('prefix_pawno_restyle_all') ? prefix_pawno_restyle_all() : 0;
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Pawno</title></head><body style="font-family:system-ui;background:#111;color:#eee;padding:24px">';
echo '<p>Обновлено баннеров (без затирания твоего rich-CSS): <b>' . (int)$n . '</b></p>';
echo '<p><a href="/admin/prefixes.php" style="color:#93c5fd">← Префиксы</a></p></body></html>';
