<?php
require_once __DIR__ . '/_layout_start.php';
require_once dirname(__DIR__) . '/includes/mailer.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && function_exists('set_setting')) {
  if (function_exists('csrf_verify')) { try { csrf_verify(); } catch (Throwable $e) {} }
  $from = trim((string)($_POST['mail_from'] ?? ''));
  $name = trim((string)($_POST['mail_from_name'] ?? 'StreamLive'));
  set_setting('mail_from', $from);
  set_setting('mail_from_name', $name);
  $msg = 'Сохранено';
}
$curFrom = function_exists('get_setting') ? get_setting('mail_from', '') : '';
$curName = function_exists('get_setting') ? get_setting('mail_from_name', 'StreamLive') : 'StreamLive';
[$autoFrom, $autoName, $host] = mailer_from();
?>
<h2>Почта (From)</h2>
<p>Домен сайта: <b><?= htmlspecialchars($host, ENT_QUOTES, 'UTF-8') ?></b></p>
<p>Сейчас письма уходят как: <b><?= htmlspecialchars($autoFrom, ENT_QUOTES, 'UTF-8') ?></b></p>
<?php if ($msg): ?><p style="color:#4ade80"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<form method="post" class="form-card" style="padding:16px;max-width:480px">
  <?= function_exists('csrf_field')?csrf_field():'' ?>
  <label>mail_from (ящик на вашем домене)</label>
  <input name="mail_from" value="<?= htmlspecialchars($curFrom, ENT_QUOTES, 'UTF-8') ?>" placeholder="noreply@<?= htmlspecialchars($host, ENT_QUOTES, 'UTF-8') ?>" style="width:100%">
  <label style="margin-top:10px;display:block">Имя отправителя</label>
  <input name="mail_from_name" value="<?= htmlspecialchars($curName, ENT_QUOTES, 'UTF-8') ?>" style="width:100%">
  <button class="btn btn-primary" style="margin-top:12px" type="submit">Сохранить</button>
</form>
<p style="font-size:13px;opacity:.7;margin-top:12px">На BindHost создай почтовый ящик на домене сайта и укажи его здесь. Иначе mail() может не доставлять письма.</p>
<?php require_once __DIR__ . '/_layout_end.php'; ?>
