<?php
/**
 * Оригинальный вид админки (shell + sidebar), но без фатала:
 * header.php в try — если падает, мягкий fallback с тем же меню.
 */
$__root = dirname(__DIR__);
if (!function_exists('db')) {
  if (is_file($__root . '/includes/functions.php')) require_once $__root . '/includes/functions.php';
  if (is_file($__root . '/includes/auth.php')) require_once $__root . '/includes/auth.php';
}

$__layout_fallback = false;
$__layout_err = '';

// auth
try {
  if (function_exists('require_admin')) {
    $__user = require_admin();
  } else {
    $__user = function_exists('current_user') ? current_user() : null;
    if (!$__user || (($__user['role'] ?? '') !== 'admin' && empty($__user['is_admin']) && (int)($__user['id'] ?? 0) !== 1)) {
      http_response_code(403);
      exit('Admin only');
    }
  }
} catch (Throwable $e) {
  http_response_code(403);
  exit('Admin: ' . htmlspecialchars($e->getMessage()));
}

// try original header (site style)
ob_start();
try {
  if (is_file($__root . '/includes/header.php')) {
    require $__root . '/includes/header.php';
  } else {
    $__layout_fallback = true;
  }
} catch (Throwable $e) {
  $__layout_err = $e->getMessage();
  $__layout_fallback = true;
  ob_end_clean();
}
if (!$__layout_fallback) {
  // header printed ok
  $buf = ob_get_clean();
  echo $buf;
} else {
  if (ob_get_level()) @ob_end_clean();
  if (!headers_sent()) header('Content-Type: text/html; charset=utf-8');
  echo '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
  echo '<title>Админ</title>';
  // подтянуть стили сайта если есть
  if (is_file($__root . '/assets/css/main.css')) {
    echo '<link rel="stylesheet" href="/assets/css/main.css">';
  }
  echo '<style>
  body{margin:0;font-family:system-ui,sans-serif;background:#0f0f12;color:#e5e7eb}
  .admin-shell{display:flex;min-height:100vh}
  .admin-sidebar{width:220px;background:#111827;padding:16px;flex-shrink:0}
  .admin-sidebar a{display:block;color:#93c5fd;text-decoration:none;padding:8px 0;font-size:14px}
  .admin-content{flex:1;padding:20px}
  .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
  .stat-card{background:#1e293b;border-radius:12px;padding:14px}
  .stat-card .num{font-size:22px;font-weight:700}
  .stat-card .lbl{font-size:12px;opacity:.7}
  @media(max-width:768px){.admin-shell{flex-direction:column}.admin-sidebar{width:auto;display:flex;flex-wrap:wrap;gap:8px 16px}}
  </style></head><body>';
  if ($__layout_err) {
    echo '<!-- header error: '.htmlspecialchars($__layout_err, ENT_QUOTES).' -->';
  }
}

// original sidebar links
?>
<div class="admin-shell">
  <div class="admin-sidebar">
    <a href="/admin/index.php">Обзор</a>
    <a href="/admin/transfer_ownership.php">Передача контента</a>
    <a href="/admin/moderation.php">Модерация каналов</a>
    <a href="/content_moderation_panel.php">Модерация контента</a>
    <a href="/admin/security.php">Безопасность (2FA)</a>
    <a href="/admin/maintenance.php">Техработы</a>
    <a href="/admin/channels.php">Все каналы</a>
    <a href="/admin/forum.php">Форум (категории)</a>
    <a href="/admin/rss.php">RSS-источники</a>
    <a href="/admin/ai.php">ИИ T2000</a>
    <a href="/admin/prefixes.php">Префиксы</a>
    <a href="/admin/battle_pass.php">Battle Pass</a>
    <a href="/admin/sources.php">Источники</a>
    <a href="/admin/oauth.php">Соц. авторизация</a>
    <a href="/admin/themes.php">Themes</a>
    <a href="/admin/services.php">Деплой-сервисы</a>
    <a href="/admin/users.php">Пользователи</a>
    <a href="/admin/update.php">Обновление БД</a>
    <a href="/admin/import.php">Импорт</a>
    <a href="/resources">Ресурсы</a>
    <a href="/admin/paid_channels.php">Платный контент</a>
    <a href="/moderator/index.php">Мод-панель</a>
  </div>
  <div class="admin-content">
