<?php
/**
 * Максимально живучий feed — не падает, всегда JSON.
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Cache-Control: public, max-age=15');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$videos = [];
$channels = [];
$threads = [];
$err = null;

try {
  $root = dirname(__DIR__);
  // functions.php часто тянет сессию/auth — ловим всё
  if (is_file($root . '/includes/functions.php')) {
    ob_start();
    require_once $root . '/includes/functions.php';
    ob_end_clean();
  } elseif (is_file($root . '/config.php')) {
    ob_start();
    require_once $root . '/config.php';
    ob_end_clean();
  }

  if (!function_exists('db')) {
    throw new Exception('db() not found — подключите includes/functions.php');
  }

  // videos — разные схемы
  $qList = [
    "SELECT id, slug, title, thumbnail_url FROM videos ORDER BY id DESC LIMIT 40",
    "SELECT id, slug, title, cover AS thumbnail_url FROM videos ORDER BY id DESC LIMIT 40",
    "SELECT id, slug, title FROM videos ORDER BY id DESC LIMIT 40",
    "SELECT id, slug, name AS title FROM videos ORDER BY id DESC LIMIT 40",
  ];
  foreach ($qList as $sql) {
    try {
      $videos = db()->query($sql)->fetchAll();
      if (!is_array($videos)) $videos = [];
      break;
    } catch (Throwable $e) {
      $err = $e->getMessage();
      $videos = [];
    }
  }

  $cList = [
    "SELECT id, slug, title FROM channels ORDER BY id DESC LIMIT 24",
    "SELECT id, slug, name AS title FROM channels ORDER BY id DESC LIMIT 24",
    "SELECT id, slug, title FROM channel ORDER BY id DESC LIMIT 24",
  ];
  foreach ($cList as $sql) {
    try {
      $channels = db()->query($sql)->fetchAll();
      if (!is_array($channels)) $channels = [];
      break;
    } catch (Throwable $e) {
      $channels = [];
    }
  }

  try {
    $threads = db()->query(
      "SELECT t.id, t.title FROM forum_threads t ORDER BY t.id DESC LIMIT 20"
    )->fetchAll() ?: [];
  } catch (Throwable $e) {
    $threads = [];
  }
} catch (Throwable $e) {
  $err = $e->getMessage();
}

echo json_encode([
  'ok' => true,
  'videos' => $videos,
  'channels' => $channels,
  'threads' => $threads,
  'error' => $err,
  'counts' => [
    'videos' => count($videos),
    'channels' => count($channels),
    'threads' => count($threads),
  ],
], JSON_UNESCAPED_UNICODE);
