<?php
/**
 * Явный cinema-вход (совместимость):
 * /embed_cinema.php?type=channel|video&slug=...
 */
$type = strtolower(trim((string)($_GET['type'] ?? 'video')));
$slug = trim((string)($_GET['slug'] ?? ''));
if ($slug === '') {
  http_response_code(400);
  die('Укажите slug');
}
if ($type === 'channel') {
  header('Location: /embed.php?slug=' . rawurlencode($slug), true, 302);
  exit;
}
header('Location: /video_embed.php?slug=' . rawurlencode($slug), true, 302);
exit;
