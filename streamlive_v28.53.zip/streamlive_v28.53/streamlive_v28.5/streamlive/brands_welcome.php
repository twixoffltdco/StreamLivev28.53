<?php
/**
 * Лендинг StreamLive бренды (как welcome.php)
 */
$siteName = defined('SITE_NAME') ? SITE_NAME : 'StreamLive';
$e = static function ($s) {
  return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
};
if (is_file(__DIR__ . '/includes/functions.php')) {
  require_once __DIR__ . '/includes/functions.php';
  if (defined('SITE_NAME')) $siteName = SITE_NAME;
}
?><!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $e($siteName) ?> бренды — аккаунты организаций</title>
<meta name="description" content="StreamLive бренды: создавайте бренд-аккаунты как организации на GitHub. Каналы, форум, комментарии и Flex World от имени бренда.">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Unbounded:wght@500;700&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0b0e14; --fg: #f1f5f9; --muted: #94a3b8; --card: #151a24;
  --accent: #00a2ff; --radius: 14px;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Inter,system-ui,sans-serif;background:var(--bg);color:var(--fg);line-height:1.55;min-height:100vh}
.wrap{max-width:720px;margin:0 auto;padding:48px 20px}
h1{font-family:Unbounded,sans-serif;font-size:clamp(1.6rem,4vw,2.2rem);margin-bottom:12px}
.lead{color:var(--muted);margin-bottom:28px;font-size:1.05rem}
.grid{display:grid;gap:12px;margin:24px 0}
.card{background:var(--card);border-radius:var(--radius);padding:16px 18px;border:1px solid rgba(255,255,255,.06)}
.card strong{display:block;margin-bottom:4px}
.card span{color:var(--muted);font-size:.92rem}
.cta{display:inline-block;margin:8px 8px 0 0;padding:14px 18px;border-radius:12px;font-weight:800;text-decoration:none}
.cta-main{background:var(--accent);color:#fff}
.cta-ghost{background:#1e293b;color:#fff}
.note{margin-top:28px;font-size:13px;color:var(--muted)}
</style>
</head>
<body>
<div class="wrap">
  <h1>StreamLive бренды</h1>
  <p class="lead">Аккаунты бренда — как организации на GitHub. Публикуйте видео, ТВ/радио, посты на форуме и заходите в Flex World от имени бренда. До 20 брендов на аккаунт.</p>
  <div class="grid">
    <div class="card"><strong>Отдельный профиль</strong><span>Как обычный профиль + пометка, кто создал бренд</span></div>
    <div class="card"><strong>Команда</strong><span>Добавляйте admin и editor — вместе ведёте бренд</span></div>
    <div class="card"><strong>Везде от имени бренда</strong><span>Комментарии, форум, ресурсы, Flex — если бренд активен</span></div>
    <div class="card"><strong>Быстрое переключение</strong><span>Личный ↔ бренд в один клик</span></div>
  </div>
  <a class="cta cta-main" href="/brands/">Мои бренды</a>
  <a class="cta cta-ghost" href="/auth/register.php">Регистрация</a>
  <a class="cta cta-ghost" href="/">На главную</a>
  <p class="note">StreamLive · бренд-аккаунты · не ломает личный профиль</p>
</div>
</body>
</html>
