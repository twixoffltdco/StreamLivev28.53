<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
$name = 'StreamLive';
try {
  $cfg = dirname(__DIR__) . '/config.php';
  if (is_file($cfg)) {
    ob_start();
    include $cfg;
    ob_end_clean();
  }
  if (defined('SITE_NAME') && SITE_NAME) $name = (string)SITE_NAME;
  elseif (defined('APP_NAME') && APP_NAME) $name = (string)APP_NAME;
} catch (Throwable $e) {}
echo json_encode(['ok' => true, 'name' => $name], JSON_UNESCAPED_UNICODE);
