<?php
$pageTitle = 'Мои статьи';
require_once __DIR__ . '/includes/header.php';
require_login();
if (is_file(__DIR__ . '/includes/content_articles.php')) {
  require_once __DIR__ . '/includes/content_articles.php';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try { csrf_verify(); } catch (Throwable $e) {
    flash_set('error', 'CSRF');
    redirect('/my_articles.php');
  }
  $action = (string)($_POST['action'] ?? '');
  if ($action === 'delete_article') {
    $res = content_article_delete((int)($_POST['article_id'] ?? 0), $__user);
    flash_set(!empty($res['ok']) ? 'success' : 'error', !empty($res['ok']) ? 'Удалено' : ($res['error'] ?? 'Ошибка'));
    redirect('/my_articles.php');
  }
  if ($action === 'create_article') {
    $res = content_article_create($__user, [
      'title' => (string)($_POST['title'] ?? ''),
      'body' => (string)($_POST['body'] ?? ''),
      'channel_id' => !empty($_POST['channel_id']) ? (int)$_POST['channel_id'] : null,
      'video_id' => !empty($_POST['video_id']) ? (int)$_POST['video_id'] : null,
      'cover_url' => (string)($_POST['cover_url'] ?? ''),
    ]);
    flash_set(!empty($res['ok']) ? 'success' : 'error',
      !empty($res['ok']) ? ('Создано' . ((($res['status'] ?? '') === 'pending') ? ' (модерация)' : '')) : ($res['error'] ?? 'Ошибка'));
    redirect('/my_articles.php');
  }
}

$list = content_articles_list_by_user((int)$__user['id'], 100);
$myChannels = [];
try {
  $st = db()->prepare('SELECT id, title FROM channels WHERE owner_id = ? ORDER BY title');
  $st->execute([(int)$__user['id']]);
  $myChannels = $st->fetchAll() ?: [];
} catch (Throwable $e) {}
?>
<div class="container">
  <h1>Мои статьи</h1>
  <p style="color:var(--text-dim);font-size:14px">Публикация как в Дзене. Просмотр — в модальном окне.</p>

  <div class="form-card form-wide" style="margin:16px 0">
    <h2>Новая статья</h2>
    <form method="POST">
      <?= function_exists('csrf_field') ? csrf_field() : '' ?>
      <input type="hidden" name="action" value="create_article">
      <label>Заголовок</label>
      <input type="text" name="title" required maxlength="255">
      <label>Текст</label>
      <textarea name="body" required rows="8"></textarea>
      <label>Обложка URL</label>
      <input type="url" name="cover_url" placeholder="https://...">
      <label>Канал (опционально)</label>
      <select name="channel_id">
        <option value="">— без канала —</option>
        <?php foreach ($myChannels as $c): ?>
          <option value="<?= (int)$c['id'] ?>"><?= e($c['title']) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-primary" type="submit" style="margin-top:12px">Опубликовать</button>
    </form>
  </div>

  <div class="form-card form-wide">
    <h2>Опубликованные (<?= count($list) ?>)</h2>
    <?php if (!$list): ?>
      <p style="color:var(--text-dim)">Пока пусто</p>
    <?php else: ?>
      <ul style="list-style:none;padding:0;margin:0">
        <?php foreach ($list as $a): ?>
        <li style="display:flex;gap:12px;align-items:flex-start;padding:14px 0;border-bottom:1px solid var(--border,#243049);flex-wrap:wrap">
          <?php if (!empty($a['cover_url'])): ?>
            <img src="<?= e($a['cover_url']) ?>" alt="" style="width:96px;height:64px;object-fit:cover;border-radius:10px">
          <?php endif; ?>
          <div style="flex:1;min-width:180px">
            <strong><?= e($a['title']) ?></strong>
            <div style="font-size:12px;opacity:.65;margin-top:4px">
              <?= e($a['status']) ?> · <?= e($a['created_at']) ?>
              <?php if (!empty($a['channel_title'])): ?> · <?= e($a['channel_title']) ?><?php endif; ?>
              <?php if (!empty($a['video_title'])): ?> · видео: <?= e($a['video_title']) ?><?php endif; ?>
              · <?= (int)($a['views'] ?? 0) ?> просм.
            </div>
          </div>
          <button type="button" class="btn btn-ghost dz-open-article" data-id="<?= (int)$a['id'] ?>">Открыть</button>
          <form method="POST" onsubmit="return confirm('Удалить?');" style="display:inline">
            <?= function_exists('csrf_field') ? csrf_field() : '' ?>
            <input type="hidden" name="action" value="delete_article">
            <input type="hidden" name="article_id" value="<?= (int)$a['id'] ?>">
            <button class="btn btn-danger" type="submit">Удалить</button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</div>
<link rel="stylesheet" href="/assets/css/dzen-article-modal.css?v=1">
<script src="/assets/js/dzen-article-modal.js?v=1" defer></script>
<div id="dz-article-modal" class="dz-modal" hidden>
  <div class="dz-modal__backdrop" data-dz-close></div>
  <div class="dz-modal__sheet" role="dialog">
    <button type="button" class="dz-modal__x" data-dz-close aria-label="Закрыть">×</button>
    <div class="dz-modal__body" id="dz-article-body">Загрузка…</div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
