<?php
if (!function_exists('content_articles_ensure_table')) {
  function content_articles_ensure_table(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
      db()->exec(
        "CREATE TABLE IF NOT EXISTS content_articles (
          id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          user_id INT UNSIGNED NOT NULL,
          channel_id INT UNSIGNED NULL,
          video_id INT UNSIGNED NULL,
          title VARCHAR(255) NOT NULL,
          body MEDIUMTEXT NOT NULL,
          cover_url VARCHAR(500) NULL,
          status VARCHAR(20) NOT NULL DEFAULT 'pending',
          views INT UNSIGNED NOT NULL DEFAULT 0,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NULL,
          KEY idx_user (user_id),
          KEY idx_channel (channel_id),
          KEY idx_video (video_id),
          KEY idx_status_created (status, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
      );
    } catch (Throwable $e) {}
  }
}

if (!function_exists('content_articles_list')) {
  function content_articles_list(?int $channelId = null, ?int $videoId = null, int $limit = 20, bool $publishedOnly = true): array {
    content_articles_ensure_table();
    $limit = max(1, min(100, $limit));
    try {
      $where = $publishedOnly ? "a.status = 'published'" : '1=1';
      if ($videoId) {
        $st = db()->prepare(
          "SELECT a.*, u.username FROM content_articles a
           JOIN users u ON u.id = a.user_id
           WHERE a.video_id = ? AND {$where}
           ORDER BY a.created_at DESC LIMIT {$limit}"
        );
        $st->execute([$videoId]);
        return $st->fetchAll() ?: [];
      }
      if ($channelId) {
        $st = db()->prepare(
          "SELECT a.*, u.username FROM content_articles a
           JOIN users u ON u.id = a.user_id
           WHERE a.channel_id = ? AND {$where}
           ORDER BY a.created_at DESC LIMIT {$limit}"
        );
        $st->execute([$channelId]);
        return $st->fetchAll() ?: [];
      }
      $st = db()->query(
        "SELECT a.*, u.username FROM content_articles a
         JOIN users u ON u.id = a.user_id
         WHERE {$where}
         ORDER BY a.created_at DESC LIMIT {$limit}"
      );
      return $st->fetchAll() ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }
}

if (!function_exists('content_articles_list_by_user')) {
  function content_articles_list_by_user(int $userId, int $limit = 50): array {
    content_articles_ensure_table();
    $limit = max(1, min(100, $limit));
    try {
      $st = db()->prepare(
        "SELECT a.*, c.title AS channel_title, c.slug AS channel_slug,
                v.title AS video_title, v.slug AS video_slug
         FROM content_articles a
         LEFT JOIN channels c ON c.id = a.channel_id
         LEFT JOIN videos v ON v.id = a.video_id
         WHERE a.user_id = ?
         ORDER BY a.created_at DESC LIMIT {$limit}"
      );
      $st->execute([$userId]);
      return $st->fetchAll() ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }
}

if (!function_exists('content_article_get')) {
  function content_article_get(int $id): ?array {
    content_articles_ensure_table();
    try {
      $st = db()->prepare(
        "SELECT a.*, u.username, u.avatar_url,
                c.title AS channel_title, c.slug AS channel_slug,
                v.title AS video_title, v.slug AS video_slug
         FROM content_articles a
         JOIN users u ON u.id = a.user_id
         LEFT JOIN channels c ON c.id = a.channel_id
         LEFT JOIN videos v ON v.id = a.video_id
         WHERE a.id = ? LIMIT 1"
      );
      $st->execute([$id]);
      $row = $st->fetch();
      return $row ?: null;
    } catch (Throwable $e) {
      return null;
    }
  }
}

if (!function_exists('content_article_create')) {
  function content_article_create(array $user, array $data): array {
    content_articles_ensure_table();
    if (is_file(__DIR__ . '/verified_moderation.php')) {
      require_once __DIR__ . '/verified_moderation.php';
    }
    if (empty($user['id'])) {
      return ['ok' => false, 'error' => 'Войдите в аккаунт'];
    }
    // rate limit soft
    if (function_exists('verified_rate_limit_ok')) {
      $rl = verified_rate_limit_ok($user, 'article');
      if (empty($rl['ok'])) {
        return ['ok' => false, 'error' => $rl['error'] ?? 'Лимит 24ч'];
      }
    }
    $title = trim((string)($data['title'] ?? ''));
    $body = trim((string)($data['body'] ?? ''));
    if ($title === '' || mb_strlen($title) < 2) {
      return ['ok' => false, 'error' => 'Укажите заголовок'];
    }
    if ($body === '' || mb_strlen($body) < 3) {
      return ['ok' => false, 'error' => 'Укажите текст статьи'];
    }
    $channelId = !empty($data['channel_id']) ? (int)$data['channel_id'] : null;
    $videoId = !empty($data['video_id']) ? (int)$data['video_id'] : null;
    $cover = trim((string)($data['cover_url'] ?? '')) ?: null;

    // ownership check
    if ($channelId) {
      try {
        $st = db()->prepare('SELECT owner_id FROM channels WHERE id = ? LIMIT 1');
        $st->execute([$channelId]);
        $ch = $st->fetch();
        $isAdmin = !empty($user['role']) && $user['role'] === 'admin';
        if (!$ch || ((int)$ch['owner_id'] !== (int)$user['id'] && !$isAdmin)) {
          return ['ok' => false, 'error' => 'Нет доступа к каналу'];
        }
      } catch (Throwable $e) {
        return ['ok' => false, 'error' => 'Ошибка канала'];
      }
    }

    $status = (!empty($user['role']) && $user['role'] === 'admin') ? 'published' : 'pending';
    if (function_exists('user_is_admin') && user_is_admin($user)) {
      $status = 'published';
    }
    // verified still pending until 24h visit (per previous logic)
    try {
      $st = db()->prepare(
        'INSERT INTO content_articles (user_id, channel_id, video_id, title, body, cover_url, status)
         VALUES (?,?,?,?,?,?,?)'
      );
      $st->execute([(int)$user['id'], $channelId, $videoId, $title, $body, $cover, $status]);
      return ['ok' => true, 'id' => (int)db()->lastInsertId(), 'status' => $status];
    } catch (Throwable $e) {
      return ['ok' => false, 'error' => 'БД: ' . $e->getMessage()];
    }
  }
}

if (!function_exists('content_article_delete')) {
  function content_article_delete(int $id, array $user): array {
    content_articles_ensure_table();
    if (empty($user['id'])) return ['ok' => false, 'error' => 'Войдите'];
    try {
      $st = db()->prepare('SELECT * FROM content_articles WHERE id = ? LIMIT 1');
      $st->execute([$id]);
      $a = $st->fetch();
      if (!$a) return ['ok' => false, 'error' => 'Не найдено'];
      $isAdmin = !empty($user['role']) && $user['role'] === 'admin';
      if ((int)$a['user_id'] !== (int)$user['id'] && !$isAdmin) {
        return ['ok' => false, 'error' => 'Нет доступа'];
      }
      db()->prepare('DELETE FROM content_articles WHERE id = ?')->execute([$id]);
      return ['ok' => true];
    } catch (Throwable $e) {
      return ['ok' => false, 'error' => $e->getMessage()];
    }
  }
}

if (!function_exists('content_article_bump_views')) {
  function content_article_bump_views(int $id): void {
    try {
      db()->prepare('UPDATE content_articles SET views = views + 1 WHERE id = ?')->execute([$id]);
    } catch (Throwable $e) {}
  }
}
