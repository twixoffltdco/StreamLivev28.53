(function(root, factory) {
  const api = factory(root);

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  root.FlexVpnPremiumProxyGrant = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function(root) {
  'use strict';

  const DEFAULT_BASE_URL = 'https://api.clause.su';
  const ACCESS_EXPIRY_MARGIN_MS = 30 * 1000;
  const GRANT_EXPIRY_MARGIN_MS = 30 * 1000;
  const GRANT_FALLBACK_MARGIN_MS = 5 * 1000;
  const MAX_REFRESH_JITTER_MS = 2 * 60 * 1000;
  const ACCOUNT_ID_PATTERN = /^ACC-[A-Za-z0-9]{6,30}$/;
  const INSTALL_ID_PATTERN = /^[A-Za-z0-9_-]{16,128}$/;
  const APP_VERSION_PATTERN = /^\d+(?:\.\d+){2,3}$/;
  const EXTENSION_PLATFORM = 'extension';
  const UNIFIED_DEVICE_LIMIT_CAPABILITY = 'unified-device-limit-v1';
  const DEVICE_LIMIT_ERROR_CODE = 'device_limit_reached';
  const DEFAULT_DEVICE_LIMIT = 10;
  const MAX_DEVICE_LIMIT = 1000;
  const DEFAULT_MANAGE_DEVICES_URL = 'https://flexvpn.net/account#devices';
  const STORAGE_KEYS = Object.freeze({
    accessToken: 'flexvpnSiteAccessTokenV1',
    accessTokenExpiresAt: 'flexvpnSiteAccessTokenExpiresAtV1',
    refreshToken: 'flexvpnSiteRefreshTokenV1',
    refreshTokenExpiresAt: 'flexvpnSiteRefreshTokenExpiresAtV1',
    premiumGrant: 'flexvpnPremiumProxyGrantV1'
  });
  const ALL_AUTHORIZATION_KEYS = Object.freeze(Object.values(STORAGE_KEYS));

  function normalizeBaseUrl(value) {
    return String(value || DEFAULT_BASE_URL).replace(/\/+$/, '');
  }

  function resolveAppVersion(value) {
    let detected = value;
    if (
      !detected &&
      root &&
      root.chrome &&
      root.chrome.runtime &&
      typeof root.chrome.runtime.getManifest === 'function'
    ) {
      try {
        detected = root.chrome.runtime.getManifest().version;
      } catch (_error) {
        detected = '';
      }
    }
    const version = String(detected || '').trim();
    return APP_VERSION_PATTERN.test(version) ? version : '0.0.0';
  }

  function clientError(code, options = {}) {
    const error = new Error(code);
    error.code = code;
    error.status = Number(options.status || 0) || undefined;
    error.retryable = options.retryable === true;
    if (options.details && typeof options.details === 'object') {
      for (const key of ['deviceLimit', 'devicesUsed', 'manageDevicesUrl']) {
        if (Object.prototype.hasOwnProperty.call(options.details, key)) {
          error[key] = options.details[key];
        }
      }
    }
    return error;
  }

  function normalizePositiveInteger(value, fallback) {
    const number = Number(value);
    return Number.isInteger(number) && number >= 1 && number <= MAX_DEVICE_LIMIT
      ? number
      : fallback;
  }

  function normalizeDevicesUsed(value) {
    const number = Number(value);
    return Number.isInteger(number) && number >= 0 && number <= MAX_DEVICE_LIMIT
      ? number
      : undefined;
  }

  function normalizeManageDevicesUrl(value) {
    try {
      const url = new URL(String(value || ''));
      if (
        url.protocol === 'https:' &&
        url.hostname === 'flexvpn.net' &&
        !url.username &&
        !url.password &&
        (!url.port || url.port === '443')
      ) {
        return url.href;
      }
    } catch (_error) {}
    return DEFAULT_MANAGE_DEVICES_URL;
  }

  function normalizeDeviceLimitDetails(value = {}) {
    const deviceLimit = normalizePositiveInteger(value.deviceLimit, DEFAULT_DEVICE_LIMIT);
    const devicesUsed = normalizeDevicesUsed(value.devicesUsed);
    return Object.freeze({
      deviceLimit,
      ...(devicesUsed === undefined ? {} : { devicesUsed }),
      manageDevicesUrl: normalizeManageDevicesUrl(value.manageDevicesUrl)
    });
  }

  function parseExpiry(value) {
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) return value;
    const parsed = Date.parse(String(value || ''));
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }

  function publicGrant(record) {
    return Object.freeze({
      token: record.token,
      expiresAt: record.expiresAt,
      assurance: record.assurance
    });
  }

  function normalizeGrantRecord(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const token = typeof value.token === 'string' ? value.token.trim() : '';
    const expiresAt = Number(value.expiresAt);
    const refreshAt = Number(value.refreshAt);
    const assurance = value.assurance === 'site_authenticated' || value.assurance === 'legacy_account_id'
      ? value.assurance
      : '';
    if (
      !token ||
      token.length > 4096 ||
      !Number.isFinite(expiresAt) ||
      !Number.isFinite(refreshAt) ||
      !assurance
    ) {
      return null;
    }
    return Object.freeze({ token, expiresAt, refreshAt, assurance });
  }

  function storageError() {
    const lastError = root && root.chrome && root.chrome.runtime
      ? root.chrome.runtime.lastError
      : null;
    return lastError ? new Error(lastError.message || 'Chrome storage operation failed') : null;
  }

  function callStorage(area, method, argument) {
    if (!area || typeof area[method] !== 'function') {
      return Promise.reject(clientError('grant_service_unavailable', { retryable: true }));
    }
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        if (error) reject(error);
        else resolve(value);
      };
      const callback = (value) => finish(storageError(), value);
      try {
        const maybePromise = area[method](argument, callback);
        if (maybePromise && typeof maybePromise.then === 'function') {
          maybePromise.then((value) => finish(null, value), (error) => finish(error));
        }
      } catch (error) {
        finish(error);
      }
    });
  }

  async function readStorage(area, keys) {
    const result = await callStorage(area, 'get', keys);
    return result && typeof result === 'object' ? result : {};
  }

  async function writeStorage(area, values) {
    await callStorage(area, 'set', values);
  }

  async function removeStorage(area, keys) {
    await callStorage(area, 'remove', keys);
  }

  async function readResponseJson(response) {
    try {
      const value = await response.json();
      return value && typeof value === 'object' ? value : {};
    } catch (_error) {
      return {};
    }
  }

  function createClient(options = {}) {
    const fetchImpl = options.fetchImpl || (typeof fetch === 'function' ? fetch.bind(root) : null);
    const storage = options.storage || (root && root.chrome ? root.chrome.storage : null);
    const now = typeof options.now === 'function' ? options.now : Date.now;
    const random = typeof options.random === 'function' ? options.random : Math.random;
    const baseUrl = normalizeBaseUrl(options.baseUrl);
    const appVersion = resolveAppVersion(options.appVersion);
    if (typeof fetchImpl !== 'function') throw new Error('Fetch is required');
    if (!storage || !storage.session || !storage.local) throw new Error('Chrome session and local storage are required');

    let grantRefreshPromise = null;
    let grantRefreshIdentity = '';
    let accessRefreshPromise = null;

    function currentTime() {
      const value = Number(now());
      if (!Number.isFinite(value) || value < 0) {
        throw clientError('grant_service_unavailable', { retryable: true });
      }
      return value;
    }

    async function clearCachedGrant() {
      await Promise.all([
        removeStorage(storage.session, [STORAGE_KEYS.premiumGrant]),
        removeStorage(storage.local, [STORAGE_KEYS.premiumGrant])
      ]);
    }

    async function clearAuthorization() {
      await Promise.all([
        removeStorage(storage.session, ALL_AUTHORIZATION_KEYS),
        removeStorage(storage.local, ALL_AUTHORIZATION_KEYS)
      ]);
    }

    function buildTokenStorage(loginResult) {
      const value = loginResult || {};
      const timestamp = currentTime();
      const accessToken = typeof value.accessToken === 'string' ? value.accessToken.trim() : '';
      const refreshToken = typeof value.refreshToken === 'string' ? value.refreshToken.trim() : '';
      const accessExpiresIn = Number(value.accessTokenExpiresIn);
      const accessTokenExpiresAt = parseExpiry(value.accessTokenExpiresAt) || (
        Number.isFinite(accessExpiresIn) && accessExpiresIn > 0
          ? timestamp + (accessExpiresIn * 1000)
          : null
      );
      const refreshTokenExpiresAt = parseExpiry(value.refreshTokenExpiresAt);
      if (!accessToken || !accessTokenExpiresAt || !refreshToken || !refreshTokenExpiresAt) {
        throw clientError('unauthorized', { retryable: false });
      }
      return {
        session: {
          [STORAGE_KEYS.accessToken]: accessToken,
          [STORAGE_KEYS.accessTokenExpiresAt]: accessTokenExpiresAt
        },
        local: {
          [STORAGE_KEYS.refreshToken]: refreshToken,
          [STORAGE_KEYS.refreshTokenExpiresAt]: refreshTokenExpiresAt
        }
      };
    }

    async function persistSiteLogin(loginResult) {
      const records = buildTokenStorage(loginResult);
      await Promise.all([
        writeStorage(storage.session, records.session),
        writeStorage(storage.local, records.local),
        removeStorage(storage.session, [
          STORAGE_KEYS.refreshToken,
          STORAGE_KEYS.refreshTokenExpiresAt,
          STORAGE_KEYS.premiumGrant
        ]),
        removeStorage(storage.local, [
          STORAGE_KEYS.accessToken,
          STORAGE_KEYS.accessTokenExpiresAt,
          STORAGE_KEYS.premiumGrant
        ])
      ]);
    }

    async function readAuthorizationState() {
      const [sessionValues, localValues] = await Promise.all([
        readStorage(storage.session, [
          STORAGE_KEYS.accessToken,
          STORAGE_KEYS.accessTokenExpiresAt,
          STORAGE_KEYS.premiumGrant
        ]),
        readStorage(storage.local, [
          STORAGE_KEYS.refreshToken,
          STORAGE_KEYS.refreshTokenExpiresAt
        ])
      ]);
      return {
        accessToken: typeof sessionValues[STORAGE_KEYS.accessToken] === 'string'
          ? sessionValues[STORAGE_KEYS.accessToken]
          : '',
        accessTokenExpiresAt: Number(sessionValues[STORAGE_KEYS.accessTokenExpiresAt] || 0),
        refreshToken: typeof localValues[STORAGE_KEYS.refreshToken] === 'string'
          ? localValues[STORAGE_KEYS.refreshToken]
          : '',
        refreshTokenExpiresAt: Number(localValues[STORAGE_KEYS.refreshTokenExpiresAt] || 0),
        grant: normalizeGrantRecord(sessionValues[STORAGE_KEYS.premiumGrant])
      };
    }

    async function request(path, requestOptions = {}) {
      let response;
      try {
        response = await fetchImpl(`${baseUrl}${path}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(requestOptions.accessToken
              ? { Authorization: `Bearer ${requestOptions.accessToken}` }
              : {})
          },
          body: JSON.stringify(requestOptions.body || {})
        });
      } catch (_error) {
        throw clientError('grant_service_unavailable', { retryable: true });
      }
      return {
        status: Number(response.status || 0),
        ok: response.ok === true,
        data: await readResponseJson(response)
      };
    }

    function refreshSiteAccessToken() {
      if (accessRefreshPromise) return accessRefreshPromise;
      accessRefreshPromise = (async () => {
        const state = await readAuthorizationState();
        const timestamp = currentTime();
        if (
          !state.refreshToken ||
          state.refreshTokenExpiresAt <= timestamp + ACCESS_EXPIRY_MARGIN_MS
        ) {
          await clearAuthorization();
          throw clientError('unauthorized', { retryable: false });
        }

        const response = await request('/api/site/refresh', {
          body: { refreshToken: state.refreshToken }
        });
        if (response.status === 401 || response.status === 403) {
          await clearAuthorization();
          throw clientError('unauthorized', { status: response.status, retryable: false });
        }
        if (!response.ok) {
          throw clientError('grant_service_unavailable', {
            status: response.status,
            retryable: true
          });
        }
        await persistSiteLogin(response.data);
        return String(response.data.accessToken || '');
      })().finally(() => {
        accessRefreshPromise = null;
      });
      return accessRefreshPromise;
    }

    async function requestGrant(accountId, installId, cachedGrant) {
      let state = await readAuthorizationState();
      const timestamp = currentTime();
      let accessToken = state.accessToken &&
        state.accessTokenExpiresAt > timestamp + ACCESS_EXPIRY_MARGIN_MS
        ? state.accessToken
        : '';
      let refreshedAccess = false;
      let authorizationRefreshRejected = false;

      if (!accessToken && state.refreshToken &&
          state.refreshTokenExpiresAt > timestamp + ACCESS_EXPIRY_MARGIN_MS) {
        try {
          accessToken = await refreshSiteAccessToken();
          refreshedAccess = true;
          state = await readAuthorizationState();
        } catch (error) {
          if (!error || error.code !== 'unauthorized') throw error;
          authorizationRefreshRejected = true;
          accessToken = '';
        }
      }

      const extendedBody = Object.freeze({
        accountId,
        installId,
        platform: EXTENSION_PLATFORM,
        appVersion,
        capabilities: [UNIFIED_DEVICE_LIMIT_CAPABILITY]
      });
      const legacyBody = Object.freeze({ accountId, installId });
      let useLegacyBody = authorizationRefreshRejected;
      let legacyFallbackUsed = false;
      let authorizationFallbackUsed = authorizationRefreshRejected;
      const requestIssuer = async (token) => {
        let issuerResponse = await request('/api/site/premium-proxy-grant', {
          accessToken: token,
          body: useLegacyBody ? legacyBody : extendedBody
        });
        if (
          !useLegacyBody &&
          !legacyFallbackUsed &&
          issuerResponse.status === 400 &&
          issuerResponse.data.error === 'invalid_request'
        ) {
          legacyFallbackUsed = true;
          useLegacyBody = true;
          issuerResponse = await request('/api/site/premium-proxy-grant', {
            accessToken: token,
            body: legacyBody
          });
        }
        return issuerResponse;
      };
      const requestIssuerWithoutStaleAuthorization = async () => {
        if (authorizationFallbackUsed) return null;
        authorizationFallbackUsed = true;
        useLegacyBody = true;
        return request('/api/site/premium-proxy-grant', {
          body: legacyBody
        });
      };
      let response = await requestIssuer(accessToken);
      let responseUsedAuthorization = Boolean(accessToken);

      if (response.status === 401 && accessToken && !refreshedAccess) {
        try {
          accessToken = await refreshSiteAccessToken();
          refreshedAccess = true;
          response = await requestIssuer(accessToken);
          responseUsedAuthorization = Boolean(accessToken);
        } catch (error) {
          if (!error || error.code !== 'unauthorized') throw error;
          accessToken = '';
          response = await requestIssuerWithoutStaleAuthorization();
          responseUsedAuthorization = false;
        }
      }

      if (response.status === 401 && responseUsedAuthorization) {
        await clearAuthorization();
        response = await requestIssuerWithoutStaleAuthorization();
        responseUsedAuthorization = false;
      }

      if (
        response.status === 403 &&
        responseUsedAuthorization &&
        response.data.error !== DEVICE_LIMIT_ERROR_CODE
      ) {
        await clearCachedGrant();
        // The compatibility request omits only a stale site session. The issuer
        // still validates the current account entitlement before issuing a grant.
        response = await requestIssuerWithoutStaleAuthorization();
        responseUsedAuthorization = false;
      }

      if (response.status === 401) {
        await clearAuthorization();
        throw clientError('unauthorized', { status: 401, retryable: false });
      }
      if (response.status === 403) {
        await clearCachedGrant();
        if (response.data.error === DEVICE_LIMIT_ERROR_CODE) {
          throw clientError(DEVICE_LIMIT_ERROR_CODE, {
            status: 403,
            retryable: false,
            details: normalizeDeviceLimitDetails(response.data)
          });
        }
        throw clientError(
          response.data.error === 'legacy_grant_disabled'
            ? 'legacy_grant_disabled'
            : 'premium_required',
          { status: 403, retryable: false }
        );
      }
      if ([408, 425, 429].includes(response.status)) {
        throw clientError('grant_service_unavailable', {
          status: response.status,
          retryable: true
        });
      }
      if (response.status >= 400 && response.status < 500) {
        throw clientError('invalid_request', {
          status: response.status,
          retryable: false
        });
      }
      if (!response.ok) {
        throw clientError('grant_service_unavailable', {
          status: response.status,
          retryable: true
        });
      }

      const grantToken = typeof response.data.grant === 'string'
        ? response.data.grant.trim()
        : '';
      const expiresAt = Number(response.data.expiresAt);
      const refreshAfterSeconds = Number(response.data.refreshAfterSeconds);
      const assurance = response.data.assurance;
      if (
        response.data.success !== true ||
        !grantToken ||
        grantToken.length > 4096 ||
        !Number.isFinite(expiresAt) ||
        expiresAt <= timestamp + GRANT_FALLBACK_MARGIN_MS ||
        !Number.isFinite(refreshAfterSeconds) ||
        refreshAfterSeconds <= 0 ||
        (assurance !== 'site_authenticated' && assurance !== 'legacy_account_id')
      ) {
        throw clientError('grant_service_unavailable', { retryable: true });
      }

      const randomValue = Math.min(1, Math.max(0, Number(random()) || 0));
      const jitterMs = Math.floor(randomValue * MAX_REFRESH_JITTER_MS);
      const latestRefreshAt = Math.max(timestamp, expiresAt - GRANT_EXPIRY_MARGIN_MS);
      const refreshAt = Math.min(
        timestamp + (refreshAfterSeconds * 1000) + jitterMs,
        latestRefreshAt
      );
      const record = Object.freeze({
        token: grantToken,
        expiresAt,
        refreshAt,
        assurance
      });
      await writeStorage(storage.session, { [STORAGE_KEYS.premiumGrant]: record });
      await removeStorage(storage.local, [STORAGE_KEYS.premiumGrant]);
      return publicGrant(record);
    }

    async function performGrantRefresh(accountId, installId, cachedGrant) {
      try {
        return await requestGrant(accountId, installId, cachedGrant);
      } catch (error) {
        const timestamp = currentTime();
        if (
          error &&
          error.retryable === true &&
          cachedGrant &&
          cachedGrant.expiresAt > timestamp + GRANT_FALLBACK_MARGIN_MS
        ) {
          return publicGrant(cachedGrant);
        }
        throw error;
      }
    }

    async function getGrant(input = {}) {
      const accountId = String(input.accountId || '').trim();
      const installId = String(input.installId || '').trim();
      if (!ACCOUNT_ID_PATTERN.test(accountId) || !INSTALL_ID_PATTERN.test(installId)) {
        throw clientError('invalid_request', { retryable: false });
      }

      const state = await readAuthorizationState();
      const timestamp = currentTime();
      if (
        state.grant &&
        state.grant.expiresAt > timestamp + GRANT_EXPIRY_MARGIN_MS &&
        timestamp < state.grant.refreshAt
      ) {
        return publicGrant(state.grant);
      }

      const identity = `${accountId}\n${installId}`;
      if (grantRefreshPromise) {
        if (grantRefreshIdentity === identity) return grantRefreshPromise;
        try {
          await grantRefreshPromise;
        } catch (_error) {
          // A different account/install gets its own bounded attempt below.
        }
      }

      grantRefreshIdentity = identity;
      grantRefreshPromise = performGrantRefresh(accountId, installId, state.grant)
        .finally(() => {
          grantRefreshPromise = null;
          grantRefreshIdentity = '';
        });
      return grantRefreshPromise;
    }

    return Object.freeze({
      getGrant,
      clearCachedGrant,
      clearAuthorization,
      persistSiteLogin
    });
  }

  return Object.freeze({
    DEFAULT_BASE_URL,
    DEFAULT_DEVICE_LIMIT,
    DEFAULT_MANAGE_DEVICES_URL,
    DEVICE_LIMIT_ERROR_CODE,
    STORAGE_KEYS,
    createClient
  });
});
