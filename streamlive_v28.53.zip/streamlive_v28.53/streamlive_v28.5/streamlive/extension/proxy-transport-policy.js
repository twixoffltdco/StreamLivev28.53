(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.FlexVpnProxyTransportPolicy = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';

  const SUPPORTED_SCHEMES = new Set(['http', 'https']);
  const HOST_LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
  const SERVER_KEY = /^[a-z][a-z0-9_]{0,63}$/;

  function policyError(message) {
    const error = new Error(message);
    error.code = 'PROXY_TRANSPORT_POLICY_INVALID';
    return error;
  }

  function isPlainObject(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }

  function isValidPort(value) {
    return Number.isInteger(value) && value >= 1 && value <= 65535;
  }

  function isIpv4(host) {
    if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return false;
    return host.split('.').every((part) => {
      const number = Number(part);
      return Number.isInteger(number) && number >= 0 && number <= 255 && String(number) === part;
    });
  }

  function isPublicIpv4(host) {
    if (!isIpv4(host)) return false;
    const [a, b, c] = host.split('.').map(Number);
    return !(
      a === 0 ||
      a === 10 ||
      a === 127 ||
      a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 192 && b === 88 && c === 99) ||
      (a === 198 && (b === 18 || b === 19)) ||
      (a === 198 && b === 51 && c === 100) ||
      (a === 203 && b === 0 && c === 113)
    );
  }

  function isDnsHostname(host) {
    if (typeof host !== 'string' || host.length < 1 || host.length > 253) return false;
    if (host !== host.toLowerCase() || host.endsWith('.') || host.includes(':')) return false;
    const labels = host.split('.');
    return labels.every((label) => label.length >= 1 && label.length <= 63 && HOST_LABEL.test(label));
  }

  function normalizeSupportedProxySchemes(value) {
    if (value === undefined || value === null) return [];
    if (!Array.isArray(value)) throw policyError('Supported proxy schemes must be an array.');
    const result = [];
    for (const item of value) {
      if (typeof item !== 'string' || !SUPPORTED_SCHEMES.has(item)) {
        throw policyError('Unsupported proxy scheme capability.');
      }
      if (!result.includes(item)) result.push(item);
    }
    if (result.length > 2) throw policyError('Too many proxy scheme capabilities.');
    return result;
  }

  function validateFleetPolicy(policy) {
    if (!isPlainObject(policy)) throw policyError('HTTPS proxy fleet policy is invalid.');
    const requiredKeys = ['allowPublicIpv4', 'enabled', 'hostnamePrefix', 'hostnameSuffix', 'port'];
    const allowedKeys = new Set([
      ...requiredKeys,
      'httpsOnly',
      'ports',
      'supportedProxySchemes',
      'httpPort',
      'httpPorts',
      'allowLegacyAuthFallback',
      'serverKeys',
      'bootstrapServerKeys'
    ]);
    if (
      Object.keys(policy).some((key) => !allowedKeys.has(key)) ||
      requiredKeys.some((key) => !Object.prototype.hasOwnProperty.call(policy, key)) ||
      policy.enabled !== true || policy.allowPublicIpv4 !== true
    ) {
      throw policyError('HTTPS proxy fleet policy is disabled or invalid.');
    }
    if (
      policy.hostnamePrefix !== 'edge-' ||
      policy.hostnameSuffix !== '.noralvio.com' ||
      policy.port !== 443
    ) {
      throw policyError('HTTPS proxy fleet policy boundary is invalid.');
    }
    if (policy.httpsOnly !== undefined && typeof policy.httpsOnly !== 'boolean') {
      throw policyError('HTTPS-only fleet policy is invalid.');
    }
    if (policy.supportedProxySchemes !== undefined) {
      const supportedProxySchemes = normalizeSupportedProxySchemes(policy.supportedProxySchemes);
      if (
        supportedProxySchemes.length < 1 ||
        (policy.httpsOnly === true && (
          supportedProxySchemes.length !== 1 || supportedProxySchemes[0] !== 'https'
        ))
      ) {
        throw policyError('Fleet proxy scheme capability is invalid.');
      }
      if (supportedProxySchemes.includes('http')) {
        if (
          policy.httpPort !== 6443 ||
          !Array.isArray(policy.httpPorts) ||
          policy.httpPorts.length !== 1 ||
          policy.httpPorts[0] !== policy.httpPort
        ) {
          throw policyError('HTTP CONNECT fleet port boundary is invalid.');
        }
      }
    }
    if (
      policy.allowLegacyAuthFallback !== undefined &&
      typeof policy.allowLegacyAuthFallback !== 'boolean'
    ) {
      throw policyError('Legacy proxy auth fallback policy is invalid.');
    }
    if (policy.ports !== undefined) {
      if (
        !Array.isArray(policy.ports) ||
        policy.ports.length < 1 ||
        policy.ports.length > 4 ||
        new Set(policy.ports).size !== policy.ports.length ||
        policy.ports.some((port) => !isValidPort(port)) ||
        !policy.ports.includes(policy.port)
      ) {
        throw policyError('HTTPS fleet ports are invalid.');
      }
    }
    if (policy.serverKeys !== undefined) {
      if (
        !Array.isArray(policy.serverKeys) ||
        policy.serverKeys.length < 1 ||
        policy.serverKeys.length > 100 ||
        new Set(policy.serverKeys).size !== policy.serverKeys.length ||
        policy.serverKeys.some((key) => typeof key !== 'string' || !SERVER_KEY.test(key))
      ) {
        throw policyError('HTTPS fleet server keys are invalid.');
      }
    }
    if (policy.bootstrapServerKeys !== undefined) {
      if (
        !Array.isArray(policy.bootstrapServerKeys) ||
        policy.bootstrapServerKeys.length < 1 ||
        policy.bootstrapServerKeys.length > 100 ||
        new Set(policy.bootstrapServerKeys).size !== policy.bootstrapServerKeys.length ||
        policy.bootstrapServerKeys.some((key) => typeof key !== 'string' || !SERVER_KEY.test(key))
      ) {
        throw policyError('HTTPS fleet bootstrap server keys are invalid.');
      }
    }
    if (
      policy.httpsOnly === true &&
      (!Array.isArray(policy.serverKeys) || !Array.isArray(policy.bootstrapServerKeys))
    ) {
      throw policyError('HTTPS-only fleet server keys are missing.');
    }
    if (
      Array.isArray(policy.bootstrapServerKeys) &&
      policy.bootstrapServerKeys.some((key) => !policy.serverKeys.includes(key))
    ) {
      throw policyError('HTTPS fleet bootstrap keys must be supported server keys.');
    }
    return policy;
  }

  function isFleetDnsHostname(host) {
    if (!isDnsHostname(host) || isIpv4(host)) return false;
    if (!host.startsWith('edge-') || !host.endsWith('.noralvio.com')) return false;
    const labels = host.split('.');
    return labels.length === 3 && labels[0].length > 'edge-'.length &&
      labels[1] === 'noralvio' && labels[2] === 'com';
  }

  function isAllowedFleetHttpsHost(host, policy) {
    const fleetPolicy = validateFleetPolicy(policy);
    if (isPublicIpv4(host)) return fleetPolicy.allowPublicIpv4;
    return isFleetDnsHostname(host);
  }

  function normalizeV2ProxyEndpoint(value, policy) {
    if (!isPlainObject(value)) throw policyError('Proxy endpoint must be an object.');
    const keys = Object.keys(value).sort().join(',');
    if (keys !== 'host,port,scheme') throw policyError('Proxy endpoint shape is invalid.');
    if (!SUPPORTED_SCHEMES.has(value.scheme)) throw policyError('Proxy endpoint scheme is invalid.');
    if (!isValidPort(value.port)) throw policyError('Proxy endpoint port is invalid.');

    const fleetPolicy = validateFleetPolicy(policy);
    const declaredSchemes = normalizeSupportedProxySchemes(fleetPolicy.supportedProxySchemes);
    if (declaredSchemes.length > 0 && !declaredSchemes.includes(value.scheme)) {
      throw policyError('Proxy endpoint scheme is outside the fleet capability.');
    }

    if (value.scheme === 'http') {
      if (!isIpv4(value.host) && !isDnsHostname(value.host)) {
        throw policyError('HTTP proxy host is invalid.');
      }
      if (declaredSchemes.includes('http')) {
        const allowedPorts = Array.isArray(fleetPolicy.httpPorts)
          ? fleetPolicy.httpPorts
          : [fleetPolicy.httpPort];
        const allowedHost = isPublicIpv4(value.host) || isFleetDnsHostname(value.host);
        if (!allowedPorts.includes(value.port) || !allowedHost) {
          throw policyError('HTTP proxy endpoint is outside the fleet policy.');
        }
      }
      return Object.freeze({ scheme: 'http', host: value.host, port: value.port });
    }

    const allowedPorts = Array.isArray(fleetPolicy.ports)
      ? fleetPolicy.ports
      : [fleetPolicy.port];
    if (!allowedPorts.includes(value.port) || !isAllowedFleetHttpsHost(value.host, fleetPolicy)) {
      throw policyError('HTTPS proxy endpoint is outside the fleet policy.');
    }
    return Object.freeze({ scheme: 'https', host: value.host, port: value.port });
  }

  function assertNormalizedEndpoint(endpoint) {
    if (!isPlainObject(endpoint) || !SUPPORTED_SCHEMES.has(endpoint.scheme) || !isValidPort(endpoint.port)) {
      throw policyError('Normalized proxy endpoint is invalid.');
    }
    const validHost = endpoint.scheme === 'https'
      ? isPublicIpv4(endpoint.host) || isFleetDnsHostname(endpoint.host)
      : isIpv4(endpoint.host) || isDnsHostname(endpoint.host);
    if (!validHost) throw policyError('Normalized proxy host is invalid.');
  }

  function formatPacProxyDirective(endpoint) {
    assertNormalizedEndpoint(endpoint);
    const directive = endpoint.scheme === 'https' ? 'HTTPS' : 'PROXY';
    return `${directive} ${endpoint.host}:${endpoint.port}`;
  }

  function createFixedProxyServer(endpoint) {
    assertNormalizedEndpoint(endpoint);
    return Object.freeze({
      scheme: endpoint.scheme,
      host: endpoint.host,
      port: endpoint.port
    });
  }

  return Object.freeze({
    normalizeSupportedProxySchemes,
    normalizeV2ProxyEndpoint,
    formatPacProxyDirective,
    createFixedProxyServer
  });
});
