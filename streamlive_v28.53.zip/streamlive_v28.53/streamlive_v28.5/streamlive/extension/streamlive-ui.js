(() => {
  const DEFAULT_LIGHT = "00.jpg";
  const DEFAULT_DARK = "5.jpg";
  const COVER_KEY = "streamLiveCustomCover";

  const applyBackground = async () => {
    const data = await new Promise(resolve => {
      try {
        chrome.storage.local.get(["theme", COVER_KEY], resolve);
      } catch (_) {
        resolve({ theme: "light", [COVER_KEY]: null });
      }
    });
    const theme = data.theme || "light";
    const cover = data[COVER_KEY] || null;
    document.body.classList.toggle("dark-mode", theme === "dark");
    document.body.style.backgroundImage = cover ? `url("${cover}")` : `url("${theme === "dark" ? DEFAULT_DARK : DEFAULT_LIGHT}")`;
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";
    document.body.style.backgroundRepeat = "no-repeat";
    document.body.dataset.streamliveCustomCover = cover ? "1" : "0";
  };

  const hideLegacy = () => {
    document.querySelectorAll('[data-streamlive-legacy-premium="1"]').forEach(el => {
      el.style.display = "none";
    });
  };

  const init = () => {
    hideLegacy();
    const top = document.getElementById("streamlive-settings-top");
    const bottom = document.getElementById("settings-button");
    if (top && bottom && !top.dataset.streamliveBound) {
      top.dataset.streamliveBound = "1";
      top.addEventListener("click", () => bottom.click());
    }
    applyBackground();
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[COVER_KEY] || changes.theme) applyBackground();
    hideLegacy();
  });
})();
