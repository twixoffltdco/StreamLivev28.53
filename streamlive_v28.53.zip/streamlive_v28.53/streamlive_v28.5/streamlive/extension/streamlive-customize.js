(() => {
  const COVER_KEY = "streamLiveCustomCover";
  const MAX_FILE_BYTES = 6 * 1024 * 1024;
  const TARGET_MAX_BYTES = 900 * 1024;
  const MAX_W = 1400;
  const MAX_H = 900;
  let bound = false;

  const notify = (message, type = "error") => {
    try {
      if (typeof window.showNotification === "function") return window.showNotification(message, type);
    } catch (_) {}
    console.warn(`[StreamLive VPN] ${message}`);
  };

  const storageGet = keys => new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(keys, value => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message));
        resolve(value || {});
      });
    } catch (e) { reject(e); }
  });

  const storageSet = values => new Promise((resolve, reject) => {
    try {
      chrome.storage.local.set(values, () => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message));
        resolve();
      });
    } catch (e) { reject(e); }
  });

  const storageRemove = keys => new Promise((resolve, reject) => {
    try {
      chrome.storage.local.remove(keys, () => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message));
        resolve();
      });
    } catch (e) { reject(e); }
  });

  const render = value => {
    const preview = document.getElementById("streamlive-cover-preview");
    if (!preview) return;
    preview.hidden = !value;
    preview.style.backgroundImage = value ? `url("${value}")` : "none";
  };

  const blobToDataUrl = blob => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Не удалось прочитать изображение"));
    reader.onload = () => resolve(String(reader.result || ""));
    reader.readAsDataURL(blob);
  });

  async function prepareCover(file) {
    if (!(file instanceof File)) throw new Error("Файл не выбран");
    if (!/^image\/(png|jpeg|webp)$/i.test(file.type)) throw new Error("Поддерживаются PNG, JPEG и WebP");
    if (file.size > MAX_FILE_BYTES) throw new Error("Файл слишком большой (максимум 6 МБ)");

    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, MAX_W / bitmap.width, MAX_H / bitmap.height);
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("Не удалось подготовить изображение");
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close?.();

    let quality = 0.84;
    let blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", quality));
    while (blob && blob.size > TARGET_MAX_BYTES && quality > 0.5) {
      quality -= 0.08;
      blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", quality));
    }
    if (!blob) throw new Error("Не удалось сжать изображение");
    if (blob.size > TARGET_MAX_BYTES) throw new Error("Изображение всё ещё слишком большое");
    return blobToDataUrl(blob);
  }

  const bind = () => {
    const input = document.getElementById("streamlive-cover-input");
    const clear = document.getElementById("streamlive-cover-clear");
    if (!input || !clear || bound) return Boolean(input && clear);
    bound = true;

    storageGet([COVER_KEY]).then(data => render(data[COVER_KEY] || null)).catch(() => render(null));

    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const value = await prepareCover(file);
        await storageSet({ [COVER_KEY]: value });
        render(value);
        notify("Обложка сохранена", "success");
      } catch (e) {
        console.error("[StreamLive VPN] cover_save_failed", e);
        notify(e?.message || "Не удалось сохранить обложку", "error");
      } finally {
        input.value = "";
      }
    });

    clear.addEventListener("click", async () => {
      try {
        await storageRemove([COVER_KEY]);
        input.value = "";
        render(null);
        notify("Обложка убрана", "success");
      } catch (e) {
        notify(`Не удалось убрать обложку: ${e?.message || e}`, "error");
      }
    });
    return true;
  };

  const observer = new MutationObserver(() => bind());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  bind();
})();
