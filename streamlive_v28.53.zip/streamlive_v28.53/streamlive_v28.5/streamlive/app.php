<?php
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/pwa_config.php';
$name = pwa_app_name();
?><!DOCTYPE html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0d0d0d">
<link rel="manifest" href="/manifest.webmanifest.php">
<title><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></title>
<style>body{margin:0;background:#0d0d0d;color:#ccc;font-family:system-ui;min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column}</style>
</head><body>
<div style="font-size:40px">▶</div>
<h1><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></h1>
<p style="opacity:.6">Загрузка…</p>
<script src="/assets/js/pwa-app.js?v=6"></script>
<script>setTimeout(function(){try{StreamLivePWA&&StreamLivePWA.bootAsApp()}catch(e){}location.replace('/?from_app=1')},700)</script>
</body></html>
