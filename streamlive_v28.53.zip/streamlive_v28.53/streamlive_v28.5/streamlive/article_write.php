<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/content_articles.php';
if (is_file(__DIR__ . '/includes/verified_moderation.php')) {
  require_once __DIR__ . '/includes/verified_moderation.php';
}
$__user = require_login();
content_articles_ensure_table();

$channelId = (int)($_GET['channel_id'] ?? $_POST['channel_id'] ?? 0);
$videoId = (int)($_GET['video_id'] ?? $_POST['video_id'] ?? 0);
$coverDefault = trim((string)($_GET['cover'] ?? $_POST['cover_url'] ?? ''));

// доступ: владелец канала / автор видео
$allowed = false;
$back = '/';
if ($channelId > 0) {
  $st = db()->prepare('SELECT * FROM channels WHERE id = ?');
  $st->execute([$channelId]);
  $ch = $st->fetch();
  if ($ch && (int)$ch['owner_id'] === (int)$__user['id']) {
    $allowed = true;
    $back = '/channel_manage.php?id=' . $channelId;
    if ($coverDefault === '' && !empty($ch['logo_url'])) $coverDefault = $ch['logo_url'];
  }
}
if ($videoId > 0) {
  $st = db()->prepare('SELECT * FROM videos WHERE id = ?');
  $st->execute([$videoId]);
  $vid = $st->fetch();
  if ($vid && (int)$vid['user_id'] === (int)$__user['id']) {
    $allowed = true;
    $back = '/video.php?slug=' . urlencode($vid['slug']);
    if ($coverDefault === '' && !empty($vid['thumbnail_url'])) $coverDefault = $vid['thumbnail_url'];
    if (!$channelId) $channelId = (int)$vid['channel_id'];
  }
}
if (!$allowed && empty($__user['role'])) {
  http_response_code(403);
  exit('Нет доступа');
}
if (!$allowed && ($__user['role'] ?? '') === 'admin') $allowed = true;

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (function_exists('csrf_verify')) csrf_verify();
  $res = content_article_create($__user, [
    'title' => $_POST['title'] ?? '',
    'body' => $_POST['body'] ?? '',
    'channel_id' => $channelId ?: null,
    'video_id' => $videoId ?: null,
    'cover_url' => trim((string)($_POST['cover_url'] ?? '')) ?: $coverDefault,
  ]);
  if (!empty($res['ok'])) {
    if (($res['status'] ?? '') === 'published') {
      redirect('/article.php?id=' . (int)$res['id']);
    }
    $msg = 'Статья отправлена на модерацию.';
  } else {
    $msg = $res['error'] ?? 'Ошибка';
  }
}

$pageTitle = 'Написать статью';
require_once __DIR__ . '/includes/header.php';
echo '<style>.dzen-write{max-width:720px;margin:24px auto;padding:0 16px}.dzen-write h1{font-size:22px;margin:0 0 8px}.dzen-write .hint{color:var(--text-dim,#888);font-size:13px;margin:0 0 18px}.dzen-write input,.dzen-write textarea{width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:inherit;margin:6px 0 14px;font:inherit}.dzen-write textarea{min-height:220px;line-height:1.55}.dzen-write label{font-size:13px;opacity:.85}</style>';
?>
<div class="container" style="max-width:640px">
  <h1>Статья к <?= $videoId ? 'видео' : 'каналу' ?></h1>
  <?php if ($msg): ?><div class="alert"><?= e($msg) ?></div><?php endif; ?>
  <form method="post" action="/article_write.php">
    <?= function_exists('csrf_field') ? csrf_field() : '' ?>
    <input type="hidden" name="channel_id" value="<?= (int)$channelId ?>">
    <input type="hidden" name="video_id" value="<?= (int)$videoId ?>">
    <label>Заголовок</label>
    <input type="text" name="title" required maxlength="200" style="width:100%;padding:10px;margin:6px 0 12px">
    <label>Текст</label>
    <textarea name="body" required rows="12" style="width:100%;padding:10px;margin:6px 0 12px"></textarea>
    <label>Обложка (URL)</label>
    <input type="url" name="cover_url" value="<?= e($coverDefault) ?>" style="width:100%;padding:10px;margin:6px 0 12px">
    <button class="btn btn-primary" type="submit">Опубликовать</button>
    <a class="btn btn-outline" href="<?= e($back) ?>">Назад</a>
  <p class="hint">С галочкой: статья уйдёт на модерацию и опубликуется автоматически через 24 часа после вашего следующего захода на сайт. Без галочки — только после ручной модерации.</p>
</form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
