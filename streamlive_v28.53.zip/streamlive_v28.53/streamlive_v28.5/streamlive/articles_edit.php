<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/articles.php')) require_once __DIR__ . '/includes/articles.php';

$user = current_user();
if (!$user) { header('Location: /auth/login.php'); exit; }
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT * FROM articles WHERE id = ? AND user_id = ?');
$st->execute([$id, (int)$user['id']]);
$article = $st->fetch();
if (!$article) { http_response_code(404); echo 'Статья не найдена'; exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = trim((string)($_POST['title'] ?? ''));
  $subtitle = trim((string)($_POST['subtitle'] ?? ''));
  $content = (string)($_POST['content'] ?? '');
  $status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'published';
  if ($title === '' || $content === '') {
    $error = 'Заполните название и текст';
  } else {
    if (function_exists('articles_update')) {
      articles_update($id, [
        'title' => $title,
        'subtitle' => $subtitle,
        'content' => $content,
        'status' => $status,
      ]);
    } else {
      db()->prepare('UPDATE articles SET title=?, subtitle=?, content=?, status=? WHERE id=? AND user_id=?')
        ->execute([$title, $subtitle, $content, $status, $id, (int)$user['id']]);
    }
    header('Location: /platforma/studio/articles.php?updated=1');
    exit;
  }
}

$pageTitle = 'Редактирование статьи';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container" style="max-width:800px;margin:24px auto;padding:0 16px">
  <h1>Редактировать статью</h1>
  <?php if ($error): ?><p style="color:#f87171"><?= htmlspecialchars($error) ?></p><?php endif; ?>
  <form method="post">
    <p><label>Название<br><input name="title" style="width:100%;padding:10px" value="<?= htmlspecialchars((string)$article['title']) ?>"></label></p>
    <p><label>Подзаголовок<br><input name="subtitle" style="width:100%;padding:10px" value="<?= htmlspecialchars((string)($article['subtitle'] ?? '')) ?>"></label></p>
    <p><label>Текст<br><textarea name="content" rows="16" style="width:100%;padding:10px"><?= htmlspecialchars((string)$article['content']) ?></textarea></label></p>
    <p><label>Статус
      <select name="status">
        <option value="published" <?= ($article['status'] ?? '') === 'published' ? 'selected' : '' ?>>Опубликовано</option>
        <option value="draft" <?= ($article['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Черновик</option>
      </select>
    </label></p>
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="/platforma/studio/articles.php">Назад</a>
  </form>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
