<?php
/**
 * Cinema-лендинг: фон-плеер + title + desc + статьи + unmute.
 * iframe / ?cinema=0 / ?raw=1 / ?embed=1 / Sec-Fetch-Dest:iframe → чистый плеер.
 */
if (!function_exists('cinema_is_raw_player')) {
  function cinema_is_raw_player(): bool {
    if (isset($_GET['cinema']) && (string)$_GET['cinema'] === '0') return true;
    if (isset($_GET['raw']) && (string)$_GET['raw'] !== '0' && (string)$_GET['raw'] !== '') return true;
    if (isset($_GET['embed']) && (string)$_GET['embed'] === '1') return true;
    $dest = strtolower((string)($_SERVER['HTTP_SEC_FETCH_DEST'] ?? ''));
    if ($dest === 'iframe' || $dest === 'embed') return true;
    return false;
  }
}

if (!function_exists('cinema_render_page')) {
  function cinema_render_page(array $opt): void {
    $title = (string)($opt['title'] ?? '');
    $desc = trim((string)($opt['description'] ?? ''));
    $primary = (string)($opt['primary_url'] ?? '/');
    $player = (string)($opt['player_html'] ?? '');
    $articles = $opt['articles'] ?? [];
    $badge = (string)($opt['badge'] ?? '');
    $now = (string)($opt['now_line'] ?? '');
    $site = defined('SITE_NAME') ? (string)SITE_NAME : 'StreamLive';
    header('Content-Type: text/html; charset=utf-8');
    ?><!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars($site, ENT_QUOTES, 'UTF-8') ?></title>
<style>
*{box-sizing:border-box}
html,body{margin:0;padding:0;min-height:100%;background:#05070d;color:#f4f6fb;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.cin-bg{position:fixed;inset:0;z-index:0;overflow:hidden;background:#000}
.cin-bg iframe,.cin-bg video{position:absolute;inset:0;width:100%;height:100%;border:0;object-fit:cover}
.cin-bg:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(5,7,13,.35) 0%,rgba(5,7,13,.55) 40%,rgba(5,7,13,.96) 100%);pointer-events:none}
.cin-ui{position:relative;z-index:2;min-height:100vh;display:flex;flex-direction:column;justify-content:flex-end;padding:28px 22px 44px;max-width:960px;margin:0 auto}
.cin-badge{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;background:#e31c25;color:#fff;padding:5px 12px;border-radius:999px;margin-bottom:14px}
.cin-badge:before{content:"";width:6px;height:6px;border-radius:50%;background:#fff;box-shadow:0 0 0 3px rgba(255,255,255,.25)}
.cin-title{font-size:clamp(28px,5vw,48px);font-weight:800;line-height:1.15;margin:0 0 12px;text-shadow:0 2px 24px rgba(0,0,0,.5)}
.cin-now{font-size:14px;opacity:.8;margin:0 0 16px}
.cin-desc{font-size:15px;line-height:1.55;opacity:.85;max-width:640px;margin:0 0 22px;white-space:pre-wrap}
.cin-actions{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px}
.cin-btn{appearance:none;border:0;cursor:pointer;font:inherit;font-weight:700;font-size:14px;padding:12px 18px;border-radius:999px;text-decoration:none;display:inline-flex;align-items:center;gap:8px;transition:transform .15s ease,background .15s ease}
.cin-btn:active{transform:scale(.98)}
.cin-btn-primary{background:#fff;color:#0b0b12}
.cin-btn-primary:hover{background:#e8e8f0}
.cin-btn-ghost{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.14)}
.cin-btn-ghost:hover{background:rgba(255,255,255,.18)}
.cin-btn-sound{background:#a78bfa;color:#0b0b12}
.cin-btn-sound.is-on{background:#34d399}
.cin-art{margin-top:8px}
.cin-art h2{font-size:13px;text-transform:uppercase;letter-spacing:.06em;opacity:.65;margin:0 0 12px}
.cin-art-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
.cin-card{display:block;text-decoration:none;color:inherit;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden;transition:background .15s}
.cin-card:hover{background:rgba(255,255,255,.1)}
.cin-card img{width:100%;aspect-ratio:16/9;object-fit:cover;display:block;background:#111}
.cin-card .t{padding:10px 12px;font-size:13px;font-weight:600;line-height:1.35}
.cin-empty{font-size:13px;opacity:.5}
.cin-tap{position:fixed;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;pointer-events:none}
.cin-tap-hint{pointer-events:none;background:rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.15);backdrop-filter:blur(8px);padding:14px 20px;border-radius:999px;font-size:14px;font-weight:600;opacity:0;transition:opacity .3s}
.cin-tap-hint.show{opacity:1}
</style>
</head>
<body>
<div class="cin-bg" id="cinBg"><?= $player ?></div>
<div class="cin-tap"><div class="cin-tap-hint" id="cinTapHint">Нажмите «Звук», чтобы включить аудио</div></div>
<div class="cin-ui">
  <?php if ($badge !== ''): ?><div class="cin-badge"><?= htmlspecialchars($badge, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  <h1 class="cin-title"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
  <?php if ($now !== ''): ?><div class="cin-now"><?= $now ?></div><?php endif; ?>
  <?php if ($desc !== ''): ?><div class="cin-desc"><?= nl2br(htmlspecialchars(mb_substr($desc, 0, 600), ENT_QUOTES, 'UTF-8')) ?><?= mb_strlen($desc) > 600 ? '…' : '' ?></div><?php endif; ?>

  <div class="cin-actions">
    <button type="button" class="cin-btn cin-btn-sound" id="cinUnmute" style="display:none!important" aria-pressed="false">🔊 Включить звук</button>
    <button type="button" class="cin-btn cin-btn-ghost" id="cinPlayPause">⏸ Пауза</button>
    <a class="cin-btn cin-btn-primary" href="<?= htmlspecialchars($primary, ENT_QUOTES, 'UTF-8') ?>">Смотреть на <?= htmlspecialchars($site, ENT_QUOTES, 'UTF-8') ?></a>
    <a class="cin-btn cin-btn-ghost" href="#articles">Статьи</a>
  </div>

  <div class="cin-art" id="articles">
    <h2>Статьи</h2>
    <?php if (!$articles): ?>
      <p class="cin-empty">Пока нет опубликованных статей</p>
    <?php else: ?>
      <div class="cin-art-grid">
        <?php foreach ($articles as $a):
          $aid = (int)($a['id'] ?? 0);
          $href = '/article.php?id=' . $aid;
          $cov = trim((string)($a['cover_url'] ?? ''));
          ?>
        <a class="cin-card" href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">
          <?php if ($cov !== ''): ?><img src="<?= htmlspecialchars($cov, ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy"><?php endif; ?>
          <div class="t"><?= htmlspecialchars((string)($a['title'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
        </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<script>
(function(){
  var bg = document.getElementById('cinBg');
  var unmuteBtn = document.getElementById('cinUnmute');
  var ppBtn = document.getElementById('cinPlayPause');
  var hint = document.getElementById('cinTapHint');
  var muted = false;
  var playing = true;

  function mediaEls(){
    var list = [];
    if (!bg) return list;
    bg.querySelectorAll('video').forEach(function(v){ list.push(v); });
    // iframe: postMessage best-effort for youtube-like
    bg.querySelectorAll('iframe').forEach(function(f){ list.push(f); });
    return list;
  }

  function setMuted(m){
    muted = m;
    mediaEls().forEach(function(el){
      if (el.tagName === 'VIDEO') {
        try { el.muted = m; if (!m) { el.volume = 1; el.play().catch(function(){}); } } catch(e){}
      } else if (el.tagName === 'IFRAME' && el.contentWindow) {
        try {
          // YouTube / generic
          el.contentWindow.postMessage(JSON.stringify({event:'command', func: m ? 'mute' : 'unMute', args:[]}), '*');
          el.contentWindow.postMessage(JSON.stringify({event:'command', func: m ? 'mute' : 'unMute'}), '*');
        } catch(e){}
      }
    });
    if (unmuteBtn) {
      unmuteBtn.textContent = m ? '🔊 Включить звук' : '🔇 Без звука';
      unmuteBtn.classList.toggle('is-on', !m);
      unmuteBtn.setAttribute('aria-pressed', m ? 'false' : 'true');
    }
    if (hint) {
      if (m) { hint.classList.add('show'); setTimeout(function(){ hint.classList.remove('show'); }, 3200); }
      else hint.classList.remove('show');
    }
  }

  function setPlaying(p){
    playing = p;
    mediaEls().forEach(function(el){
      if (el.tagName === 'VIDEO') {
        try { if (p) el.play().catch(function(){}); else el.pause(); } catch(e){}
      } else if (el.tagName === 'IFRAME' && el.contentWindow) {
        try {
          el.contentWindow.postMessage(JSON.stringify({event:'command', func: p ? 'playVideo' : 'pauseVideo', args:[]}), '*');
        } catch(e){}
      }
    });
    if (ppBtn) ppBtn.textContent = p ? '⏸ Пауза' : '▶️ Play';
  }

  // start muted autoplay-friendly
  setTimeout(function(){ setMuted(false); setPlaying(true); if (hint) { hint.classList.add('show'); setTimeout(function(){ hint.classList.remove('show'); }, 3500); } }, 200);

  if (unmuteBtn) unmuteBtn.addEventListener('click', function(){ setMuted(!muted); });
  if (ppBtn) ppBtn.addEventListener('click', function(){ setPlaying(!playing); });
})();
</script>
</body>
</html><?php
    exit;
  }
}
