<?php
/**
 * Подключать из includes/resources.php или resource.php
 */
if (!function_exists('resource_render_author_badge')) {
  function resource_render_author_badge(array $r, int $size = 22): string {
    $uid = (int)($r['author_id'] ?? $r['user_id'] ?? 0);
    $user = [
      'id' => $uid,
      'username' => (string)($r['username'] ?? ''),
      'avatar' => $r['avatar'] ?? null,
      'prefix_id' => $r['prefix_id'] ?? null,
      'username_css' => $r['username_css'] ?? null,
      'is_verified' => $r['is_verified'] ?? 0,
    ];
    $pfxHtml = '';
    if (function_exists('user_get_prefixes_for_user')) {
      $list = user_get_prefixes_for_user($user);
      if (function_exists('prefix_pawno_render_html')) {
        $bits = [];
        foreach ($list as $p) {
          $bits[] = prefix_pawno_render_html($p);
        }
        $pfxHtml = $bits ? '<span class="user-prefixes">' . implode(' ', $bits) . '</span> ' : '';
      } elseif (function_exists('user_render_prefixes_html')) {
        $pfxHtml = user_render_prefixes_html($list);
      }
    }
    if (function_exists('render_user_badge')) {
      // badge may include prefixes — if so still ok
      return $pfxHtml . render_user_badge($user, $size);
    }
    $name = htmlspecialchars((string)$user['username'], ENT_QUOTES, 'UTF-8');
    return $pfxHtml . '<a href="/profile?username=' . rawurlencode((string)$user['username']) . '">' . $name . '</a>';
  }
}
