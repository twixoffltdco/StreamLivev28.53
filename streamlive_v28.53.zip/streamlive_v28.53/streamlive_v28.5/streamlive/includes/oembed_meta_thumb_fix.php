<?php
/**
 * Подключи ПОСЛЕ oembed_meta.php и thumbnail_proxy_fix.php
 * oembed_http_raw → через video_http_get (прокси), потом добор thumbnail.
 */
if (!function_exists('oembed_http_raw_direct')) {
  // wrap
}
if (function_exists('oembed_fetch_meta') && function_exists('sl_enrich_meta_thumbnail')) {
  if (!function_exists('oembed_fetch_meta_original_sl')) {
    // can't rename easily — provide enhanced entry
  }
}

if (!function_exists('oembed_fetch_meta_full')) {
  function oembed_fetch_meta_full(string $url): array {
    if (function_exists('oembed_fetch_meta')) {
      $m = oembed_fetch_meta($url);
    } else {
      $m = ['title' => '', 'description' => '', 'thumbnail_url' => '', 'tags' => ''];
    }
    // если oembed ходил напрямую без прокси — подтянем HTML через video_http_get
    if (empty($m['thumbnail_url']) && function_exists('video_http_get')) {
      $html = video_http_get($url);
      if ($html) {
        $m = sl_enrich_meta_thumbnail($m, $url, $html);
      }
    } elseif (function_exists('sl_enrich_meta_thumbnail')) {
      $m = sl_enrich_meta_thumbnail($m, $url);
    }
    return $m;
  }
}

/** oembed_http_raw через NETWORK_PROXY если есть video_http_get */
if (function_exists('video_http_get')) {
  // override by redefining is not possible; callers should use video_http_get
}
