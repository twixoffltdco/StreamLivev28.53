<?php
if (is_file(__DIR__ . '/prefix_pawno_banners.php')) {
  require_once __DIR__ . '/prefix_pawno_banners.php';
}
