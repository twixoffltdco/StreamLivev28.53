<?php
/** Очистка HTML из MediaWiki / Wikipedia / Ruwiki */
function streampedia_clean_mediawiki_html(string $html): string {
  // вырезать скрипты/стили
  $html = preg_replace('#<script\b[^>]*>[\s\S]*?</script>#iu', '', $html);
  $html = preg_replace('#<style\b[^>]*>[\s\S]*?</style>#iu', '', $html);
  // edit sections, metadata
  $html = preg_replace('#<span[^>]*class="[^"]*mw-editsection[^"]*"[^>]*>[\s\S]*?</span>#iu', '', $html);
  $html = preg_replace('#<div[^>]*class="[^"]*(?:navbox|sistersitebox|metadata|noprint|mw-references-wrap|reflist|catlinks|printfooter|mw-hidden-catlinks)[^"]*"[^>]*>[\s\S]*?</div>#iu', '', $html);
  // reference superscripts clutter
  $html = preg_replace('#<sup[^>]*class="[^"]*reference[^"]*"[^>]*>[\s\S]*?</sup>#iu', '', $html);
  // empty anchors
  $html = preg_replace('#<a\b[^>]*>\s*</a>#iu', '', $html);
  // table of contents from MW — уберём, свой TOC построим
  $html = preg_replace('#<div[^>]*id="toc"[^>]*>[\s\S]*?</div>#iu', '', $html);
  // data-mw attributes noise - strip most attributes from tags except href/src/alt/colspan/rowspan
  $html = preg_replace_callback('#<([a-z0-9]+)(\s[^>]*)?>#iu', function ($m) {
    $tag = strtolower($m[1]);
    $attrs = $m[2] ?? '';
    if ($attrs === '') return '<' . $tag . '>';
    $keep = [];
    if (preg_match('#\bhref=("|\')(.*?)\1#iu', $attrs, $h)) $keep[] = 'href=' . $h[1] . $h[2] . $h[1];
    if (preg_match('#\bsrc=("|\')(.*?)\1#iu', $attrs, $h)) $keep[] = 'src=' . $h[1] . $h[2] . $h[1];
    if (preg_match('#\balt=("|\')(.*?)\1#iu', $attrs, $h)) $keep[] = 'alt=' . $h[1] . $h[2] . $h[1];
    if (preg_match('#\bcolspan=("|\')(.*?)\1#iu', $attrs, $h)) $keep[] = 'colspan=' . $h[1] . $h[2] . $h[1];
    if (preg_match('#\browspan=("|\')(.*?)\1#iu', $attrs, $h)) $keep[] = 'rowspan=' . $h[1] . $h[2] . $h[1];
    // infobox class keep
    if (preg_match('#\bclass=("|\')([^"\']*infobox[^"\']*)\1#iu', $attrs, $h)) {
      $keep[] = 'class="sp-mw-infobox"';
    }
    if (in_array($tag, ['br', 'hr', 'img'], true)) {
      return '<' . $tag . ($keep ? ' ' . implode(' ', $keep) : '') . '>';
    }
    return '<' . $tag . ($keep ? ' ' . implode(' ', $keep) : '') . '>';
  }, $html);
  // normalize <br> variants, collapse many br
  $html = preg_replace('#<br\s*/?>#iu', "\n", $html);
  $html = preg_replace("/\n{3,}/", "\n\n", $html);
  // convert leftover newlines inside block to spaces carefully - wrap plain lines
  // strip empty tags
  $html = preg_replace('#<(p|div|span)>\s*</\1>#iu', '', $html);
  // decode double-escaped entities sometimes
  $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  // if content still has literal &lt;br&gt;
  $html = str_replace(['&lt;br&gt;', '&lt;br/&gt;', '&lt;br /&gt;', '&lt;BR&gt;'], "\n", $html);
  $html = preg_replace('#\n{3,}#', "\n\n", $html);
  // paragraphs: split by double newline if no block tags
  if (stripos($html, '<p') === false && stripos($html, '<h') === false) {
    $parts = preg_split('/\n\s*\n/', trim($html));
    $out = '';
    foreach ($parts as $p) {
      $p = trim($p);
      if ($p === '') continue;
      $out .= '<p>' . nl2br($p, false) . '</p>';
    }
    $html = $out !== '' ? $out : $html;
  } else {
    // inside text nodes collapse &lt;br&gt; already done; fix <p>\n sequences
    $html = preg_replace('#</p>\s*<p>#iu', "</p>\n<p>", $html);
  }
  return trim($html);
}

function streampedia_import_mediawiki(string $url): ?array {
  if (!preg_match('#https?://([^/]+)/(?:wiki|w)/(.+)#i', $url, $g)
      && !preg_match('#https?://([^/]+)/wiki/(.+)#i', $url, $g)) {
    return null;
  }
  $host = $g[1];
  $title = urldecode(str_replace('_', ' ', preg_replace('#^wiki/#i', '', $g[2])));
  $title = preg_replace('#\?.*$#', '', $title);

  $apiCandidates = [
    'https://' . $host . '/w/api.php',
    'https://' . $host . '/api.php',
  ];
  $ctx = stream_context_create([
    'http' => [
      'timeout' => 15,
      'header' => "User-Agent: StreamPediaBot/1.0 (import; +https://streamlive)\r\nAccept: application/json\r\n",
    ],
    'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
  ]);
  $data = null;
  foreach ($apiCandidates as $apiBase) {
    $api = $apiBase . '?action=parse&page=' . rawurlencode($title) . '&prop=text|displaytitle|wikitext&format=json&formatversion=2';
    $json = @file_get_contents($api, false, $ctx);
    if (!$json) {
      // try title with underscores
      $api = $apiBase . '?action=parse&page=' . rawurlencode(str_replace(' ', '_', $title)) . '&prop=text|displaytitle&format=json&formatversion=2';
      $json = @file_get_contents($api, false, $ctx);
    }
    if (!$json) continue;
    $data = json_decode($json, true);
    if (!empty($data['parse']['text'])) break;
    $data = null;
  }
  if (!$data || empty($data['parse']['text'])) return null;
  $body = is_array($data['parse']['text']) ? ($data['parse']['text']['*'] ?? '') : $data['parse']['text'];
  $body = streampedia_clean_mediawiki_html($body);
  $disp = $data['parse']['displaytitle'] ?? $title;
  $disp = html_entity_decode(strip_tags($disp), ENT_QUOTES, 'UTF-8');
  return ['title' => $disp, 'content' => $body, 'source' => $url];
}
