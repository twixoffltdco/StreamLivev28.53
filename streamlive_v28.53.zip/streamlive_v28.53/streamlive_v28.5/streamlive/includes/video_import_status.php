<?php
/** Подключить в video_import.php и использовать verified_video_status() */
if (is_file(__DIR__ . '/verified_moderation.php')) {
  require_once __DIR__ . '/verified_moderation.php';
}
