<?php
/**
 * Подключи в article.php СРАЗУ после require articles.php:
 *   require_once __DIR__ . '/includes/wallet.php';
 *   require_once __DIR__ . '/includes/wallet_pay.php';
 *   require_once __DIR__ . '/includes/article_buy_wallet_patch.php';
 *
 * ИЛИ замени POST buy-блок на вызов article_handle_wallet_buy().
 */

if (!function_exists('article_handle_wallet_buy')) {
  function article_handle_wallet_buy(array &$article, ?array $user, string $slug): array {
    $out = ['error' => null, 'success' => false, 'hasAccess' => false, 'canBuy' => false];
    if (!$user) {
      $out['error'] = 'Войдите, чтобы купить';
      return $out;
    }
    if ((int)($article['is_premium'] ?? 0) !== 1) {
      $out['hasAccess'] = true;
      return $out;
    }
    // автор
    if ((int)$user['id'] === (int)($article['user_id'] ?? 0)) {
      $out['hasAccess'] = true;
      $out['success'] = true;
      return $out;
    }
    if (!function_exists('wallet_pay_article_now')) {
      $out['error'] = 'Кошелёк не подключён (wallet_pay.php)';
      return $out;
    }
    $r = wallet_pay_article_now((int)$user['id'], $article);
    if (!empty($r['ok'])) {
      $out['success'] = true;
      $out['hasAccess'] = true;
      $out['canBuy'] = false;
      if (!empty($r['already'])) {
        // уже было
      }
      return $out;
    }
    $out['error'] = $r['error'] ?? 'Оплата не прошла';
    $out['canBuy'] = true;
    return $out;
  }
}
