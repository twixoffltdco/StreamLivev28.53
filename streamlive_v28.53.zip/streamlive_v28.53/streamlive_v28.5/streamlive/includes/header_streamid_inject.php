<?php
/** Подключать из header.php: require_once __DIR__.'/header_streamid_inject.php'; */
if (!empty($__user) && is_array($__user)) {
  if (is_file(__DIR__ . '/streamid_banner.php')) {
    require_once __DIR__ . '/streamid_banner.php';
    if (function_exists('streamid_header_banner')) {
      echo streamid_header_banner($__user);
    }
  }
}
