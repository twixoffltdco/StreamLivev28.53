<?php
require_once __DIR__ . '/vibe.php';

function vibe_render_reactions(int $postId, array $counts = [], ?string $my = null): string {
  $emojis = ['🔥','😂','👏','❤️','😮','🎉','👍'];
  $html = '<div class="vibe-react-bar" data-post-id="' . $postId . '">';
  foreach ($emojis as $em) {
    $c = (int)($counts[$em] ?? 0);
    $mine = ($my === $em) ? ' mine' : '';
    $html .= '<button type="button" class="vibe-react-btn' . $mine . '" data-vibe-react="' . htmlspecialchars($em, ENT_QUOTES) . '" data-post-id="' . $postId . '">'
      . $em . ($c ? ' ' . $c : '') . '</button>';
  }
  $html .= '</div>';
  return $html;
}

function vibe_render_achievements(int $userId): string {
  $list = vibe_user_achievements($userId);
  if (!$list) return '<p class="muted" style="font-size:13px">Ачивок пока нет — пиши, смотри, общайся.</p>';
  $html = '<div class="vibe-achievements">';
  foreach ($list as $a) {
    $html .= '<div class="vibe-ach" title="' . htmlspecialchars($a['desc'], ENT_QUOTES) . '"><span class="e">' . $a['emoji'] . '</span> ' . htmlspecialchars($a['title'], ENT_QUOTES) . '</div>';
  }
  $html .= '</div>';
  return $html;
}

function vibe_season_banner_html(): string {
  $f = vibe_active_frame();
  if (!$f) return '';
  return '<div class="vibe-season-banner">' . $f['emoji'] . ' Сейчас на платформе: <b>' . htmlspecialchars($f['title'], ENT_QUOTES) . '</b> — смотри рамки ников</div>';
}
