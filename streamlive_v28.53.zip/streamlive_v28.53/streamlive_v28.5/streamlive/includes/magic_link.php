<?php
function magic_link_ensure(): void {
  static $d = false; if ($d) return; $d = true;
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS auth_magic_links (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        email VARCHAR(190) NOT NULL,
        token CHAR(64) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        ip VARCHAR(45) NULL,
        KEY idx_user (user_id),
        KEY idx_exp (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
}

function magic_link_create(int $userId, string $email): ?string {
  magic_link_ensure();
  $token = bin2hex(random_bytes(32));
  $exp = date('Y-m-d H:i:s', time() + 1800);
  try {
    db()->prepare('INSERT INTO auth_magic_links (user_id, email, token, expires_at, ip) VALUES (?,?,?,?,?)')
      ->execute([$userId, $email, $token, $exp, $_SERVER['REMOTE_ADDR'] ?? null]);
    return $token;
  } catch (Throwable $e) {
    return null;
  }
}

function magic_link_consume(string $token): ?int {
  magic_link_ensure();
  try {
    $st = db()->prepare('SELECT * FROM auth_magic_links WHERE token=? LIMIT 1');
    $st->execute([$token]);
    $row = $st->fetch();
    if (!$row || !empty($row['used_at']) || strtotime($row['expires_at']) < time()) return null;
    db()->prepare('UPDATE auth_magic_links SET used_at=NOW() WHERE id=?')->execute([(int)$row['id']]);
    return (int)$row['user_id'];
  } catch (Throwable $e) {
    return null;
  }
}

function site_base_url(): string {
  if (defined('SITE_URL') && SITE_URL && strpos((string)SITE_URL, 'http') === 0) {
    return rtrim((string)SITE_URL, '/');
  }
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
  return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}
