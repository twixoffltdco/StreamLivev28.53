<?php
function forum_mod_compose_message(string $username, string $topicTitle, string $reason): string {
  $username = trim($username) !== '' ? $username : 'пользователь';
  $reason = trim($reason) !== '' ? $reason : 'нарушение правил раздела';
  return "Уважаемый(ая) {$username}!\n\n"
    . "В теме «{$topicTitle}» зафиксировано: {$reason}.\n"
    . "Просим придерживаться правил форума и не уходить в оффтоп.\n"
    . "При повторных нарушениях возможны ограничения доступа.\n\n"
    . "С уважением,\nкоманда проекта.";
}
