<?php
/**
 * require_once после partners.php / paid_access.php
 * Либо вставь extension_promo_mark_used() в конец partners_activate и paid_activate_code.
 */
if (is_file(__DIR__ . '/extension_promo_mark_used.php')) {
  require_once __DIR__ . '/extension_promo_mark_used.php';
}

/**
 * Обертка: если вызываете partners_activate — после успеха пометить SL-код.
 * Использование в partners/index.php после успешного activate:
 *   if (!empty($res['ok']) && function_exists('extension_promo_mark_used')) {
 *     extension_promo_mark_used($code, $userId);
 *   }
 */
