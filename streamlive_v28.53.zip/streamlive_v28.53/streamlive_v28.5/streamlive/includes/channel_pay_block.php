<?php
if (!isset($channel) || !is_array($channel)) return;
$uid = isset($user['id']) ? (int)$user['id'] : (function_exists('current_user') && current_user() ? (int)current_user()['id'] : 0);
$price = (float)($channel['price'] ?? $channel['premium_price'] ?? 0);
$isPaid = !empty($channel['is_paid']) || !empty($channel['is_premium']) || $price > 0;
if (!$isPaid || $price <= 0) return;
if ($uid && function_exists('wallet_has_channel_access') && wallet_has_channel_access($uid, (int)$channel['id'])) return;
if ($uid && (int)($channel['user_id'] ?? 0) === $uid) return;
$cur = htmlspecialchars((string)($channel['currency'] ?? 'RUB'), ENT_QUOTES);
$bal = ($uid && function_exists('wallet_balance')) ? wallet_balance($uid) : 0;
?>
<div class="sl-paywall" style="padding:20px;border-radius:14px;background:#1a1a22;border:1px solid rgba(251,191,36,.3);text-align:center;margin:12px 0">
  <h3>🔒 Платный канал (ТВ/радио)</h3>
  <p>Цена: <b><?= number_format($price, 2) ?> <?= $cur ?></b>
    <?php if ($uid): ?> · баланс: <b><?= number_format($bal, 2) ?> ₽</b><?php endif; ?></p>
  <?php if ($uid): ?>
  <form method="post" action="/channel_pay.php">
    <input type="hidden" name="channel_id" value="<?= (int)$channel['id'] ?>">
    <button type="submit" class="btn btn-primary">Оплатить с баланса</button>
  </form>
  <?php else: ?>
  <a href="/auth/login.php">Войдите</a>
  <?php endif; ?>
</div>
<?php
