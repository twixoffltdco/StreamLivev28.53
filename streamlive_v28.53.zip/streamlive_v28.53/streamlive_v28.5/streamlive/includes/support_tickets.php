<?php
/**
 * Тикеты поддержки (как InfinityFree): open/closed, шаблоны, без realtime.
 * Лёгкий код под хит-хостинг.
 */

function support_tickets_ensure(): void {
  static $done = false;
  if ($done) return;
  $done = true;
  try {
    db()->exec("CREATE TABLE IF NOT EXISTS support_tickets (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNSIGNED NOT NULL,
      subject VARCHAR(200) NOT NULL,
      category VARCHAR(64) NOT NULL DEFAULT 'general',
      status ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
      priority TINYINT NOT NULL DEFAULT 0,
      related_type VARCHAR(32) NULL,
      related_id INT UNSIGNED NULL,
      last_reply_at DATETIME NULL,
      closed_at DATETIME NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX (user_id), INDEX (status), INDEX (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } catch (Throwable $e) {}
  try {
    db()->exec("CREATE TABLE IF NOT EXISTS support_ticket_replies (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      ticket_id INT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      is_staff TINYINT(1) NOT NULL DEFAULT 0,
      body MEDIUMTEXT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX (ticket_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } catch (Throwable $e) {}
  try {
    db()->exec("CREATE TABLE IF NOT EXISTS support_templates (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(120) NOT NULL,
      body TEXT NOT NULL,
      sort_order INT NOT NULL DEFAULT 0,
      is_active TINYINT(1) NOT NULL DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } catch (Throwable $e) {}
  // дефолтные шаблоны
  try {
    $n = (int)db()->query('SELECT COUNT(*) FROM support_templates')->fetchColumn();
    if ($n === 0) {
      $defs = [
        ['Принято в работу', "Здравствуйте!\n\nМы приняли ваше обращение в работу. Ответим в ближайшее время.\n\nС уважением,\nКоманда поддержки"],
        ['Запрос доп. информации', "Здравствуйте!\n\nДля решения вопроса уточните, пожалуйста:\n1) ...\n2) ...\n\nС уважением,\nКоманда поддержки"],
        ['Вики возобновлена', "Здравствуйте!\n\nВики-проект проверен и возобновлён. Можете продолжать работу.\n\nС уважением,\nКоманда поддержки"],
        ['Отказ (правила)', "Здравствуйте!\n\nК сожалению, мы не можем удовлетворить запрос: он противоречит правилам платформы.\n\nС уважением,\nКоманда поддержки"],
        ['Тикет закрыт', "Здравствуйте!\n\nОбращение закрыто. Если вопрос останется актуальным — откройте новый тикет.\n\nС уважением,\nКоманда поддержки"],
      ];
      $st = db()->prepare('INSERT INTO support_templates (title, body, sort_order) VALUES (?,?,?)');
      $i = 0;
      foreach ($defs as $d) { $st->execute([$d[0], $d[1], $i++]); }
    }
  } catch (Throwable $e) {}
}

function support_is_staff(?array $user): bool {
  if (!$user) return false;
  $role = (string)($user['role'] ?? '');
  return in_array($role, ['admin', 'moderator', 'mod'], true);
}

function support_ticket_create(int $userId, string $subject, string $body, string $category = 'general', ?string $relatedType = null, ?int $relatedId = null): ?int {
  support_tickets_ensure();
  $subject = mb_substr(trim($subject), 0, 200);
  $body = trim($body);
  if ($subject === '' || $body === '') return null;
  try {
    db()->prepare(
      'INSERT INTO support_tickets (user_id, subject, category, status, related_type, related_id, last_reply_at)
       VALUES (?,?,?,?,?,?,NOW())'
    )->execute([$userId, $subject, mb_substr($category, 0, 64), 'open', $relatedType, $relatedId]);
    $tid = (int)db()->lastInsertId();
    db()->prepare(
      'INSERT INTO support_ticket_replies (ticket_id, user_id, is_staff, body) VALUES (?,?,0,?)'
    )->execute([$tid, $userId, $body]);
    return $tid;
  } catch (Throwable $e) {
    return null;
  }
}

function support_ticket_reply(int $ticketId, int $userId, string $body, bool $isStaff): bool {
  support_tickets_ensure();
  $body = trim($body);
  if ($body === '') return false;
  try {
    db()->prepare(
      'INSERT INTO support_ticket_replies (ticket_id, user_id, is_staff, body) VALUES (?,?,?,?)'
    )->execute([$ticketId, $userId, $isStaff ? 1 : 0, $body]);
    $status = $isStaff ? 'answered' : 'open';
    db()->prepare('UPDATE support_tickets SET status=?, last_reply_at=NOW() WHERE id=? AND status!=\'closed\'')
      ->execute([$status, $ticketId]);
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function support_ticket_set_status(int $ticketId, string $status): bool {
  support_tickets_ensure();
  if (!in_array($status, ['open', 'answered', 'closed'], true)) return false;
  try {
    if ($status === 'closed') {
      db()->prepare('UPDATE support_tickets SET status=?, closed_at=NOW() WHERE id=?')->execute([$status, $ticketId]);
    } else {
      db()->prepare('UPDATE support_tickets SET status=?, closed_at=NULL WHERE id=?')->execute([$status, $ticketId]);
    }
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function support_templates_list(): array {
  support_tickets_ensure();
  try {
    return db()->query('SELECT * FROM support_templates WHERE is_active=1 ORDER BY sort_order ASC, id ASC')->fetchAll() ?: [];
  } catch (Throwable $e) {
    return [];
  }
}

function support_status_label(string $s): string {
  return match ($s) {
    'open' => 'Открыт',
    'answered' => 'Есть ответ',
    'closed' => 'Закрыт',
    default => $s,
  };
}
