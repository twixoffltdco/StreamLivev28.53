<?php
if (!function_exists('current_user')) return;
$__gu = current_user();
if (!$__gu) {
  echo '<meta name="sl-platform" content="streamlive">' . "\n";
  return;
}
$__name = (string)($__gu['username'] ?? '');
$__id = (int)($__gu['id'] ?? 0);
$__av = (string)($__gu['avatar'] ?? $__gu['avatar_url'] ?? '');
echo '<meta name="sl-platform" content="streamlive">' . "\n";
echo '<meta name="sl-username" content="' . htmlspecialchars($__name, ENT_QUOTES, 'UTF-8') . '">' . "\n";
echo '<meta name="sl-user-id" content="' . $__id . '">' . "\n";
if ($__av !== '') {
  echo '<meta name="sl-avatar" content="' . htmlspecialchars($__av, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}
echo '<script>window.__USER=' . json_encode([
  'id' => $__id,
  'username' => $__name,
  'avatar' => $__av,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';window.__STREAMLIVE__=1;</script>' . "\n";
