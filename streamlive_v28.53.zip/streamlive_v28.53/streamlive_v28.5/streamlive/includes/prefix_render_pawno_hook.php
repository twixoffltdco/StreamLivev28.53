<?php
/**
 * Подключать ПОСЛЕ user_display.php
 * Подменяет отображение префиксов на Pawno-баннеры.
 */
if (!is_file(__DIR__ . '/prefix_pawno_banners.php')) {
  return;
}
require_once __DIR__ . '/prefix_pawno_banners.php';

if (!function_exists('user_render_prefix_html_original') && function_exists('user_render_prefix_html')) {
  // не можем переименовать уже объявленную — оборачиваем через user_render_prefixes_html path
}

/**
 * Единая точка: всегда Pawno-баннер.
 * Вызывайте prefix_display_html() из шаблонов; также патчим через
 * user_render_prefix_html только если функция ещё не объявлена.
 */
if (!function_exists('user_render_prefix_html')) {
  function user_render_prefix_html(?array $prefix): string {
    return prefix_pawno_render_html($prefix);
  }
}

if (!function_exists('user_render_prefixes_html')) {
  function user_render_prefixes_html(array $prefixes): string {
    if (!$prefixes) {
      return '';
    }
    $parts = [];
    foreach ($prefixes as $p) {
      $h = prefix_pawno_render_html(is_array($p) ? $p : null);
      if ($h !== '') {
        $parts[] = $h;
      }
    }
    if (!$parts) {
      return '';
    }
    return '<span class="user-prefixes">' . implode(' ', $parts) . '</span> ';
  }
}

/** Если user_render_prefix_html уже есть — даём alias */
if (!function_exists('prefix_display_html')) {
  function prefix_display_html(?array $prefix): string {
    if (function_exists('prefix_pawno_render_html')) {
      return prefix_pawno_render_html($prefix);
    }
    if (function_exists('user_render_prefix_html')) {
      return user_render_prefix_html($prefix);
    }
    return htmlspecialchars((string)($prefix['title'] ?? ''), ENT_QUOTES, 'UTF-8');
  }
}
