<?php
/**
 * Подключи ПОСЛЕ user_display.php (или вместо, если функций нет).
 * Чинит: старый столбец `color`, CSS, text_color/bg_color — как на форуме.
 */
if (!function_exists('user_render_prefix_html')) {
  function user_render_prefix_html(?array $prefix): string {
    if (!$prefix || !is_array($prefix)) return '';
    $title = htmlspecialchars((string)($prefix['title'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($title === '') return '';
    $custom = trim((string)($prefix['css'] ?? ''));
    if ($custom !== '') {
      $custom = preg_replace('/[<>]|expression|javascript/i', '', $custom) ?? '';
      return '<span class="user-prefix xf-prefix" style="' . htmlspecialchars($custom, ENT_QUOTES) . '">' . $title . '</span>';
    }
    $tc = (string)($prefix['text_color'] ?? '');
    $bg = (string)($prefix['bg_color'] ?? '');
    // старый формат admin: только color
    if ($bg === '' && !empty($prefix['color'])) {
      $bg = (string)$prefix['color'];
    }
    if ($tc === '') $tc = '#ffffff';
    if ($bg === '') $bg = '#6366f1';
    $tc = htmlspecialchars($tc, ENT_QUOTES);
    $bg = htmlspecialchars($bg, ENT_QUOTES);
    return '<span class="user-prefix xf-prefix" style="display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;font-weight:700;line-height:1.4;color:'
      . $tc . ';background:' . $bg . ';margin-right:4px;vertical-align:middle">' . $title . '</span>';
  }
} else {
  // переопределяем через обёртку нельзя — патчим поведение копией с другим именем + alias
}

/** Автор с префиксами как на форуме */
if (!function_exists('user_author_with_prefixes_html')) {
  function user_author_with_prefixes_html(array $userRow): string {
    $html = '';
    if (function_exists('user_get_prefixes_for_user')) {
      $prefs = user_get_prefixes_for_user($userRow);
      if ($prefs && function_exists('user_render_prefixes_html')) {
        $html .= user_render_prefixes_html($prefs);
      } elseif ($prefs) {
        foreach ($prefs as $p) {
          $html .= user_render_prefix_html($p);
        }
      }
    } elseif (!empty($userRow['prefix_id']) && function_exists('user_get_prefix')) {
      $p = user_get_prefix((int)$userRow['prefix_id']);
      $html .= user_render_prefix_html($p);
    }
    $name = htmlspecialchars((string)($userRow['username'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if (function_exists('user_render_username_html') && !empty($userRow['id'])) {
      return $html . user_render_username_html($userRow);
    }
    return $html . $name;
  }
}
