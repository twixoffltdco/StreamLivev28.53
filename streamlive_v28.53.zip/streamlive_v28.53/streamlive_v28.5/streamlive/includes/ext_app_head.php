<?php
?>
<script src="/assets/js/ext-app-banner.js?v=3" defer></script>
