<?php
/**
 * Минимальный бут админ/мод БЕЗ header.php (он часто даёт 500).
 */
declare(strict_types=1);

if (!defined('SL_PANEL_BOOT')) {
  define('SL_PANEL_BOOT', 1);
}

$__root = dirname(__DIR__);

// session
if (session_status() !== PHP_SESSION_ACTIVE) {
  try { @session_start(); } catch (Throwable $e) {}
}

// config + db
foreach ([$__root . '/config.php', $__root . '/includes/config.php'] as $cfg) {
  if (is_file($cfg)) {
    try { require_once $cfg; } catch (Throwable $e) {}
  }
}
foreach ([$__root . '/includes/functions.php', $__root . '/includes/db.php'] as $f) {
  if (is_file($f)) {
    try { require_once $f; } catch (Throwable $e) {
      // continue
    }
  }
}
if (is_file($__root . '/includes/auth.php')) {
  try { require_once $__root . '/includes/auth.php'; } catch (Throwable $e) {}
}

function panel_user(): ?array {
  try {
    if (function_exists('current_user')) {
      return current_user();
    }
  } catch (Throwable $e) {}
  if (empty($_SESSION['user_id']) || !function_exists('db')) return null;
  try {
    $st = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $st->execute([(int)$_SESSION['user_id']]);
    return $st->fetch() ?: null;
  } catch (Throwable $e) {
    return null;
  }
}

function panel_is_admin(?array $u): bool {
  if (!$u) return false;
  $role = strtolower((string)($u['role'] ?? ''));
  if ($role === 'admin') return true;
  if (!empty($u['is_admin'])) return true;
  if ((int)($u['id'] ?? 0) === 1) return true;
  return false;
}

function panel_is_mod(?array $u): bool {
  if (panel_is_admin($u)) return true;
  if (!$u) return false;
  $role = strtolower((string)($u['role'] ?? ''));
  if (in_array($role, ['moderator', 'mod', 'admin'], true)) return true;
  if (!empty($u['is_moderator'])) return true;
  return false;
}

function panel_html_start(string $title): void {
  if (!headers_sent()) {
    header('Content-Type: text/html; charset=utf-8');
  }
  echo '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">';
  echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
  echo '<title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title>';
  echo '<style>
  body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#0b0b0f;color:#e5e7eb}
  .wrap{display:flex;min-height:100vh}
  .side{width:220px;background:#111827;padding:16px;flex-shrink:0}
  .side a{display:block;color:#93c5fd;text-decoration:none;padding:8px 0;font-size:14px}
  .side a:hover{color:#fff}
  .main{flex:1;padding:20px 24px}
  h1,h2{margin-top:0}
  .card{background:#111827;border:1px solid #1f2937;border-radius:12px;padding:14px;margin:10px 0}
  .err{color:#fca5a5;background:#450a0a;padding:10px;border-radius:8px}
  .ok{color:#86efac}
  table{width:100%;border-collapse:collapse}
  td,th{border:1px solid #333;padding:8px;text-align:left;font-size:13px}
  button,.btn{background:#2563eb;color:#fff;border:0;padding:8px 12px;border-radius:8px;cursor:pointer}
  @media(max-width:700px){.wrap{flex-direction:column}.side{width:auto}}
  </style></head><body><div class="wrap">';
}

function panel_html_end(): void {
  echo '</div></body></html>';
}

function panel_count(string $sql): int {
  try {
    if (!function_exists('db')) return 0;
    return (int)db()->query($sql)->fetchColumn();
  } catch (Throwable $e) {
    return 0;
  }
}
