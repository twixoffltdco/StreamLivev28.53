<?php
/**
 * Функции для работы со статьями и подпиской PLUS
 * StreamLife Core
 */

// Гарантируем подключение зависимостей
if (!function_exists('db')) {
    if (file_exists(__DIR__ . '/db.php')) {
        require_once __DIR__ . '/db.php';
    }
}
if (!function_exists('antibot_client_ip')) {
    if (file_exists(__DIR__ . '/antibot.php')) {
        require_once __DIR__ . '/antibot.php';
    }
}

// Создаём таблицы статей при первом запуске
function articles_ensure_schema(): void {
  try {
    db()->exec(file_get_contents(__DIR__ . '/../sql/migrations/063_articles.sql'));
  } catch (\Throwable $e) {
    // Таблицы уже могут существовать — это нормально
  }
}

// Создаём slug из заголовка
function articles_make_slug(string $title): string {
  $s = mb_strtolower($title);
  $s = preg_replace('/[^\p{L}\p{N}]+/u', '-', $s);
  $s = trim($s, '-');
  if ($s === '') $s = 'article';
  return mb_substr($s, 0, 60) . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
}

// Подсчёт просмотров с одного IP (только 1 раз)
function articles_track_view(int $articleId): void {
  try {
    articles_ensure_schema();
    $ip = function_exists('antibot_client_ip') ? antibot_client_ip() : ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $userId = $_SESSION['user_id'] ?? null;
    // 1 просмотр = 1 IP на статью (как «открыл страницу с этого IP»)
    $st = db()->prepare('INSERT IGNORE INTO article_views (article_id, ip, user_id) VALUES (?, ?, ?)');
    $st->execute([$articleId, $ip, $userId]);
    // ВАЖНО: rowCount() у statement, не у db() — из-за этого просмотры не считались
    if ($st->rowCount() > 0) {
      db()->prepare('UPDATE articles SET views_count = views_count + 1 WHERE id = ?')->execute([$articleId]);
    }
  } catch (Throwable $e) {
    // fallback: просто +1 без уникальности, если таблицы views нет
    try {
      db()->prepare('UPDATE articles SET views_count = views_count + 1 WHERE id = ?')->execute([$articleId]);
    } catch (Throwable $e2) {}
  }
}

// Проверка активной подписки PLUS у пользователя
function plus_is_active(?int $userId): bool {
  if (!$userId) return false;
  try {
    articles_ensure_schema(); //确保表存在
    $stmt = db()->prepare('SELECT id FROM plus_subscriptions WHERE user_id = ? AND status = \'active\' AND expires_at > NOW()');
    $stmt->execute([$userId]);
    return (bool)$stmt->fetch();
  } catch (\Throwable $e) {
    return false;
  }
}

// Активация/продление подписки PLUS на 14 дней
function plus_activate(int $userId): bool {
  try {
    articles_ensure_schema();
    $now = date('Y-m-d H:i:s');
    $expires = date('Y-m-d H:i:s', strtotime('+14 days'));
    
    // Проверяем, есть ли активная подписка
    $stmt = db()->prepare('SELECT id, expires_at FROM plus_subscriptions WHERE user_id = ? AND status = \'active\'');
    $stmt->execute([$userId]);
    $existing = $stmt->fetch();
    
    if ($existing) {
      // Продлеваем текущую подписку
      $newExpires = strtotime($existing['expires_at']) > time() 
        ? date('Y-m-d H:i:s', strtotime($existing['expires_at'] . ' +14 days'))
        : $expires;
      
      db()->prepare('UPDATE plus_subscriptions SET expires_at = ?, last_checkin = ? WHERE user_id = ?')
        ->execute([$newExpires, $now, $userId]);
    } else {
      // Создаём новую подписку
      db()->prepare('INSERT INTO plus_subscriptions (user_id, status, started_at, expires_at, last_checkin) VALUES (?, \'active\', ?, ?, ?)')
        ->execute([$userId, $now, $expires, $now]);
    }
    
    return true;
  } catch (\Throwable $e) {
    return false;
  }
}

// Проверка и продление подписки за ежедневный вход (раз в 30 дней)
function plus_check_daily_login(int $userId): void {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare('SELECT last_checkin, expires_at FROM plus_subscriptions WHERE user_id = ? AND status = \'active\'');
    $stmt->execute([$userId]);
    $sub = $stmt->fetch();
    
    $now = time();
    $shouldActivate = false;
    
    if (!$sub) {
      // Подписки нет — активируем
      $shouldActivate = true;
    } elseif ($sub['last_checkin']) {
      // Последняя проверка была больше 30 дней назад
      $lastCheck = strtotime($sub['last_checkin']);
      if (($now - $lastCheck) >= (30 * 24 * 60 * 60)) {
        $shouldActivate = true;
      }
    } else {
      // last_checkin NULL — активируем
      $shouldActivate = true;
    }
    
    if ($shouldActivate) {
      plus_activate($userId);
    }
  } catch (\Throwable $e) {
    // Игнорируем ошибки
  }
}

// Получить количество платных подписчиков автора
function plus_get_author_subscribers_count(int $authorId): int {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare('SELECT COUNT(*) FROM author_plus_stats WHERE author_id = ?');
    $stmt->execute([$authorId]);
    return (int)$stmt->fetchColumn();
  } catch (\Throwable $e) {
    return 0;
  }
}

// Подписаться на автора (для статистики)
function plus_subscribe_to_author(int $authorId, int $subscriberId): bool {
  try {
    articles_ensure_schema();
    db()->prepare('INSERT IGNORE INTO author_plus_stats (author_id, subscriber_id) VALUES (?, ?)')
      ->execute([$authorId, $subscriberId]);
    
    // Обновляем счётчик у автора
    $count = plus_get_author_subscribers_count($authorId);
    db()->prepare('UPDATE users SET plus_subscribers_count = ? WHERE id = ?')
      ->execute([$count, $authorId]);
    
    return true;
  } catch (\Throwable $e) {
    return false;
  }
}

// Статистика подписок для автора
function plus_get_author_stats(int $authorId): array {
  try {
    articles_ensure_schema();
    $pdo = db();
    
    // Общее количество подписчиков
    $totalSubscribers = (int)$pdo->prepare('SELECT COUNT(*) FROM author_plus_stats WHERE author_id = ?')
      ->execute([$authorId]) && $pdo->fetchColumn();
    
    // Топ подписчиков (по дате подписки)
    $stmt = $pdo->prepare(
      'SELECT aps.subscribed_at, u.username, u.avatar 
       FROM author_plus_stats aps
       JOIN users u ON u.id = aps.subscriber_id
       WHERE aps.author_id = ?
       ORDER BY aps.subscribed_at DESC
       LIMIT 20'
    );
    $stmt->execute([$authorId]);
    $topSubscribers = $stmt->fetchAll() ?: [];
    
    // Динамика подписок по дням (за последние 30 дней)
    $stmt = $pdo->prepare(
      'SELECT DATE(subscribed_at) AS d, COUNT(*) AS new_subs
       FROM author_plus_stats
       WHERE author_id = ? AND subscribed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY DATE(subscribed_at)
       ORDER BY d ASC'
    );
    $stmt->execute([$authorId]);
    $dailySubs = $stmt->fetchAll() ?: [];
    
    return [
      'total_subscribers' => $totalSubscribers,
      'top_subscribers' => $topSubscribers,
      'daily_subs' => $dailySubs,
    ];
  } catch (\Throwable $e) {
    return [
      'total_subscribers' => 0,
      'top_subscribers' => [],
      'daily_subs' => [],
    ];
  }
}

// Получить статью по slug
function articles_get_by_slug(string $slug): ?array {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare('SELECT * FROM articles WHERE slug = ? AND status = \'published\'');
    $stmt->execute([$slug]);
    return $stmt->fetch() ?: null;
  } catch (\Throwable $e) {
    return null;
  }
}

// Получить все опубликованные статьи
function articles_get_all(int $limit = 20, int $offset = 0): array {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare(
      'SELECT a.*, u.username, u.avatar 
       FROM articles a 
       JOIN users u ON u.id = a.user_id 
       WHERE a.status = \'published\' 
       ORDER BY a.published_at DESC, a.created_at DESC 
       LIMIT ? OFFSET ?'
    );
    $stmt->execute([$limit, $offset]);
    return $stmt->fetchAll() ?: [];
  } catch (\Throwable $e) {
    return [];
  }
}

// Получить статьи пользователя
function articles_get_by_user(int $userId, int $limit = 50): array {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare(
      'SELECT * FROM articles WHERE user_id = ? ORDER BY created_at DESC LIMIT ?'
    );
    $stmt->execute([$userId, $limit]);
    return $stmt->fetchAll() ?: [];
  } catch (\Throwable $e) {
    return [];
  }
}

// Лайкнуть статью (один раз от пользователя)
function articles_toggle_like(int $articleId, int $userId): bool {
  try {
    articles_ensure_schema();
    
    // Проверяем, лайкнул ли уже
    $stmt = db()->prepare('SELECT id FROM article_likes WHERE article_id = ? AND user_id = ?');
    $stmt->execute([$articleId, $userId]);
    $existing = $stmt->fetch();
    
    if ($existing) {
      // Убираем лайк
      db()->prepare('DELETE FROM article_likes WHERE article_id = ? AND user_id = ?')
        ->execute([$articleId, $userId]);
      db()->prepare('UPDATE articles SET likes_count = GREATEST(0, likes_count - 1) WHERE id = ?')
        ->execute([$articleId]);
      return false; // лайк убран
    } else {
      // Ставим лайк
      db()->prepare('INSERT INTO article_likes (article_id, user_id) VALUES (?, ?)')
        ->execute([$articleId, $userId]);
      db()->prepare('UPDATE articles SET likes_count = likes_count + 1 WHERE id = ?')
        ->execute([$articleId]);
      return true; // лайк поставлен
    }
  } catch (\Throwable $e) {
    return false;
  }
}

// Добавить комментарий к статье
function articles_add_comment(int $articleId, int $userId, string $content, ?int $parentId = null): int {
  try {
    articles_ensure_schema();
    $content = trim($content);
    if ($content === '') return 0;
    
    db()->prepare(
      'INSERT INTO article_comments (article_id, user_id, parent_id, content) VALUES (?, ?, ?, ?)'
    )->execute([$articleId, $userId, $parentId, $content]);
    
    $commentId = (int)db()->lastInsertId();
    
    // Увеличиваем счётчик комментариев
    db()->prepare('UPDATE articles SET comments_count = comments_count + 1 WHERE id = ?')
      ->execute([$articleId]);
    
    return $commentId;
  } catch (\Throwable $e) {
    return 0;
  }
}

// Получить комментарии к статье
function articles_get_comments(int $articleId, int $limit = 100): array {
  try {
    articles_ensure_schema();
    $stmt = db()->prepare(
      'SELECT c.*, u.username, u.avatar 
       FROM article_comments c 
       JOIN users u ON u.id = c.user_id 
       WHERE c.article_id = ? AND c.is_deleted = 0 
       ORDER BY c.created_at ASC 
       LIMIT ?'
    );
    $stmt->execute([$articleId, $limit]);
    return $stmt->fetchAll() ?: [];
  } catch (\Throwable $e) {
    return [];
  }
}

// Создать статью
function articles_create(int $userId, ?int $channelId, string $title, string $subtitle, string $content, ?string $coverImage, string $status = 'published', int $isPremium = 0, float $premiumPrice = 0.0, string $premiumCurrency = 'RUB'): ?int {
  try {
    articles_ensure_schema();
    $slug = articles_make_slug($title);
    $publishedAt = ($status === 'published') ? date('Y-m-d H:i:s') : null;
    
    db()->prepare(
      'INSERT INTO articles (user_id, channel_id, slug, title, subtitle, content, cover_image, status, published_at, is_premium, premium_price, premium_currency)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([$userId, $channelId, $slug, $title, $subtitle, $content, $coverImage, $status, $publishedAt, $isPremium, $premiumPrice, $premiumCurrency]);
    
    return (int)db()->lastInsertId();
  } catch (\Throwable $e) {
    return null;
  }
}

// Обновить статью
function articles_update(int $articleId, array $data): bool {
  try {
    articles_ensure_schema();
    $allowed = ['title', 'subtitle', 'content', 'cover_image', 'status'];
    $sets = [];
    $params = [];
    
    foreach ($allowed as $field) {
      if (isset($data[$field])) {
        $sets[] = "$field = ?";
        $params[] = $data[$field];
      }
    }
    
    if (isset($data['status']) && $data['status'] === 'published') {
      $sets[] = 'published_at = COALESCE(published_at, ?)';
      $params[] = date('Y-m-d H:i:s');
    }
    
    if (!$sets) return false;
    
    $sets[] = 'updated_at = CURRENT_TIMESTAMP';
    $params[] = $articleId;
    
    $sql = 'UPDATE articles SET ' . implode(', ', $sets) . ' WHERE id = ?';
    db()->prepare($sql)->execute($params);
    
    return true;
  } catch (\Throwable $e) {
    return false;
  }
}

// Удалить статью
function articles_delete(int $articleId): bool {
  try {
    articles_ensure_schema();
    db()->prepare('DELETE FROM articles WHERE id = ?')->execute([$articleId]);
    return true;
  } catch (\Throwable $e) {
    return false;
  }
}

// Статистика статей для студии
function articles_get_stats(int $userId): array {
  try {
    articles_ensure_schema();
    $pdo = db();
    
    $totalArticles = (int)$pdo->prepare('SELECT COUNT(*) FROM articles WHERE user_id = ?')
      ->execute([$userId]) && $pdo->fetchColumn();
    
    $totalViews = (int)$pdo->prepare('SELECT COALESCE(SUM(views_count), 0) FROM articles WHERE user_id = ?')
      ->execute([$userId]) && $pdo->fetchColumn();
    
    $totalLikes = (int)$pdo->prepare('SELECT COALESCE(SUM(likes_count), 0) FROM articles WHERE user_id = ?')
      ->execute([$userId]) && $pdo->fetchColumn();
    
    $totalComments = (int)$pdo->prepare('SELECT COALESCE(SUM(comments_count), 0) FROM articles WHERE user_id = ?')
      ->execute([$userId]) && $pdo->fetchColumn();
    
    // Просмотры по дням
    $stmt = $pdo->prepare(
      'SELECT DATE(av.created_at) AS d, COUNT(DISTINCT av.article_id) AS articles_read, COUNT(*) AS views
       FROM article_views av
       JOIN articles a ON a.id = av.article_id
       WHERE a.user_id = ? AND av.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY DATE(av.created_at)
       ORDER BY d ASC'
    );
    $stmt->execute([$userId]);
    $dailyStats = $stmt->fetchAll() ?: [];
    
    // Топ статей
    $stmt = $pdo->prepare(
      'SELECT id, title, views_count, likes_count, comments_count, created_at 
       FROM articles 
       WHERE user_id = ? 
       ORDER BY views_count DESC 
       LIMIT 10'
    );
    $stmt->execute([$userId]);
    $topArticles = $stmt->fetchAll() ?: [];
    
    return [
      'total_articles' => $totalArticles,
      'total_views' => $totalViews,
      'total_likes' => $totalLikes,
      'total_comments' => $totalComments,
      'daily_stats' => $dailyStats,
      'top_articles' => $topArticles,
    ];
  } catch (\Throwable $e) {
    return [
      'total_articles' => 0,
      'total_views' => 0,
      'total_likes' => 0,
      'total_comments' => 0,
      'daily_stats' => [],
      'top_articles' => [],
    ];
  }
}
