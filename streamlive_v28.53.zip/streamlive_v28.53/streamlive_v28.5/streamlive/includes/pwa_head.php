<?php
/** Старый PWA head: больше НЕ предлагает установку как приложение. Только баннер расширения. */
if (is_file(__DIR__ . '/ext_app_head.php')) {
  require_once __DIR__ . '/ext_app_head.php';
  return;
}
?>
<script src="/assets/js/pwa-app.js?v=off1" defer></script>
<script src="/assets/js/ext-app-banner.js?v=2" defer></script>
