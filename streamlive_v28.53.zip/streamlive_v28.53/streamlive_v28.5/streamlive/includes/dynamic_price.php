<?php
/**
 * Динамическая цена от просмотров / подписчиков / лайков.
 *
 * База: premium_price / price из записи.
 * Итог = base * (1 + k_views + k_likes + k_subs) в пределах min/max.
 *
 * Настройки в options (или константы ниже).
 */
if (!function_exists('dyn_price_settings')) {
  function dyn_price_settings(): array {
    static $s = null;
    if ($s !== null) return $s;
    $defaults = [
      'enabled' => 1,
      // +% за каждые N просмотров
      'views_step' => 1000,      // каждые 1000 просмотров
      'views_pct' => 5,          // +5%
      // +% за каждые N лайков
      'likes_step' => 100,
      'likes_pct' => 3,
      // каналы: +% за подписчиков
      'subs_step' => 50,
      'subs_pct' => 4,
      // потолок / пол
      'max_multiplier' => 3.0,   // не больше x3 от базы
      'min_multiplier' => 1.0,   // не ниже базы (можно 0.8 если нужно дешеветь)
      // опционально: чуть дешеветь если мало просмотров? выкл
      'decay_enabled' => 0,
    ];
    try {
      if (function_exists('db')) {
        $st = db()->query("SELECT k, v FROM options WHERE k LIKE 'dyn_price_%'");
        if ($st) {
          foreach ($st->fetchAll() as $row) {
            $key = preg_replace('/^dyn_price_/', '', (string)$row['k']);
            if ($key !== '' && array_key_exists($key, $defaults)) {
              $defaults[$key] = is_numeric($row['v']) ? $row['v'] + 0 : $row['v'];
            }
          }
        }
      }
    } catch (Throwable $e) {}
    return $s = $defaults;
  }
}

if (!function_exists('dyn_price_pick_views')) {
  function dyn_price_pick_views(array $row): int {
    foreach (['views', 'views_count', 'view_count', 'hits', 'plays'] as $k) {
      if (isset($row[$k])) return max(0, (int)$row[$k]);
    }
    return 0;
  }
}
if (!function_exists('dyn_price_pick_likes')) {
  function dyn_price_pick_likes(array $row): int {
    foreach (['likes', 'likes_count', 'like_count'] as $k) {
      if (isset($row[$k])) return max(0, (int)$row[$k]);
    }
    return 0;
  }
}
if (!function_exists('dyn_price_pick_subs')) {
  function dyn_price_pick_subs(array $row): int {
    foreach (['subscribers', 'subscribers_count', 'followers', 'followers_count'] as $k) {
      if (isset($row[$k])) return max(0, (int)$row[$k]);
    }
    return 0;
  }
}

if (!function_exists('dyn_price_base')) {
  function dyn_price_base(array $row): float {
    foreach (['premium_price', 'price', 'paid_price'] as $k) {
      if (isset($row[$k]) && (float)$row[$k] > 0) return (float)$row[$k];
    }
    return 0.0;
  }
}

/**
 * @return array{price:float,base:float,multiplier:float,views:int,likes:int,subs:int,enabled:bool}
 */
if (!function_exists('dyn_price_calc')) {
  function dyn_price_calc(array $row, string $type = 'video'): array {
    $cfg = dyn_price_settings();
    $base = dyn_price_base($row);
    $views = dyn_price_pick_views($row);
    $likes = dyn_price_pick_likes($row);
    $subs = $type === 'channel' ? dyn_price_pick_subs($row) : 0;

    if (!(int)$cfg['enabled'] || $base <= 0) {
      return [
        'price' => $base,
        'base' => $base,
        'multiplier' => 1.0,
        'views' => $views,
        'likes' => $likes,
        'subs' => $subs,
        'enabled' => false,
      ];
    }

    $mult = 1.0;
    $vStep = max(1, (int)$cfg['views_step']);
    $mult += (floor($views / $vStep) * ((float)$cfg['views_pct'] / 100.0));

    $lStep = max(1, (int)$cfg['likes_step']);
    $mult += (floor($likes / $lStep) * ((float)$cfg['likes_pct'] / 100.0));

    if ($type === 'channel') {
      $sStep = max(1, (int)$cfg['subs_step']);
      $mult += (floor($subs / $sStep) * ((float)$cfg['subs_pct'] / 100.0));
    }

    $minM = (float)$cfg['min_multiplier'];
    $maxM = (float)$cfg['max_multiplier'];
    if ($mult < $minM) $mult = $minM;
    if ($mult > $maxM) $mult = $maxM;

    $price = round($base * $mult, 2);
    if ($price < 0.01 && $base > 0) $price = $base;

    return [
      'price' => $price,
      'base' => $base,
      'multiplier' => round($mult, 4),
      'views' => $views,
      'likes' => $likes,
      'subs' => $subs,
      'enabled' => true,
    ];
  }
}

/** Применить к массиву статьи/видео/канала перед оплатой */
if (!function_exists('dyn_price_apply_row')) {
  function dyn_price_apply_row(array $row, string $type = 'video'): array {
    $c = dyn_price_calc($row, $type);
    // для wallet_pay: подменяем premium_price / price на динамическую
    if ($c['price'] > 0) {
      if (isset($row['premium_price'])) $row['premium_price'] = $c['price'];
      if (isset($row['price']) || $type !== 'article') $row['price'] = $c['price'];
      $row['_dyn_price'] = $c;
    }
    return $row;
  }
}
