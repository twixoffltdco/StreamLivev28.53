<?php
// StreamLive VPN header banner: additive component, does not alter existing header content.
?>
<div id="slVpnHeaderBanner" class="sl-vpn-banner" role="region" aria-label="StreamLive VPN">
  <div class="sl-vpn-banner__icon" aria-hidden="true">🛡️</div>
  <div class="sl-vpn-banner__content">
    <div class="sl-vpn-banner__title">YouTube не работает или тормозит?</div>
    <div class="sl-vpn-banner__text">Попробуйте StreamLive VPN — до 90 минут бесплатно, выбор страны и автоматическое переключение при сбое.</div>
  </div>
  <button type="button" class="sl-vpn-banner__more" id="slVpnOpenInstall">Как установить</button>
  <button type="button" class="sl-vpn-banner__close" id="slVpnCloseBanner" aria-label="Закрыть баннер">×</button>
</div>

<div id="slVpnInstallModal" class="sl-vpn-modal" hidden>
  <div class="sl-vpn-modal__backdrop" data-vpn-close></div>
  <div class="sl-vpn-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="slVpnModalTitle">
    <button type="button" class="sl-vpn-modal__close" data-vpn-close aria-label="Закрыть">×</button>
    <div class="sl-vpn-modal__eyebrow">STREAMLIVE VPN</div>
    <h2 id="slVpnModalTitle">Как установить VPN?</h2>
    <p class="sl-vpn-modal__lead">Выберите устройство — покажем короткую инструкцию и кнопку установки.</p>

    <div class="sl-vpn-devices" role="tablist" aria-label="Устройство">
      <button type="button" class="sl-vpn-device is-active" data-vpn-device="desktop" role="tab" aria-selected="true">💻 ПК / ноутбук</button>
      <button type="button" class="sl-vpn-device" data-vpn-device="android" role="tab" aria-selected="false">📱 Android</button>
      <button type="button" class="sl-vpn-device" data-vpn-device="ios" role="tab" aria-selected="false">🍎 iPhone / iPad</button>
    </div>

    <div class="sl-vpn-install-panel" data-vpn-panel="desktop">
      <h3>ПК / ноутбук</h3>
      <ol><li>Скачайте расширение StreamLive VPN.</li><li>Распакуйте архив.</li><li>Откройте <code>chrome://extensions</code> → включите «Режим разработчика».</li><li>Нажмите «Загрузить распакованное» и выберите папку расширения.</li></ol>
      <a class="sl-vpn-download" href="/downloads/streamlive-vpn-unified-extension.zip">Скачать расширение</a>
    </div>
    <div class="sl-vpn-install-panel" data-vpn-panel="android" hidden>
      <h3>Android</h3>
      <ol><li>Откройте мобильную версию StreamLive VPN.</li><li>Установите приложение/клиент из официального источника.</li><li>Выберите страну и нажмите «Подключить».</li></ol>
      <span class="sl-vpn-soon">Мобильная версия готовится</span>
    </div>
    <div class="sl-vpn-install-panel" data-vpn-panel="ios" hidden>
      <h3>iPhone / iPad</h3>
      <ol><li>Откройте мобильную версию StreamLive VPN.</li><li>Установите клиент из официального источника.</li><li>Выберите страну и подключитесь.</li></ol>
      <span class="sl-vpn-soon">Мобильная версия готовится</span>
    </div>
  </div>
</div>

<style>
.sl-vpn-banner{position:relative;z-index:30;display:flex;align-items:center;gap:14px;margin:10px auto 12px;max-width:1200px;padding:12px 14px;border:1px solid rgba(111,195,255,.18);border-radius:14px;background:linear-gradient(100deg,rgba(20,33,54,.94),rgba(39,28,69,.94));box-shadow:0 8px 28px rgba(0,0,0,.18);color:#eef5ff}
.sl-vpn-banner__icon{font-size:23px;line-height:1}.sl-vpn-banner__content{min-width:0;flex:1}.sl-vpn-banner__title{font-weight:800;font-size:15px}.sl-vpn-banner__text{margin-top:2px;font-size:12px;opacity:.78}.sl-vpn-banner__more{border:0;border-radius:999px;padding:8px 14px;background:#6fc3ff;color:#09111e;font-weight:800;cursor:pointer;white-space:nowrap}.sl-vpn-banner__close{width:34px;height:34px;border-radius:50%;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#d9e5f7;font-size:23px;line-height:1;cursor:pointer}.sl-vpn-banner__close:hover,.sl-vpn-banner__more:hover{filter:brightness(1.08)}
.sl-vpn-modal[hidden]{display:none}.sl-vpn-modal{position:fixed;inset:0;z-index:10060}.sl-vpn-modal__backdrop{position:absolute;inset:0;background:rgba(0,0,0,.66);backdrop-filter:blur(5px)}.sl-vpn-modal__dialog{position:relative;width:min(560px,calc(100vw - 28px));max-height:calc(100vh - 28px);overflow:auto;margin:7vh auto 0;padding:25px;border-radius:20px;background:#101722;color:#eef5ff;border:1px solid rgba(255,255,255,.1);box-shadow:0 20px 80px rgba(0,0,0,.45)}.sl-vpn-modal__close{position:absolute;top:12px;right:12px;border:0;background:transparent;color:#9fb0c8;font-size:27px;cursor:pointer}.sl-vpn-modal__eyebrow{font-size:11px;letter-spacing:.16em;font-weight:800;color:#6fc3ff}.sl-vpn-modal h2{margin:5px 0 6px;font-size:25px}.sl-vpn-modal__lead{margin:0 0 18px;color:#9eacc1}.sl-vpn-devices{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px}.sl-vpn-device{padding:11px 8px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:#171f2c;color:#dce8f8;cursor:pointer;font-weight:700}.sl-vpn-device.is-active{border-color:rgba(111,195,255,.55);background:rgba(111,195,255,.12)}.sl-vpn-install-panel{padding:17px;border-radius:15px;background:#151d29;border:1px solid rgba(255,255,255,.06)}.sl-vpn-install-panel h3{margin:0 0 10px}.sl-vpn-install-panel ol{margin:0 0 15px;padding-left:21px;color:#b9c7d9;line-height:1.65}.sl-vpn-download,.sl-vpn-soon{display:inline-block;padding:10px 15px;border-radius:10px;font-weight:800}.sl-vpn-download{background:#6fc3ff;color:#08111b;text-decoration:none}.sl-vpn-soon{background:rgba(255,255,255,.06);color:#aebbd0}
@media(max-width:650px){.sl-vpn-banner{margin:8px 10px;align-items:flex-start}.sl-vpn-banner__more{padding:8px 10px}.sl-vpn-banner__text{display:none}.sl-vpn-devices{grid-template-columns:1fr}.sl-vpn-modal__dialog{margin:3vh auto 0}}
</style>
<script>
(function(){
  var banner=document.getElementById('slVpnHeaderBanner');
  var modal=document.getElementById('slVpnInstallModal');
  if(!banner||!modal)return;
  var closeBanner=document.getElementById('slVpnCloseBanner');
  var open=document.getElementById('slVpnOpenInstall');
  var close=function(){modal.hidden=true;document.body.classList.remove('sl-vpn-modal-open');};
  var show=function(){modal.hidden=false;document.body.classList.add('sl-vpn-modal-open');};
  closeBanner.addEventListener('click',function(){banner.remove();try{localStorage.setItem('sl_vpn_banner_closed','1')}catch(e){}});
  try{if(localStorage.getItem('sl_vpn_banner_closed')==='1')banner.remove();}catch(e){}
  open.addEventListener('click',show);
  modal.querySelectorAll('[data-vpn-close]').forEach(function(el){el.addEventListener('click',close);});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!modal.hidden)close();});
  modal.querySelectorAll('[data-vpn-device]').forEach(function(btn){btn.addEventListener('click',function(){
    var device=btn.getAttribute('data-vpn-device');
    modal.querySelectorAll('[data-vpn-device]').forEach(function(b){b.classList.toggle('is-active',b===btn);b.setAttribute('aria-selected',b===btn?'true':'false');});
    modal.querySelectorAll('[data-vpn-panel]').forEach(function(panel){panel.hidden=panel.getAttribute('data-vpn-panel')!==device;});
  });});
})();
</script>
