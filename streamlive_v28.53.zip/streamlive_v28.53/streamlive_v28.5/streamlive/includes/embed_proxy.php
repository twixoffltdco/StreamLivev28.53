<?php
/**
 * Прокси iframe/медиа: браузер ходит ТОЛЬКО на наш домен.
 * Для Rumble и прямых mp4/m3u8 — поток через /api/media_proxy.php (сервер качает источник).
 */

function embed_proxy_allowed_hosts(): array {
  $f = dirname(__DIR__) . '/config/embed_proxy_hosts.php';
  $list = is_file($f) ? include $f : [];
  return is_array($list) ? $list : [
    'rumble.com', 'www.rumble.com', 'v.rumble.com',
    'instagram.com', 'www.instagram.com',
    'vk.com', 'vk.ru', 'vkvideo.ru', 'ok.ru',
    'tiktok.com', 'twitch.tv', 'player.twitch.tv', 'kick.com',
  ];
}

function embed_proxy_host_allowed(string $url): bool {
  $p = parse_url($url);
  if (empty($p['host']) || empty($p['scheme'])) return false;
  if (!in_array(strtolower($p['scheme']), ['http', 'https'], true)) return false;
  $host = strtolower($p['host']);
  foreach (embed_proxy_allowed_hosts() as $allow) {
    $allow = strtolower((string)$allow);
    if ($host === $allow) return true;
    $suf = '.' . $allow;
    if (strlen($host) > strlen($suf) && substr($host, -strlen($suf)) === $suf) return true;
  }
  return false;
}

function embed_proxy_base(): string {
  if (defined('SITE_URL') && SITE_URL) return rtrim((string)SITE_URL, '/');
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
  return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}

function embed_proxy_frame_url(string $embedUrl): string {
  $embedUrl = trim($embedUrl);
  if ($embedUrl === '') return '';
  if (strpos($embedUrl, '/api/embed_frame.php') !== false) return $embedUrl;
  if (!preg_match('#^https?://#i', $embedUrl)) return $embedUrl;
  // Прямые медиа — сразу media_proxy в video-теге через frame
  if (preg_match('#\.(mp4|webm|m3u8)(\?|$)#i', $embedUrl)) {
    return embed_proxy_base() . '/api/embed_frame.php?u=' . rawurlencode($embedUrl) . '&mode=media';
  }
  if (!embed_proxy_host_allowed($embedUrl)) return $embedUrl;
  return embed_proxy_base() . '/api/embed_frame.php?u=' . rawurlencode($embedUrl);
}

function embed_rewrite_for_player(string $src): string {
  return embed_proxy_frame_url(trim($src));
}

/** Сервер пытается вытащить прямой media URL (Rumble и т.п.) */
function embed_proxy_resolve_media(string $url): ?string {
  if (preg_match('#\.(mp4|webm|m3u8)(\?|$)#i', $url)) return $url;
  if (!function_exists('curl_init')) return null;

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_ENCODING => '',
  ]);
  $html = curl_exec($ch);
  curl_close($ch);
  if (!$html || !is_string($html)) return null;

  // og:video / json mp4
  if (preg_match('#property=["\']og:video["\']\s+content=["\']([^"\']+)#i', $html, $m)) return html_entity_decode($m[1]);
  if (preg_match('#content=["\']([^"\']+)["\']\s+property=["\']og:video#i', $html, $m)) return html_entity_decode($m[1]);
  if (preg_match('#"contentUrl"\s*:\s*"([^"]+\.mp4[^"]*)"#i', $html, $m)) return stripcslashes($m[1]);
  if (preg_match('#https?://[^"\'\s]+\.mp4[^"\'\s]*#i', $html, $m)) return $m[0];
  if (preg_match('#https?://[^"\'\s]+\.m3u8[^"\'\s]*#i', $html, $m)) return $m[0];
  // rumble ua embed json
  if (preg_match('#"u"\s*:\s*\{[^}]*"mp4"\s*:\s*\{[^}]*"url"\s*:\s*"([^"]+)"#s', $html, $m)) return stripcslashes($m[1]);
  if (preg_match('#"mp4"\s*:\s*\{[^{}]*"url"\s*:\s*"([^"]+)"#', $html, $m)) return stripcslashes($m[1]);
  return null;
}
