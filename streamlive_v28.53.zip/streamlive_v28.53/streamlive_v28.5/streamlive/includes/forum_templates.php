<?php
function forum_templates_ensure(): void {
  static $d = false; if ($d) return; $d = true;
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS forum_reply_templates (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        title VARCHAR(120) NOT NULL,
        body MEDIUMTEXT NOT NULL,
        is_shared TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
}

function forum_templates_list(int $userId): array {
  forum_templates_ensure();
  try {
    $st = db()->prepare('SELECT * FROM forum_reply_templates WHERE user_id=? OR is_shared=1 ORDER BY title ASC LIMIT 50');
    $st->execute([$userId]);
    return $st->fetchAll() ?: [];
  } catch (Throwable $e) {
    return [];
  }
}
