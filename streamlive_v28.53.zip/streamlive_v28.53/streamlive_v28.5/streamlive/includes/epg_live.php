<?php
/**
 * Живое расписание: строго по имени канала/потока.
 * НИКОГДА не отдаём чужие передачи «просто из XML».
 * Автопоиск зеркал → storage/epg_sources.json
 */
if (!function_exists('epg_live_storage')) {
  function epg_live_storage(): string {
    $d = dirname(__DIR__) . '/storage';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    $c = $d . '/epg_cache';
    if (!is_dir($c)) @mkdir($c, 0755, true);
    return $d;
  }
}

if (!function_exists('epg_live_bootstrap_sources')) {
  function epg_live_bootstrap_sources(): array {
    return [
      // RU-ориентированные в первую очередь
      'https://epg.pw/xmltv/epg_ru.xml',
      'https://epg.pw/xmltv/epg.xml',
      'https://iptvx.one/epg/epg.xml.gz',
      'https://epg.one/epg.xml',
      'https://xmltv.tvcom.ru/xmltv.xml.gz',
    ];
  }
}

if (!function_exists('epg_live_sources_file')) {
  function epg_live_sources_file(): string {
    return epg_live_storage() . '/epg_sources.json';
  }
}

if (!function_exists('epg_live_load_sources')) {
  function epg_live_load_sources(): array {
    $f = epg_live_sources_file();
    $list = [];
    if (is_file($f)) {
      $j = json_decode((string)@file_get_contents($f), true);
      if (is_array($j) && !empty($j['sources']) && is_array($j['sources'])) {
        $list = $j['sources'];
      }
    }
    if (!$list) $list = epg_live_bootstrap_sources();
    $out = [];
    foreach ($list as $u) {
      $u = trim((string)$u);
      if ($u !== '' && preg_match('#^https?://#i', $u) && !in_array($u, $out, true)) $out[] = $u;
    }
    return $out;
  }
}

if (!function_exists('epg_live_save_sources')) {
  function epg_live_save_sources(array $sources): void {
    $sources = array_values(array_unique(array_filter(array_map('strval', $sources))));
    $sources = array_slice($sources, 0, 80);
    @file_put_contents(
      epg_live_sources_file(),
      json_encode(['updated_at' => date('c'), 'sources' => $sources], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
      LOCK_EX
    );
  }
}

if (!function_exists('epg_live_fetch_url')) {
  function epg_live_fetch_url(string $url, int $timeout = 10): ?string {
    $ctx = stream_context_create([
      'http' => [
        'timeout' => $timeout,
        'header' => "User-Agent: StreamLive-EPG/3.0\r\nAccept: */*\r\n",
        'follow_location' => 1,
      ],
      'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false || $raw === '') {
      if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_TIMEOUT => $timeout,
          CURLOPT_SSL_VERIFYPEER => false,
          CURLOPT_USERAGENT => 'StreamLive-EPG/3.0',
        ]);
        $raw = curl_exec($ch);
        curl_close($ch);
      }
    }
    if (!is_string($raw) || $raw === '') return null;
    $path = strtolower((string)(parse_url($url, PHP_URL_PATH) ?? ''));
    if (str_ends_with($path, '.gz') || (strlen($raw) > 2 && ord($raw[0]) === 0x1f && ord($raw[1]) === 0x8b)) {
      $u = @gzdecode($raw);
      if ($u !== false) $raw = $u;
    }
    return $raw;
  }
}

if (!function_exists('epg_live_looks_like_xmltv')) {
  function epg_live_looks_like_xmltv(string $body): bool {
    return (stripos($body, '<tv') !== false || stripos($body, '<programme') !== false)
      && strlen($body) > 200;
  }
}

if (!function_exists('epg_live_norm')) {
  /** Нормализация имени канала для сравнения */
  function epg_live_norm(string $s): string {
    $s = mb_strtolower(trim($s));
    $s = str_replace(['ё'], ['е'], $s);
    $s = preg_replace('/[^\p{L}\p{N}]+/u', '', $s) ?? $s;
    return $s;
  }
}

if (!function_exists('epg_live_aliases')) {
  /** Известные русские каналы → варианты имён в EPG */
  function epg_live_aliases(string $name): array {
    $n = epg_live_norm($name);
    $map = [
      'тнт' => ['тнт', 'tnt', 'тнтhd', 'tnthd', 'тнт4'],
      'телеканалсолнце' => ['солнце', 'solnce', 'solntse', 'телеканалсолнце'],
      'солнце' => ['солнце', 'solnce', 'solntse', 'телеканалсолнце'],
      'россия1' => ['россия1', 'россия', 'russia1', 'rossia1', 'россияhd'],
      'россия24' => ['россия24', 'russia24', 'vesti', 'вести'],
      'первыйканал' => ['первый', '1tv', 'channelone', 'первыйканал'],
      'нтв' => ['нтв', 'ntv', 'нтвhd'],
      'стс' => ['стс', 'sts', 'ctc'],
      'пятница' => ['пятница', 'friday', 'pyatnica'],
      'рентв' => ['рен', 'рентв', 'rentv'],
      'матчтв' => ['матч', 'matchtv', 'матчтв'],
      'культура' => ['культура', 'russiak', 'россиякультура'],
      'карусель' => ['карусель', 'karusel'],
      'звезда' => ['звезда', 'zvezda'],
      'мир' => ['мир', 'mir'],
      'тв3' => ['тв3', 'tv3'],
      'домашний' => ['домашний', 'domashniy'],
      'че' => ['че', 'peretz', 'перец'],
      'ю' => ['ю', 'u'],
      'музтв' => ['музтв', 'muztv'],
    ];
    $out = [$n];
    foreach ($map as $key => $aliases) {
      if ($n === $key || in_array($n, $aliases, true) || mb_strpos($n, $key) !== false) {
        foreach ($aliases as $a) $out[] = $a;
        $out[] = $key;
      }
    }
    // вытащить «ядро» из «телеканал X»
    if (preg_match('/^(?:телеканал|канал|tv|тв)(.+)$/u', $n, $m)) {
      $out[] = $m[1];
    }
    return array_values(array_unique(array_filter($out)));
  }
}

if (!function_exists('epg_live_score_name')) {
  function epg_live_score_name(string $hintNorm, array $aliases, string $candidate): int {
    $c = epg_live_norm($candidate);
    if ($c === '') return 0;
    if ($c === $hintNorm) return 100;
    foreach ($aliases as $a) {
      if ($a === '') continue;
      if ($c === $a) return 95;
      if (mb_strpos($c, $a) !== false || mb_strpos($a, $c) !== false) {
        $len = min(mb_strlen($c), mb_strlen($a));
        if ($len >= 3) return 70 + min(20, $len);
      }
    }
    // prefix 4+
    if (mb_strlen($hintNorm) >= 4 && mb_strlen($c) >= 4) {
      if (mb_substr($c, 0, 4) === mb_substr($hintNorm, 0, 4)) return 40;
    }
    return 0;
  }
}

if (!function_exists('epg_live_build_channel_index')) {
  /**
   * Из XMLTV собрать id → display-name[]
   * @return array<string, string[]>
   */
  function epg_live_build_channel_index(string $xml): array {
    $idx = [];
    if (!preg_match_all('/<channel\b([^>]*)>(.*?)<\/channel>/is', $xml, $mm, PREG_SET_ORDER)) {
      return $idx;
    }
    foreach ($mm as $m) {
      $id = '';
      if (preg_match('/id=["\']([^"\']+)["\']/i', $m[1], $im)) $id = $im[1];
      if ($id === '') continue;
      $names = [];
      if (preg_match_all('/<display-name[^>]*>([^<]+)</i', $m[2], $nm)) {
        foreach ($nm[1] as $dn) {
          $dn = html_entity_decode(trim($dn), ENT_QUOTES | ENT_HTML5, 'UTF-8');
          if ($dn !== '') $names[] = $dn;
        }
      }
      $names[] = $id;
      $idx[$id] = $names;
    }
    return $idx;
  }
}

if (!function_exists('epg_live_resolve_channel_ids')) {
  /** @return string[] channel ids with score >= threshold */
  function epg_live_resolve_channel_ids(array $index, string $channelHint): array {
    $hintNorm = epg_live_norm($channelHint);
    if ($hintNorm === '') return [];
    $aliases = epg_live_aliases($channelHint);
    $scored = [];
    foreach ($index as $id => $names) {
      $best = 0;
      foreach ($names as $nm) {
        $best = max($best, epg_live_score_name($hintNorm, $aliases, $nm));
        $best = max($best, epg_live_score_name($hintNorm, $aliases, $id));
      }
      if ($best >= 70) {
        $scored[$id] = $best;
      }
    }
    arsort($scored);
    return array_keys($scored);
  }
}

if (!function_exists('epg_live_parse_programmes_for_ids')) {
  function epg_live_parse_programmes_for_ids(string $xml, array $channelIds): array {
    $out = [];
    if (!$channelIds || !epg_live_looks_like_xmltv($xml)) return $out;
    $idSet = [];
    foreach ($channelIds as $id) $idSet[mb_strtolower($id)] = true;

    if (!preg_match_all('/<programme\b([^>]*)>(.*?)<\/programme>/is', $xml, $mm, PREG_SET_ORDER)) {
      return $out;
    }
    $now = time();
    $parsed = [];
    foreach ($mm as $m) {
      $attrs = $m[1];
      $body = $m[2];
      $ch = '';
      if (preg_match('/channel=["\']([^"\']+)["\']/i', $attrs, $c)) $ch = $c[1];
      if ($ch === '' || empty($idSet[mb_strtolower($ch)])) continue;

      $start = preg_match('/start=["\'](\d{10,14})/i', $attrs, $s) ? $s[1] : '';
      $stop = preg_match('/stop=["\'](\d{10,14})/i', $attrs, $s2) ? $s2[1] : '';
      $title = '';
      if (preg_match('/<title[^>]*>([^<]+)</i', $body, $tt)) {
        $title = html_entity_decode(trim($tt[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
      }
      if ($title === '') continue;

      $ts = 0;
      if (strlen($start) >= 12) {
        $ts = gmmktime(
          (int)substr($start, 8, 2), (int)substr($start, 10, 2), 0,
          (int)substr($start, 4, 2), (int)substr($start, 6, 2), (int)substr($start, 0, 4)
        );
      }
      $parsed[] = [
        'title' => $title,
        'start' => $start,
        'stop' => $stop,
        'channel' => $ch,
        '_ts' => $ts,
      ];
    }
    // сортировка по времени, окно: −2ч … +24ч от сейчас
    usort($parsed, static fn($a, $b) => ($a['_ts'] <=> $b['_ts']));
    $from = $now - 7200;
    $to = $now + 86400;
    foreach ($parsed as $p) {
      if ($p['_ts'] && ($p['_ts'] < $from || $p['_ts'] > $to)) continue;
      unset($p['_ts']);
      $out[] = $p;
      if (count($out) >= 40) break;
    }
    // если окно пустое — ближайшие 20 по времени
    if (!$out && $parsed) {
      foreach (array_slice($parsed, 0, 20) as $p) {
        unset($p['_ts']);
        $out[] = $p;
      }
    }
    return $out;
  }
}

if (!function_exists('epg_live_discover_sources')) {
  function epg_live_discover_sources(): array {
    $found = [];
    $seedPages = [
      'https://raw.githubusercontent.com/iptv-org/epg/master/README.md',
      'https://epg.pw/',
      'https://epg.one/',
    ];
    foreach ($seedPages as $page) {
      $html = epg_live_fetch_url($page, 6);
      if ($html === null) continue;
      if (preg_match_all('#https?://[^\s"\'<>\)]+#i', $html, $mm)) {
        foreach ($mm[0] as $u) {
          $u = rtrim($u, '.,);]');
          $ul = strtolower($u);
          if (str_contains($ul, 'epg') || str_contains($ul, 'xmltv') || str_ends_with($ul, '.xml') || str_ends_with($ul, '.xml.gz')) {
            if (!in_array($u, $found, true)) $found[] = $u;
          }
        }
      }
    }
    return array_slice($found, 0, 40);
  }
}

if (!function_exists('epg_live_promote_source')) {
  function epg_live_promote_source(string $url): void {
    $list = epg_live_load_sources();
    $list = array_values(array_filter($list, static fn($x) => $x !== $url));
    array_unshift($list, $url);
    epg_live_save_sources($list);
  }
}

if (!function_exists('epg_live_schedule_for')) {
  /**
   * @return array{ok:bool,source?:string,items:array,matched?:string,error?:string}
   */
  function epg_live_schedule_for(string $channelName): array {
    $channelName = trim($channelName);
    if ($channelName === '') {
      return ['ok' => false, 'items' => [], 'error' => 'Не указан канал'];
    }

    $cacheKey = preg_replace('/[^a-zA-Z0-9_-]+/', '_', mb_strtolower($channelName)) ?: 'ch';
    $cacheFile = epg_live_storage() . '/epg_cache/' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 900) {
      $j = json_decode((string)@file_get_contents($cacheFile), true);
      if (is_array($j) && !empty($j['items']) && !empty($j['ok'])) return $j;
    }

    $sources = epg_live_load_sources();
    $tryList = $sources;
    $sf = epg_live_sources_file();
    if (!is_file($sf) || (time() - filemtime($sf)) > 21600) {
      foreach (epg_live_discover_sources() as $u) {
        if (!in_array($u, $tryList, true)) $tryList[] = $u;
      }
    }

    $lastErr = 'Расписание для этого канала не найдено';

    foreach ($tryList as $url) {
      $xml = epg_live_fetch_url($url, 10);
      if ($xml === null) {
        $lastErr = 'Недоступен: ' . $url;
        continue;
      }
      if (!epg_live_looks_like_xmltv($xml)) {
        $lastErr = 'Не XMLTV: ' . $url;
        continue;
      }

      $index = epg_live_build_channel_index($xml);
      $ids = epg_live_resolve_channel_ids($index, $channelName);
      if (!$ids) {
        $lastErr = 'Канал «' . $channelName . '» не найден в ' . $url;
        continue;
      }

      $items = epg_live_parse_programmes_for_ids($xml, $ids);
      if (!$items) {
        $lastErr = 'Нет передач для «' . $channelName . '» в ' . $url;
        continue;
      }

      epg_live_promote_source($url);
      $matched = $ids[0];
      if (!empty($index[$matched][0])) $matched = $index[$matched][0] . ' (' . $matched . ')';

      $res = [
        'ok' => true,
        'source' => $url,
        'items' => $items,
        'matched' => $matched,
      ];
      @file_put_contents($cacheFile, json_encode($res, JSON_UNESCAPED_UNICODE), LOCK_EX);
      return $res;
    }

    return ['ok' => false, 'items' => [], 'error' => $lastErr];
  }
}
