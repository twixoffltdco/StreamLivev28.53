<?php
/**
 * Фикс превью через прокси:
 * - абсолютные URL (относительные og:image ломались)
 * - twitter/og/secure_url/json-ld/poster
 * - Rumble / Dropbox эвристики
 * - показ картинки через /thumb.php?u= (хостинг тянет через NETWORK_PROXY)
 *
 * require после includes/video_embed.php или oembed_meta.php
 */

if (!function_exists('sl_abs_url')) {
  function sl_abs_url(string $maybeRelative, string $basePageUrl): string {
    $u = trim($maybeRelative);
    if ($u === '') return '';
    if (preg_match('#^https?://#i', $u)) return $u;
    if (str_starts_with($u, '//')) {
      $sch = parse_url($basePageUrl, PHP_URL_SCHEME) ?: 'https';
      return $sch . ':' . $u;
    }
    $p = parse_url($basePageUrl);
    if (!$p || empty($p['host'])) return $u;
    $scheme = $p['scheme'] ?? 'https';
    $host = $p['host'];
    $port = isset($p['port']) ? ':' . $p['port'] : '';
    $origin = $scheme . '://' . $host . $port;
    if (str_starts_with($u, '/')) return $origin . $u;
    $path = $p['path'] ?? '/';
    $dir = preg_replace('#/[^/]*$#', '/', $path);
    return $origin . $dir . $u;
  }
}

if (!function_exists('sl_extract_thumbnails_from_html')) {
  function sl_extract_thumbnails_from_html(string $html, string $pageUrl = ''): array {
    $found = [];
    $push = static function (string $u) use (&$found, $pageUrl) {
      $u = trim(html_entity_decode($u, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
      if ($u === '') return;
      if ($pageUrl !== '') $u = sl_abs_url($u, $pageUrl);
      if (!preg_match('#^https?://#i', $u)) return;
      // data: skip
      if (str_starts_with($u, 'data:')) return;
      $found[$u] = true;
    };

    // meta variants
    $patterns = [
      '/property=["\']og:image(?::url|:secure_url)?["\'][^>]*content=["\']([^"\']+)/i',
      '/content=["\']([^"\']+)["\'][^>]*property=["\']og:image(?::url|:secure_url)?["\']/i',
      '/name=["\']twitter:image(?::src)?["\'][^>]*content=["\']([^"\']+)/i',
      '/content=["\']([^"\']+)["\'][^>]*name=["\']twitter:image(?::src)?["\']/i',
      '/rel=["\']image_src["\'][^>]*href=["\']([^"\']+)/i',
      '/itemprop=["\']thumbnailUrl["\'][^>]*content=["\']([^"\']+)/i',
      '/content=["\']([^"\']+)["\'][^>]*itemprop=["\']thumbnailUrl["\']/i',
      '/<video[^>]+poster=["\']([^"\']+)/i',
      '/"thumbnailUrl"\s*:\s*"([^"]+)"/i',
      '/"thumbnail_url"\s*:\s*"([^"]+)"/i',
      '/"poster"\s*:\s*"([^"]+)"/i',
      '/"image"\s*:\s*"([^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/i',
    ];
    foreach ($patterns as $re) {
      if (preg_match_all($re, $html, $m)) {
        foreach ($m[1] as $hit) $push($hit);
      }
    }

    // Rumble: i.rmbl.ws
    if (preg_match_all('#https?://i\.rmbl\.ws/[^"\'\s<>]+#i', $html, $m)) {
      foreach ($m[0] as $hit) $push($hit);
    }
    // Dropbox preview images
    if (preg_match_all('#https?://[^"\'\s<>]*dropbox[^"\'\s<>]+\.(?:jpg|jpeg|png|webp)#i', $html, $m)) {
      foreach ($m[0] as $hit) $push($hit);
    }

    return array_keys($found);
  }
}

if (!function_exists('sl_enrich_meta_thumbnail')) {
  /**
   * Дополняет результат fetch_video_meta: если title есть, а thumbnail нет — добираем.
   */
  function sl_enrich_meta_thumbnail(array $meta, string $sourceUrl, string $html = ''): array {
    $thumb = trim((string)($meta['thumbnail_url'] ?? $meta['thumbnail'] ?? ''));
    if ($thumb !== '') {
      $meta['thumbnail_url'] = sl_abs_url($thumb, $sourceUrl);
      return $meta;
    }
    if ($html === '' && function_exists('video_fetch_with_fallback')) {
      $html = (string)(video_fetch_with_fallback($sourceUrl) ?? '');
    } elseif ($html === '' && function_exists('video_http_get')) {
      $html = (string)(video_http_get($sourceUrl) ?? '');
    } elseif ($html === '' && function_exists('oembed_http_raw')) {
      $html = oembed_http_raw($sourceUrl);
    }
    if ($html === '') return $meta;
    $cands = sl_extract_thumbnails_from_html($html, $sourceUrl);
    if ($cands) {
      $meta['thumbnail_url'] = $cands[0];
      if (empty($meta['meta_source']) || $meta['meta_source'] === 'none') {
        $meta['meta_source'] = 'thumb_fix';
      }
    }
    return $meta;
  }
}

/** URL для <img src> — через локальный прокси, если внешний хотлинк режется */
if (!function_exists('video_thumb_url')) {
  function video_thumb_url($videoOrUrl): string {
    $raw = '';
    if (is_array($videoOrUrl)) {
      $raw = (string)($videoOrUrl['thumbnail_url'] ?? $videoOrUrl['thumbnail'] ?? '');
    } else {
      $raw = (string)$videoOrUrl;
    }
    $raw = trim($raw);
    if ($raw === '') return '';
    // уже наш прокси
    if (str_contains($raw, '/thumb.php')) return $raw;
    // локальный путь
    if (str_starts_with($raw, '/') && !str_starts_with($raw, '//')) return $raw;
    return '/thumb.php?u=' . rawurlencode($raw);
  }
}

/** Переопределяем/оборачиваем fetch_video_meta если уже есть */
if (function_exists('fetch_video_meta') && !function_exists('fetch_video_meta_sl_wrapped')) {
  function fetch_video_meta_sl_wrapped(string $url, string $platform): array {
    $r = \fetch_video_meta($url, $platform);
    return sl_enrich_meta_thumbnail($r, $url);
  }
}
