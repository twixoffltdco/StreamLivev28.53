<?php
if (!function_exists('is_smotrim_ui')) {
  function is_smotrim_ui(): bool {
    $m = '';
    try {
      if (!empty($_COOKIE['pl_ui_mode'])) $m = (string)$_COOKIE['pl_ui_mode'];
      elseif (!empty($_SESSION['pl_ui_mode'])) $m = (string)$_SESSION['pl_ui_mode'];
    } catch (Throwable $e) {}
    return strtolower($m) === 'smotrim';
  }
}
