<?php
/**
 * require_once этот файл из header.php / functions.php один раз.
 */
static $__pawno_boot = false;
if ($__pawno_boot) {
  return;
}
$__pawno_boot = true;

$base = __DIR__;
if (is_file($base . '/prefix_pawno_banners.php')) {
  require_once $base . '/prefix_pawno_banners.php';
}

// Подмена рендера: если оригинальный user_render_prefix_html уже загружен,
// объявляем обёртку через user_render_prefixes только для badge-путей сложно.
// Вместо этого патчим вывод через runkit нельзя — используем CSS+UPDATE css в БД.

if (function_exists('prefix_pawno_render_html') && !function_exists('user_render_prefix_html')) {
  function user_render_prefix_html(?array $prefix): string {
    return prefix_pawno_render_html($prefix);
  }
}

// Если функция уже есть — переопределить нельзя. Тогда restyle_all пишет gradient в css,
// а штатный user_render_prefix_html подхватит style= из поля css.
