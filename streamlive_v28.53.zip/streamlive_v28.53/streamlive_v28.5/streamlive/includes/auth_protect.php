<?php
/** Защита входа: незавершённый PIN за 30 сек → блок login/register на 100 часов */
function auth_protect_ensure(): void {
  static $d = false; if ($d) return; $d = true;
  try {
    db()->exec(
      "CREATE TABLE IF NOT EXISTS auth_login_locks (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(45) NOT NULL,
        login_key VARCHAR(190) NOT NULL DEFAULT '',
        reason VARCHAR(40) NOT NULL DEFAULT 'pin_timeout',
        locked_until DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_ip (ip),
        KEY idx_until (locked_until)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    db()->exec(
      "CREATE TABLE IF NOT EXISTS auth_pending_pins (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        ip VARCHAR(45) NOT NULL,
        pin_hash VARCHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_user (user_id),
        KEY idx_exp (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
  } catch (Throwable $e) {}
}

function auth_client_ip(): string {
  if (function_exists('antibot_client_ip')) return antibot_client_ip();
  return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function auth_is_locked(?string $login = null): bool {
  auth_protect_ensure();
  $ip = auth_client_ip();
  try {
    $st = db()->prepare(
      "SELECT id FROM auth_login_locks WHERE locked_until > NOW() AND (ip=? OR (login_key<>'' AND login_key=?)) LIMIT 1"
    );
    $st->execute([$ip, $login ?? '']);
    return (bool)$st->fetchColumn();
  } catch (Throwable $e) {
    return false;
  }
}

function auth_lock(string $reason = 'pin_timeout', ?string $login = null, int $hours = 100): void {
  auth_protect_ensure();
  try {
    db()->prepare(
      'INSERT INTO auth_login_locks (ip, login_key, reason, locked_until) VALUES (?,?,?, DATE_ADD(NOW(), INTERVAL ? HOUR))'
    )->execute([auth_client_ip(), $login ?? '', $reason, $hours]);
  } catch (Throwable $e) {}
}

function auth_start_pin_challenge(int $userId): string {
  auth_protect_ensure();
  $pin = (string)random_int(100000, 999999);
  $hash = hash('sha256', $pin . '|' . $userId);
  $exp = date('Y-m-d H:i:s', time() + 30); // 30 секунд
  try {
    db()->prepare('DELETE FROM auth_pending_pins WHERE user_id=? OR expires_at < NOW()')->execute([$userId]);
    db()->prepare('INSERT INTO auth_pending_pins (user_id, ip, pin_hash, expires_at) VALUES (?,?,?,?)')
      ->execute([$userId, auth_client_ip(), $hash, $exp]);
  } catch (Throwable $e) {}
  $_SESSION['auth_pin_user_id'] = $userId;
  $_SESSION['auth_pin_deadline'] = time() + 30;
  // PIN показываем один раз на экране (не в письме — без почты)
  $_SESSION['auth_pin_display'] = $pin;
  return $pin;
}

function auth_verify_pin(string $pin): ?int {
  auth_protect_ensure();
  $uid = (int)($_SESSION['auth_pin_user_id'] ?? 0);
  if ($uid <= 0) return null;
  $deadline = (int)($_SESSION['auth_pin_deadline'] ?? 0);
  if ($deadline > 0 && time() > $deadline) {
    auth_lock('pin_timeout');
    unset($_SESSION['auth_pin_user_id'], $_SESSION['auth_pin_deadline'], $_SESSION['auth_pin_display']);
    return null;
  }
  try {
    $st = db()->prepare('SELECT * FROM auth_pending_pins WHERE user_id=? AND expires_at > NOW() ORDER BY id DESC LIMIT 1');
    $st->execute([$uid]);
    $row = $st->fetch();
    if (!$row) {
      auth_lock('pin_timeout');
      return null;
    }
    $hash = hash('sha256', preg_replace('/\s+/', '', $pin) . '|' . $uid);
    if (!hash_equals($row['pin_hash'], $hash)) return null;
    db()->prepare('DELETE FROM auth_pending_pins WHERE user_id=?')->execute([$uid]);
    unset($_SESSION['auth_pin_user_id'], $_SESSION['auth_pin_deadline'], $_SESSION['auth_pin_display']);
    return $uid;
  } catch (Throwable $e) {
    return null;
  }
}

function auth_check_pin_timeout(): void {
  $uid = (int)($_SESSION['auth_pin_user_id'] ?? 0);
  $deadline = (int)($_SESSION['auth_pin_deadline'] ?? 0);
  if ($uid > 0 && $deadline > 0 && time() > $deadline) {
    auth_lock('pin_timeout');
    unset($_SESSION['auth_pin_user_id'], $_SESSION['auth_pin_deadline'], $_SESSION['auth_pin_display']);
  }
}
