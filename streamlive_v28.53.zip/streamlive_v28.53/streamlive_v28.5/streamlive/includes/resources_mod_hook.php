<?php
/**
 * Ресурсы → модерация (как темы/видео), без ломки includes/resources.php
 * В resource_new.php после insert:
 *   require resources_mod_hook.php; resources_mark_pending($id);
 */
if (!function_exists('resources_mark_pending')) {
  function resources_mark_pending(int $id): void {
    try {
      db()->prepare('UPDATE resources SET status = ? WHERE id = ?')->execute(['pending', $id]);
    } catch (Throwable $e) {
      try {
        db()->prepare('UPDATE resources SET is_approved = 0 WHERE id = ?')->execute([$id]);
      } catch (Throwable $e2) {}
    }
  }
}
if (!function_exists('resources_approve')) {
  function resources_approve(int $id): void {
    try {
      db()->prepare('UPDATE resources SET status = ? WHERE id = ?')->execute(['approved', $id]);
    } catch (Throwable $e) {
      try {
        db()->prepare('UPDATE resources SET is_approved = 1 WHERE id = ?')->execute([$id]);
      } catch (Throwable $e2) {}
    }
  }
}
