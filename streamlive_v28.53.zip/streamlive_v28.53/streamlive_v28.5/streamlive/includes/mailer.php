<?php
/**
 * Отправка писем. From подтягивается с текущего домена / настроек.
 * BindHost: создай ящик на домене сайта и укажи mail_from в настройках.
 */
function mailer_host(): string {
  $h = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $h = preg_replace('/:\\d+$/', '', $h);
  $h = preg_replace('/^www\\./i', '', $h);
  return $h;
}

function mailer_from(): array {
  $from = '';
  $name = '';
  if (function_exists('get_setting')) {
    try { $from = (string)get_setting('mail_from', ''); } catch (Throwable $e) {}
    try { $name = (string)get_setting('mail_from_name', ''); } catch (Throwable $e) {}
  }
  if ($from === '' && defined('MAIL_FROM')) $from = (string)MAIL_FROM;
  if ($name === '' && defined('SITE_NAME')) $name = (string)SITE_NAME;
  if ($name === '') $name = 'StreamLive';
  // реальный домен сайта (не websitegame служебный, если SITE_URL задан)
  $host = mailer_host();
  if (defined('SITE_URL') && SITE_URL) {
    $p = parse_url((string)SITE_URL);
    if (!empty($p['host'])) $host = $p['host'];
  }
  if ($from === '' || strpos($from, '@') === false) {
    $from = 'noreply@' . $host;
  }
  // если From с чужого домена — заменяем на текущий host
  $fromDomain = strtolower(substr(strrchr($from, '@') ?: '', 1));
  if ($fromDomain && $fromDomain !== strtolower($host) && substr($host, -strlen($fromDomain)) !== $fromDomain) {
    // оставляем локальную часть, меняем домен на текущий
    $local = substr($from, 0, strpos($from, '@')) ?: 'noreply';
    $from = $local . '@' . $host;
  }
  return [$from, $name, $host];
}

function mailer_send(string $to, string $subject, string $htmlBody, string $textBody = ''): bool {
  $to = trim($to);
  if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
  [$from, $name, $host] = mailer_from();
  if ($textBody === '') {
    $textBody = trim(strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>'], "\n", $htmlBody)));
  }
  $boundary = 'b_' . bin2hex(random_bytes(8));
  $headers = [];
  $headers[] = 'MIME-Version: 1.0';
  $encName = function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($name, 'UTF-8') : $name;
  $headers[] = 'From: ' . $encName . ' <' . $from . '>';
  $headers[] = 'Reply-To: ' . $from;
  $headers[] = 'Return-Path: ' . $from;
  $headers[] = 'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $host . '>';
  $headers[] = 'X-Mailer: StreamLive';
  $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
  $body = "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n{$textBody}\r\n";
  $body .= "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n{$htmlBody}\r\n";
  $body .= "--{$boundary}--";
  $subj = function_exists('mb_encode_mimeheader') ? mb_encode_mimeheader($subject, 'UTF-8') : $subject;
  $params = '-f' . $from;
  try {
    return @mail($to, $subj, $body, implode("\r\n", $headers), $params);
  } catch (Throwable $e) {
    try {
      return @mail($to, $subj, $body, implode("\r\n", $headers));
    } catch (Throwable $e2) {
      return false;
    }
  }
}

function mailer_template(string $title, string $lead, string $buttonLabel, string $buttonUrl, string $foot = ''): string {
  $safeUrl = htmlspecialchars($buttonUrl, ENT_QUOTES, 'UTF-8');
  $foot = $foot !== '' ? $foot : 'Если вы не запрашивали это действие — просто проигнорируйте письмо.';
  return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#0f0f12;font-family:system-ui,-apple-system,sans-serif">'
    . '<div style="max-width:480px;margin:32px auto;padding:28px;background:#1a1a22;border-radius:16px;border:1px solid #2a2a35;color:#e8e8ef">'
    . '<div style="font-size:13px;letter-spacing:.08em;color:#a78bfa;font-weight:700;margin-bottom:12px">STREAMLIVE</div>'
    . '<h1 style="font-size:22px;margin:0 0 12px;color:#fff">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1>'
    . '<p style="line-height:1.55;color:#b0b0c0;margin:0 0 22px">' . htmlspecialchars($lead, ENT_QUOTES, 'UTF-8') . '</p>'
    . '<a href="' . $safeUrl . '" style="display:inline-block;padding:14px 22px;background:#7c3aed;color:#fff;text-decoration:none;border-radius:10px;font-weight:700">'
    . htmlspecialchars($buttonLabel, ENT_QUOTES, 'UTF-8') . '</a>'
    . '<p style="margin:24px 0 0;font-size:12px;color:#777;line-height:1.45">' . htmlspecialchars($foot, ENT_QUOTES, 'UTF-8') . '</p>'
    . '<p style="margin:12px 0 0;font-size:11px;color:#555;word-break:break-all">' . $safeUrl . '</p>'
    . '</div></body></html>';
}
