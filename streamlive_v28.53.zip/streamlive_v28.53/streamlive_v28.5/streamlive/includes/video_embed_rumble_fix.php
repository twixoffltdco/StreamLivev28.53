<?php
/**
 * Фикс Rumble: чёрный экран из‑за неверного embed URL.
 * Подключить ПОСЛЕ includes/video_embed.php:
 *   require_once __DIR__ . '/video_embed_rumble_fix.php';
 *
 * Или в начало video.php / embed.php после video_embed.php.
 */

if (!function_exists('normalize_video_embed_rumble_fixed')) {
  function normalize_video_embed_rumble_fixed(string $url): string {
    $url = trim($url);
    // уже embed
    if (preg_match('#rumble\.com/embed/(v?[a-zA-Z0-9]+)#i', $url, $m)) {
      $id = $m[1];
      if ($id[0] !== 'v' && $id[0] !== 'V') $id = 'v' . $id;
      return 'https://rumble.com/embed/' . strtolower($id) . '/';
    }
    // page: rumble.com/vXXXX-title.html или /vXXXX.html
    if (preg_match('#rumble\.com/(v[a-zA-Z0-9]+)(?:-[a-zA-Z0-9\-]+)?(?:\.html)?#i', $url, $m)) {
      return 'https://rumble.com/embed/' . strtolower($m[1]) . '/';
    }
    // только id
    if (preg_match('#(^|/)(v[a-zA-Z0-9]{5,})(/|$|\?)#i', $url, $m)) {
      return 'https://rumble.com/embed/' . strtolower($m[2]) . '/';
    }
    return $url;
  }
}

if (!function_exists('video_rumble_oembed')) {
  function video_rumble_oembed(string $pageUrl): ?array {
    $api = 'https://rumble.com/api/Media/oembed.json?url=' . urlencode($pageUrl);
    $body = null;
    if (function_exists('video_fetch_with_fallback')) {
      $body = video_fetch_with_fallback($api, 10);
    } elseif (function_exists('video_http_get')) {
      $body = video_http_get($api, 10);
    } else {
      $ctx = stream_context_create(['http' => ['timeout' => 10, 'header' => "User-Agent: Mozilla/5.0\r\n"]]);
      $body = @file_get_contents($api, false, $ctx);
    }
    if (!$body) return null;
    $j = json_decode($body, true);
    return is_array($j) ? $j : null;
  }
}

/**
 * Перехват normalize_video_embed для rumble — через обёртку.
 * Если исходная функция уже есть, переопределить нельзя в PHP.
 * Поэтому вызывайте video_embed_src($platform, $url) вместо normalize_video_embed.
 */
if (!function_exists('video_embed_src')) {
  function video_embed_src(string $platform, string $url): string {
    $platform = strtolower(trim($platform));
    if ($platform === 'rumble' || (function_exists('detect_video_platform') && detect_video_platform($url) === 'rumble')) {
      $fixed = normalize_video_embed_rumble_fixed($url);
      // oEmbed html → src
      $oe = video_rumble_oembed($url);
      if ($oe && !empty($oe['html']) && preg_match('#src=["\']([^"\']+)["\']#i', $oe['html'], $m)) {
        return $m[1];
      }
      return $fixed;
    }
    if (function_exists('normalize_video_embed')) {
      return normalize_video_embed($platform, $url);
    }
    return $url;
  }
}

if (!function_exists('video_iframe_html')) {
  function video_iframe_html(string $src, string $title = 'Video'): string {
    $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
    $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    return '<div class="sl-video-frame" style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;background:#000;border-radius:12px">'
      . '<iframe src="' . $src . '" title="' . $title . '" '
      . 'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0" '
      . 'allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;fullscreen" '
      . 'allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>';
  }
}

/**
 * Патч: подмена результата normalize для rumble на уровне импорта метаданных
 */
if (!function_exists('video_fetch_meta_rumble_boost')) {
  function video_fetch_meta_rumble_boost(string $url): array {
    $out = ['title' => null, 'description' => null, 'thumbnail' => null, 'embed' => null, 'platform' => 'rumble'];
    $oe = video_rumble_oembed($url);
    if ($oe) {
      $out['title'] = $oe['title'] ?? null;
      $out['thumbnail'] = $oe['thumbnail_url'] ?? null;
      $out['description'] = $oe['author_name'] ?? null;
      if (!empty($oe['html']) && preg_match('#src=["\']([^"\']+)["\']#i', $oe['html'], $m)) {
        $out['embed'] = $m[1];
      }
    }
    if (!$out['embed']) {
      $out['embed'] = normalize_video_embed_rumble_fixed($url);
    }
    return $out;
  }
}
