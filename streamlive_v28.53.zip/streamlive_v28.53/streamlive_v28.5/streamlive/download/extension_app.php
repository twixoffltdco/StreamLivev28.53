<?php
$srcDir = dirname(__DIR__) . '/extension_app';
if (!is_dir($srcDir) || !class_exists('ZipArchive')) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=utf-8');
  echo 'Нет extension_app или ZipArchive';
  exit;
}
$tmp = sys_get_temp_dir() . '/sl292_' . md5(microtime()) . '.zip';
$zip = new ZipArchive();
$zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$root = realpath($srcDir);
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $file) {
  if (!$file->isFile()) continue;
  $full = $file->getRealPath();
  $local = str_replace('\\', '/', substr($full, strlen($root) + 1));
  $zip->addFile($full, $local);
}
$zip->close();
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="StreamLive-App.zip"');
header('Content-Length: ' . filesize($tmp));
readfile($tmp);
@unlink($tmp);
exit;
