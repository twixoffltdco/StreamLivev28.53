<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
if (is_file(__DIR__ . '/includes/wallet.php')) require_once __DIR__ . '/includes/wallet.php';
if (is_file(__DIR__ . '/includes/wallet_pay.php')) require_once __DIR__ . '/includes/wallet_pay.php';
$user = current_user();
$id = (int)($_POST['channel_id'] ?? $_GET['channel_id'] ?? 0);
if (!$user || $id <= 0) { header('Location: /channels.php'); exit; }
$ch = null;
try {
  $st = db()->prepare('SELECT * FROM channels WHERE id=?');
  $st->execute([$id]);
  $ch = $st->fetch();
} catch (Throwable $e) {}
if (!$ch) { header('Location: /channels.php'); exit; }
$r = wallet_pay_channel_now((int)$user['id'], $ch);
$slug = $ch['slug'] ?? '';
$q = !empty($r['ok']) ? 'paid=1' : ('pay_err=' . urlencode($r['error'] ?? 'error'));
header('Location: /channel.php?' . ($slug ? 'slug=' . urlencode($slug) . '&' : 'id=' . $id . '&') . $q);
exit;
