(function(){
  try{if(localStorage.getItem('sl_ext_banner_hide')==='1')return;}catch(e){}
  function run(){
    if(document.getElementById('sl-ext-banner'))return;
    var b=document.createElement('div');
    b.id='sl-ext-banner';
    b.style.cssText='position:fixed;left:12px;right:12px;bottom:12px;z-index:99999;background:#334155;color:#fff;padding:14px;border-radius:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;font:14px system-ui';
    b.innerHTML='<div style="flex:1"><b>Скачать приложение (расширение)</b><br>URL сайта пропишется сам с этого домена</div><a href="/download/extension_app.php" style="background:#fff;color:#111;padding:10px 14px;border-radius:10px;font-weight:800;text-decoration:none">Скачать</a><button id="sl-ext-x" style="background:0;border:0;color:#fff;font-size:18px">×</button>';
    document.body.appendChild(b);
    document.getElementById('sl-ext-x').onclick=function(){try{localStorage.setItem('sl_ext_banner_hide','1');}catch(e){}b.remove();};
  }
  if(document.body)run();else document.addEventListener('DOMContentLoaded',run);
})();
