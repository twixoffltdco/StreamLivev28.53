(function () {
  function qs(s, r) { return (r || document).querySelector(s); }
  function openModal(id) {
    var modal = qs('#dz-article-modal');
    var body = qs('#dz-article-body');
    if (!modal || !body) return;
    body.innerHTML = 'Загрузка…';
    modal.hidden = false;
    document.documentElement.style.overflow = 'hidden';
    fetch('/api/article_get.php?id=' + encodeURIComponent(id), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) {
          body.innerHTML = '<p style="opacity:.7">' + (d && d.error ? d.error : 'Не найдено') + '</p>';
          return;
        }
        var a = d.article;
        var html = '';
        if (a.cover_url) html += '<img class="dz-art-cover" src="' + esc(a.cover_url) + '" alt="">';
        html += '<h1 class="dz-art-title">' + esc(a.title) + '</h1>';
        html += '<p class="dz-art-meta">' + esc(a.username || '') +
          (a.channel_title ? ' · ' + esc(a.channel_title) : '') +
          (a.created_at ? ' · ' + esc(a.created_at) : '') +
          ' · ' + (a.views || 0) + ' просм.</p>';
        html += '<div class="dz-art-text">' + esc(a.body).replace(/\n/g, '<br>') + '</div>';
        body.innerHTML = html;
      })
      .catch(function () {
        body.innerHTML = '<p style="opacity:.7">Ошибка загрузки</p>';
      });
  }
  function closeModal() {
    var modal = qs('#dz-article-modal');
    if (!modal) return;
    modal.hidden = true;
    document.documentElement.style.overflow = '';
  }
  function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (t && t.closest && t.closest('[data-dz-close]')) { closeModal(); return; }
    var btn = t && t.closest ? t.closest('.dz-open-article') : null;
    if (btn) {
      e.preventDefault();
      openModal(btn.getAttribute('data-id'));
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
  });
  // open by ?article=ID
  try {
    var m = location.search.match(/[?&]article=(\d+)/);
    if (m) {
      document.addEventListener('DOMContentLoaded', function () { openModal(m[1]); });
      if (document.readyState !== 'loading') openModal(m[1]);
    }
  } catch (e) {}
  window.dzOpenArticle = openModal;
})();
