<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/user_secrets.php';

$user = current_user();
if (!$user) {
  flash_set('error', 'Нужна авторизация');
  redirect('/login.php');
}

try {
  db()->exec("CREATE TABLE IF NOT EXISTS site_mirrors (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    mirror_url VARCHAR(512) NOT NULL,
    db_host VARCHAR(255) NOT NULL,
    db_name VARCHAR(255) NOT NULL,
    db_user VARCHAR(255) NOT NULL,
    db_pass_enc TEXT NOT NULL,
    last_sync_at DATETIME NULL DEFAULT NULL,
    last_status VARCHAR(64) NULL DEFAULT NULL,
    last_error TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_mirror_user (user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

$row = null;
try {
  $st = db()->prepare('SELECT * FROM site_mirrors WHERE user_id = ? LIMIT 1');
  $st->execute([(int)$user['id']]);
  $row = $st->fetch() ?: null;
} catch (Throwable $e) {}

$error = '';
$ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_verify();
  $action = (string)($_POST['action'] ?? 'save');
  if ($action === 'disable' && $row) {
    try {
      db()->prepare('UPDATE site_mirrors SET is_active = 0 WHERE user_id = ?')->execute([(int)$user['id']]);
      $ok = 'Зеркало отключено';
      $row['is_active'] = 0;
    } catch (Throwable $e) { $error = $e->getMessage(); }
  } else {
    $url = trim((string)($_POST['mirror_url'] ?? ''));
    $host = trim((string)($_POST['db_host'] ?? ''));
    $name = trim((string)($_POST['db_name'] ?? ''));
    $dbu  = trim((string)($_POST['db_user'] ?? ''));
    $dbp  = (string)($_POST['db_pass'] ?? '');
    if ($url === '' || $host === '' || $name === '' || $dbu === '') {
      $error = 'Заполните URL зеркала и доступы к MySQL';
    } elseif (!$row && $dbp === '') {
      $error = 'Укажите пароль БД';
    } else {
      try {
        if ($row && $dbp === '') {
          // пароль не меняли — оставляем старый
          db()->prepare(
            'UPDATE site_mirrors SET mirror_url=?, db_host=?, db_name=?, db_user=?, is_active=1 WHERE user_id=?'
          )->execute([$url, $host, $name, $dbu, (int)$user['id']]);
        } else {
          $enc = user_secrets_encrypt($dbp);
          if ($enc === '' && $dbp !== '') {
            throw new RuntimeException('Не удалось зашифровать пароль (openssl)');
          }
          if ($row) {
            db()->prepare(
              'UPDATE site_mirrors SET mirror_url=?, db_host=?, db_name=?, db_user=?, db_pass_enc=?, is_active=1 WHERE user_id=?'
            )->execute([$url, $host, $name, $dbu, $enc, (int)$user['id']]);
          } else {
            db()->prepare(
              'INSERT INTO site_mirrors (user_id, mirror_url, db_host, db_name, db_user, db_pass_enc, is_active)
               VALUES (?,?,?,?,?,?,1)'
            )->execute([(int)$user['id'], $url, $host, $name, $dbu, $enc]);
          }
        }
        $ok = 'Зеркало сохранено. Синхронизация по cron (раз в сутки). Один аккаунт — одно зеркало.';
        $st = db()->prepare('SELECT * FROM site_mirrors WHERE user_id = ? LIMIT 1');
        $st->execute([(int)$user['id']]);
        $row = $st->fetch() ?: null;
      } catch (Throwable $e) {
        $error = 'Ошибка: ' . $e->getMessage();
      }
    }
  }
}

$pageTitle = 'Сайт-зеркало';
require_once __DIR__ . '/includes/header.php';
?>
<div class="container" style="max-width:680px;padding:24px 16px">
  <h1 style="margin:0 0 8px;font-size:22px">Сайт-зеркало</h1>
  <p style="color:var(--text-dim,#aaa);margin:0 0 20px;font-size:14px">
    Один аккаунт — одно зеркало. Укажите URL и MySQL зеркала (FTP для файлов — в разделе FTP): раз в сутки cron подтянет обновления (схема + данные платформы как зеркало).
    Пароль БД хранится зашифрованным.
  </p>

  <?php if ($error): ?><div class="alert alert-error" style="margin-bottom:14px"><?= e($error) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="alert alert-success" style="margin-bottom:14px"><?= e($ok) ?></div><?php endif; ?>

  <?php if ($row): ?>
    <div style="padding:12px 14px;border-radius:10px;background:rgba(255,255,255,.04);margin-bottom:16px;font-size:13px">
      <div>URL: <b><?= e($row['mirror_url']) ?></b></div>
      <div>БД: <?= e($row['db_user']) ?>@<?= e($row['db_host']) ?> / <?= e($row['db_name']) ?></div>
      <div>Статус: <?= !empty($row['is_active']) ? 'активно' : 'выкл' ?>
        · последняя синхронизация: <?= e((string)($row['last_sync_at'] ?: 'ещё не было')) ?>
        <?= $row['last_status'] ? ' · ' . e($row['last_status']) : '' ?>
      </div>
      <?php if (!empty($row['last_error'])): ?><div style="color:#f88">Ошибка: <?= e($row['last_error']) ?></div><?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="post" style="display:grid;gap:12px">
    <?= csrf_field() ?>
    <label style="display:grid;gap:6px"><span>URL зеркала</span>
      <input name="mirror_url" required value="<?= e($row['mirror_url'] ?? '') ?>" placeholder="https://mirror.example.com"
        style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:inherit">
    </label>
    <label style="display:grid;gap:6px"><span>MySQL host</span>
      <input name="db_host" required value="<?= e($row['db_host'] ?? '') ?>" placeholder="localhost"
        style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:inherit">
    </label>
    <label style="display:grid;gap:6px"><span>MySQL database</span>
      <input name="db_name" required value="<?= e($row['db_name'] ?? '') ?>"
        style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:inherit">
    </label>
    <label style="display:grid;gap:6px"><span>MySQL user</span>
      <input name="db_user" required value="<?= e($row['db_user'] ?? '') ?>"
        style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:inherit">
    </label>
    <label style="display:grid;gap:6px"><span>MySQL password</span>
      <input type="password" name="db_pass" <?= $row ? '' : 'required' ?> autocomplete="new-password" placeholder="<?= $row ? '••••••••' : '' ?>"
        style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:inherit">
    </label>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button type="submit" name="action" value="save" class="btn btn-primary">Сохранить зеркало</button>
      <?php if ($row && !empty($row['is_active'])): ?>
        <button type="submit" name="action" value="disable" class="btn btn-outline">Отключить</button>
      <?php endif; ?>
    </div>
  </form>
  <p style="font-size:12px;color:var(--text-dim,#888);margin-top:16px">
    Cron на <b>основном</b> сайте раз в сутки: <code>php cron/mirror_sync.php</code> — заливает <b>весь скрипт</b> по FTP и обновляет <b>таблицы БД</b> на зеркале (videos, channels, articles…). FTP: <a href="/account_external_ids.php">настройка</a> (раз в 30 дней). На зеркале должен быть свой <code>config</code> с доступом к своей БД; код перезаписывается, данные контента — с основного сайта.
  </p>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
