const DEF = 'https://streamliveru.web1.websitegame.ru';
chrome.storage.sync.get({ baseUrl: DEF }, (c) => {
  document.getElementById('baseUrl').value = c.baseUrl || DEF;
});
document.getElementById('save').onclick = () => {
  let v = document.getElementById('baseUrl').value.trim().replace(/\/$/, '');
  if (!/^https?:\/\//i.test(v)) v = 'http://' + v;
  chrome.storage.sync.set({ baseUrl: v }, () => alert('Сохранено: ' + v));
};
