(function () {
  if (window.__slGiga292) return;
  window.__slGiga292 = true;

  var APP = (typeof STREAMLIVE_APP_NAME !== 'undefined') ? STREAMLIVE_APP_NAME : 'StreamLive App';
  var VER = (typeof STREAMLIVE_APP_VERSION !== 'undefined') ? STREAMLIVE_APP_VERSION : '2.9.2';

  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /**
   * Распознать скрипт StreamLive на ЛЮБОМ домене (не whitelist доменов).
   */
  function detectStreamLiveSync() {
    if (document.querySelector('meta[name="sl-platform"][content="streamlive"]')) return true;
    if (document.querySelector('meta[name="generator"][content*="StreamLive" i]')) return true;
    if (document.documentElement.getAttribute('data-platform') === 'streamlive') return true;
    if (document.body && document.body.getAttribute('data-platform') === 'streamlive') return true;
    if (window.__STREAMLIVE__ || window.STREAMLIVE || window.__USER) {
      // __USER alone weak — combine
    }
    // типичные пути/ссылки скрипта
    var markers = [
      'a[href*="studio.php"]',
      'a[href*="platforma/studio"]',
      'a[href*="video_import"]',
      'link[href*="/assets/css"]',
      'script[src*="streamlive"]',
      '#sl-giga-shell'
    ];
    var hits = 0;
    for (var i = 0; i < markers.length; i++) {
      if (document.querySelector(markers[i])) hits++;
    }
    if (hits >= 2) return true;
    // текст в footer
    try {
      var ft = document.body ? document.body.innerText : '';
      if (/StreamLive|streamlive/i.test(ft) && document.querySelector('a[href*="forum"]')) return true;
    } catch (e) {}
    return false;
  }

  function detectStreamLiveAsync(cb) {
    if (detectStreamLiveSync()) {
      cb(true);
      return;
    }
    // health API — главный признак нашего PHP-скрипта
    var paths = ['/api/ext_health.php', '/ext_health.php', '/api/native_ping.php'];
    var left = paths.length;
    var ok = false;
    paths.forEach(function (p) {
      fetch(location.origin + p, {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { Accept: 'application/json' }
      }).then(function (r) {
        return r.text().then(function (t) {
          if (r.ok && t && t.charAt(0) === '{') {
            try {
              var j = JSON.parse(t);
              if (j && (j.ok === true || j.t || j.name === 'StreamLive')) ok = true;
            } catch (e) {}
          }
        });
      }).catch(function () {}).finally(function () {
        left--;
        if (left === 0) cb(ok);
      });
    });
  }

  function showStub(msg) {
    if (document.getElementById('sl-giga-stub')) return;
    var s = document.createElement('div');
    s.id = 'sl-giga-stub';
    s.innerHTML = '<div style="font-size:42px;margin-bottom:12px">📡</div><h2 style="margin:0 0 8px">Платформа временно недоступна</h2><p style="opacity:.7;max-width:300px">' +
      (msg || 'Зайдите позже.') + '</p><button type="button" id="sl-giga-retry">Повторить</button>';
    (document.body || document.documentElement).appendChild(s);
    document.getElementById('sl-giga-retry').onclick = function () { location.reload(); };
  }

  function pickUsername() {
    var meta = document.querySelector('meta[name="sl-username"]');
    if (meta && meta.content.trim()) return meta.content.trim();
    var du = document.documentElement.getAttribute('data-sl-user');
    if (du && du.trim()) return du.trim();
    try {
      if (window.__USER && window.__USER.username) return String(window.__USER.username);
    } catch (e) {}
    return '';
  }
  function pickUserId() {
    var meta = document.querySelector('meta[name="sl-user-id"]');
    if (meta && meta.content) return meta.content.trim();
    try {
      if (window.__USER && window.__USER.id) return String(window.__USER.id);
    } catch (e) {}
    return '';
  }
  function pickAvatar() {
    var meta = document.querySelector('meta[name="sl-avatar"]');
    if (meta && meta.content) return meta.content.trim();
    try {
      if (window.__USER && (window.__USER.avatar || window.__USER.avatar_url)) {
        return String(window.__USER.avatar || window.__USER.avatar_url);
      }
    } catch (e) {}
    return '';
  }
  function pickProfileUrl() {
    var id = pickUserId();
    if (id) return location.origin + '/profile.php?id=' + encodeURIComponent(id);
    var name = pickUsername();
    if (name) return location.origin + '/profile.php?user=' + encodeURIComponent(name);
    return location.origin + '/profile.php';
  }

  function greetingLine(name) {
    var h = new Date().getHours();
    var day = new Date().getDay();
    var part = h < 6 ? 'Доброй ночи' : h < 12 ? 'Доброе утро' : h < 18 ? 'Добрый день' : 'Добрый вечер';
    var days = ['Удачного воскресенья','Удачного понедельника','Удачного вторника','Удачной среды','Удачного четверга','Удачной пятницы','Удачной субботы'];
    var randoms = ['Привет','С возвращением','Рады видеть','Добро пожаловать'];
    var roll = Math.random();
    var head = roll < 0.45 ? part : (roll < 0.75 ? days[day] : randoms[Math.floor(Math.random() * randoms.length)]);
    return name ? head + ', ' + name : head;
  }

  function toast(msg) {
    var t = document.getElementById('sl-giga-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'sl-giga-toast';
      document.documentElement.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 2800);
  }
  function todayKey() {
    var d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }
  function storageGet(cb) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get({ sl_coins: 0, sl_last_bonus: '' }, function (d) {
        cb(d.sl_coins || 0, d.sl_last_bonus || '');
      });
    } else {
      try {
        cb(parseInt(localStorage.getItem('sl_coins') || '0', 10) || 0, localStorage.getItem('sl_last_bonus') || '');
      } catch (e) { cb(0, ''); }
    }
  }
  function storageSet(coins, last, cb) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ sl_coins: coins, sl_last_bonus: last }, cb || function () {});
    } else {
      try {
        localStorage.setItem('sl_coins', String(coins));
        localStorage.setItem('sl_last_bonus', last);
      } catch (e) {}
      if (cb) cb();
    }
  }

  function exchangeCoins() {
    storageGet(function (coins, last) {
      if (coins < 100) {
        toast('Нужно 100 монет (сейчас ' + coins + ')');
        return;
      }
      fetch(location.origin + '/api/ext_coins_exchange.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ coins: 100, version: VER })
      }).then(function (r) { return r.json(); }).then(function (j) {
        if (j && j.ok && j.code) {
          storageSet(coins - 100, last, function () {
            toast('Промокод: ' + j.code);
            try { prompt('Промокод StreamLive:', j.code); } catch (e) {}
            refreshPill(coins - 100, last);
          });
        } else toast((j && j.error) || 'Обмен недоступен');
      }).catch(function () { toast('API обмена недоступен'); });
    });
  }

  var refreshPill = function () {};

  function buildShell() {
    if (document.getElementById('sl-giga-shell')) return;
    document.documentElement.classList.add('sl-giga');

    var name = pickUsername();
    var av = pickAvatar();
    var profileUrl = pickProfileUrl();

    var shell = document.createElement('div');
    shell.id = 'sl-giga-shell';

    var hello = document.createElement('a');
    hello.id = 'sl-giga-hello';
    hello.href = profileUrl;
    hello.innerHTML =
      (av ? '<img class="av" alt="" src="' + esc(av) + '" onerror="this.remove()">' : '<div class="av"></div>') +
      '<div class="txt"><b id="sl-giga-greet">' + esc(greetingLine(name)) + (name ? ' ✨' : '') + '</b>' +
      '<span id="sl-giga-sub">' + (name ? 'Перейти в профиль' : 'Войдите — подтянется ник') + '</span></div>';
    hello.addEventListener('click', function (e) {
      e.preventDefault();
      location.href = pickProfileUrl();
    });

    var row = document.createElement('div');
    row.id = 'sl-giga-search-row';
    row.innerHTML =
      '<div class="box"><span style="opacity:.5">🔍</span>' +
      '<input id="sl-giga-q" type="search" placeholder="Найти на StreamLive" autocomplete="off"></div>' +
      '<button type="button" id="sl-giga-dice" title="Монетки">🎲</button>';

    var pill = document.createElement('div');
    pill.id = 'sl-giga-coins-pill';

    shell.appendChild(hello);
    shell.appendChild(row);
    shell.appendChild(pill);
    (document.body || document.documentElement).appendChild(shell);

    document.getElementById('sl-giga-q').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.value.trim()) {
        location.href = '/search.php?q=' + encodeURIComponent(e.target.value.trim());
      }
    });

    refreshPill = function (coins, last) {
      var extra = coins >= 100
        ? ' · <a href="#" id="sl-giga-ex" style="color:#93c5fd">обменять 100→промо</a>'
        : '';
      pill.innerHTML = '🪙 ' + coins + (last === todayKey() ? ' · сегодня +5' : ' · жми 🎲') + extra;
      var a = document.getElementById('sl-giga-ex');
      if (a) a.onclick = function (e) { e.preventDefault(); exchangeCoins(); };
    };

    storageGet(function (coins, last) {
      refreshPill(coins, last);
      if (last === todayKey()) document.getElementById('sl-giga-dice').classList.add('done');
    });

    document.getElementById('sl-giga-dice').onclick = function () {
      var dice = document.getElementById('sl-giga-dice');
      storageGet(function (coins, last) {
        if (last === todayKey()) {
          toast('Уже сегодня · 🪙 ' + coins);
          return;
        }
        var next = coins + 5;
        storageSet(next, todayKey(), function () {
          toast('+5 · 🪙 ' + next);
          dice.classList.add('done');
          refreshPill(next, todayKey());
        });
      });
    };

    // Ник с API сессии этого origin
    fetch(location.origin + '/api/ext_app_meta.php', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.user) return;
      var n = j.user.username || '';
      var id = j.user.id || '';
      var av2 = j.user.avatar || '';
      if (n) {
        document.getElementById('sl-giga-greet').textContent = greetingLine(n) + ' ✨';
        document.getElementById('sl-giga-sub').textContent = 'Перейти в профиль';
        hello.href = id
          ? (location.origin + '/profile.php?id=' + encodeURIComponent(id))
          : (location.origin + '/profile.php?user=' + encodeURIComponent(n));
      }
      if (av2) {
        var img = hello.querySelector('img.av');
        if (img) img.src = av2;
        else {
          var d = hello.querySelector('div.av');
          if (d) {
            var im = document.createElement('img');
            im.className = 'av';
            im.src = av2;
            d.replaceWith(im);
          }
        }
      }
    }).catch(function () {});
  }

  function buildNav() {
    if (document.getElementById('sl-giga-bottom')) return;
    var nav = document.createElement('div');
    nav.id = 'sl-giga-bottom';
    var path = location.pathname || '/';
    function item(href, icon, label) {
      var on = path === href || (href.length > 1 && path.indexOf(href.replace('.php', '')) === 0);
      return '<a href="' + href + '" class="' + (on ? 'on' : '') + '"><span style="font-size:18px">' + icon + '</span>' + label + '</a>';
    }
    nav.innerHTML =
      item('/', '🏠', 'Главная') +
      '<a class="fab" href="/studio.php?from_app=1" title="Студия">+</a>' +
      item('/forum.php', '💬', 'Чаты');
    (document.body || document.documentElement).appendChild(nav);
  }

  // keepalive пока вкладка открыта (даже в фоне)
  function keepAlive() {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'sl_alive', origin: location.origin });
      }
    } catch (e) {}
    // лёгкий ping сайта — меньше «сна» на бесплатных хостах
    try {
      fetch(location.origin + '/api/ext_health.php', {
        credentials: 'omit',
        cache: 'no-store'
      }).catch(function () {});
    } catch (e) {}
  }

  function activate() {
    try {
      document.cookie = 'sl_native_app=1;path=/;max-age=1209600;SameSite=Lax';
    } catch (e) {}
    buildShell();
    buildNav();
    keepAlive();
    setInterval(keepAlive, 60000);
    window.addEventListener('offline', function () {
      showStub('Нет сети. Платформа временно недоступна. Зайдите позже.');
    });
  }

  detectStreamLiveAsync(function (yes) {
    if (!yes) return; // не StreamLive — молча выходим
    if (document.body) activate();
    else document.addEventListener('DOMContentLoaded', activate);
  });
})();
