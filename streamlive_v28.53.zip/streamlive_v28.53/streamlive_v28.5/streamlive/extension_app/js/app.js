(async function () {
  function toast(msg) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2800);
  }
  function showOffline(msg) {
    const el = document.getElementById('offline');
    if (!el) return;
    el.style.display = 'flex';
    const p = el.querySelector('p');
    if (p) p.textContent = msg || 'Платформа временно недоступна. Зайдите позже.';
  }
  function hideOffline() {
    const el = document.getElementById('offline');
    if (el) el.style.display = 'none';
  }

  function bakedUrl() {
    if (typeof STREAMLIVE_BASE_URL === 'string' && STREAMLIVE_BASE_URL) {
      return STREAMLIVE_BASE_URL.replace(/\/$/, '');
    }
    return '';
  }

  async function getBase() {
    const baked = bakedUrl();
    if (baked) {
      try { await chrome.storage.sync.set({ baseUrl: baked }); } catch (e) {}
      return baked;
    }
    try {
      const { baseUrl } = await chrome.storage.sync.get({ baseUrl: '' });
      if (baseUrl) return String(baseUrl).replace(/\/$/, '');
    } catch (e) {}
    return 'https://streamliveru.web1.websitegame.ru';
  }

  function deviceId() {
    try {
      let id = localStorage.getItem('sl_app_device');
      if (!id) {
        id = 'app-' + Math.random().toString(36).slice(2);
        localStorage.setItem('sl_app_device', id);
      }
      return id;
    } catch (e) { return 'app'; }
  }

  async function api(base, path, opts) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 12000);
    try {
      const res = await fetch(base + path, {
        method: (opts && opts.method) || 'GET',
        headers: Object.assign({ Accept: 'application/json' }, (opts && opts.headers) || {}),
        body: opts && opts.body,
        credentials: 'omit',
        cache: 'no-store',
        mode: 'cors',
        signal: ctrl.signal
      });
      clearTimeout(timer);
      const text = await res.text();
      try { return JSON.parse(text); } catch (e) { return { ok: false, status: res.status }; }
    } catch (e) {
      clearTimeout(timer);
      return { ok: false, offline: true, error: String(e && e.message ? e.message : e) };
    }
  }

  function applyBrand(name) {
    if (typeof brandFromName !== 'function') return;
    const b = brandFromName(name);
    document.documentElement.style.setProperty('--accent', b.accent);
    document.documentElement.style.setProperty('--bg', b.bg);
    document.getElementById('splashTitle').textContent = b.title;
    document.getElementById('splashLogo').textContent = (b.title || 'S').charAt(0).toUpperCase();
    document.title = b.title;
  }

  function openPath(base, path) {
    const join = path.indexOf('?') >= 0 ? '&' : '?';
    chrome.tabs.create({ url: base + path + join + 'from_app=1&ext=1' });
  }

  function esc(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function todayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }
  async function loadCoins() {
    const data = await chrome.storage.local.get({ coins: 0, lastBonus: '' });
    const el = document.getElementById('coinsVal');
    if (el) el.textContent = String(data.coins || 0);
    return data;
  }
  async function claimBonus(base) {
    const data = await loadCoins();
    if (data.lastBonus === todayKey()) { toast('Уже получено сегодня'); return; }
    const coins = (data.coins || 0) + 5;
    await chrome.storage.local.set({ coins, lastBonus: todayKey() });
    document.getElementById('coinsVal').textContent = String(coins);
    toast('+5 монет');
    api(base, '/api/native_ping.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ device_id: deviceId(), platform: 'extension', version: '2.3.0' })
    });
  }

  function renderHome(base, data) {
    const videos = data.videos || [];
    const channels = data.channels || [];
    const forum = data.threads || [];
    const feat = document.getElementById('cardsFeatured');
    feat.innerHTML = '';
    if (!videos.length) {
      feat.innerHTML = '<div class="card"><h4>Лента пуста</h4><p>Контент с сайта: ' + esc(base) + '</p></div>';
    } else {
      videos.slice(0, 2).forEach((v, i) => {
        const a = document.createElement('a');
        a.className = 'card';
        a.href = '#';
        a.style.background = i % 2 ? 'linear-gradient(135deg,#581c87,#9d174d)' : 'linear-gradient(135deg,#1e3a8a,#312e81)';
        a.innerHTML = '<h4>' + esc(v.title || 'Видео') + '</h4>';
        a.onclick = (e) => { e.preventDefault(); openPath(base, '/video.php?slug=' + encodeURIComponent(v.slug || '')); };
        feat.appendChild(a);
      });
    }
    const row = document.getElementById('rowChannels');
    row.innerHTML = '';
    channels.slice(0, 16).forEach((c) => {
      const a = document.createElement('a');
      a.className = 'person';
      a.href = '#';
      a.innerHTML = '<div class="ph"></div><div class="name">' + esc(c.title || 'Канал') + '</div>';
      a.onclick = (e) => { e.preventDefault(); openPath(base, c.slug ? '/channel.php?slug=' + encodeURIComponent(c.slug) : '/channels.php'); };
      row.appendChild(a);
    });
    const list = document.getElementById('listVideos');
    list.innerHTML = '';
    videos.slice(0, 30).forEach((v) => {
      const a = document.createElement('a');
      a.className = 'list-item';
      a.href = '#';
      a.innerHTML = '<img alt="" src="' + esc(v.thumbnail_url || 'icons/icon-48.png') + '" onerror="this.src=\'icons/icon-48.png\'"><div class="t"><b>' + esc(v.title || 'Видео') + '</b><span>видео</span></div>';
      a.onclick = (e) => { e.preventDefault(); openPath(base, '/video.php?slug=' + encodeURIComponent(v.slug || '')); };
      list.appendChild(a);
    });
    const more = document.getElementById('listMore');
    if (more) {
      more.innerHTML = '';
      [['Все видео','/videos.php'],['Каналы','/channels.php'],['Форум','/forum.php'],['Студия','/studio.php'],['Партнёры','/partners.php'],['Профиль','/profile.php']].forEach(function (L) {
        const a = document.createElement('a');
        a.className = 'list-item';
        a.href = '#';
        a.innerHTML = '<div class="t"><b>' + esc(L[0]) + '</b></div>';
        a.onclick = (e) => { e.preventDefault(); openPath(base, L[1]); };
        more.appendChild(a);
      });
    }
    const fl = document.getElementById('listForum');
    const fe = document.getElementById('forumEmpty');
    if (fl) {
      fl.innerHTML = '';
      if (!forum.length) { if (fe) fe.style.display = 'block'; }
      else {
        if (fe) fe.style.display = 'none';
        forum.forEach((t) => {
          const a = document.createElement('a');
          a.className = 'list-item';
          a.href = '#';
          a.innerHTML = '<div class="t"><b>' + esc(t.title || 'Тема') + '</b><span>' + esc(t.username || '') + '</span></div>';
          a.onclick = (e) => { e.preventDefault(); openPath(base, '/forum_thread.php?id=' + encodeURIComponent(t.id || '')); };
          fl.appendChild(a);
        });
      }
    }
  }

  document.querySelectorAll('.nav button[data-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav button[data-tab]').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
      const panel = document.getElementById('panel-' + btn.getAttribute('data-tab'));
      if (panel) panel.classList.add('active');
    });
  });
  const fab = document.getElementById('fabPlus');
  if (fab) fab.onclick = () => {
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    document.getElementById('panel-create').classList.add('active');
  };

  const base = await getBase();
  let siteName = 'App';

  const health = await api(base, '/api/ext_health.php');
  if (health.offline || health.ok === false) {
    showOffline('Платформа временно недоступна. Зайдите позже.\n\nДомен приложения: ' + base);
  } else {
    hideOffline();
    const meta = await api(base, '/api/ext_app_meta.php');
    if (meta && meta.name) siteName = meta.name;
    if (meta && meta.user) {
      document.getElementById('userName').textContent = meta.user.username || 'Пользователь';
      document.getElementById('userSub').textContent = meta.user.native_badge ? 'Серебряная галочка' : base.replace(/^https?:\/\//, '');
      if (meta.user.avatar) document.getElementById('userAvatar').src = meta.user.avatar;
    } else {
      document.getElementById('userSub').textContent = base.replace(/^https?:\/\//, '');
    }
    const feed = await api(base, '/api/ext_app_feed.php');
    if (!feed.offline && feed.ok !== false) {
      renderHome(base, feed);
      api(base, '/api/native_ping.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_id: deviceId(), platform: 'extension', version: '2.3.0' })
      });
    } else {
      showOffline('Платформа временно недоступна. Зайдите позже.');
    }
  }

  applyBrand(siteName);
  await loadCoins();

  document.getElementById('btnBonus').onclick = () => claimBonus(base);
  document.getElementById('btnOpenSite').onclick = () => openPath(base, '/');
  document.getElementById('btnReload').onclick = () => location.reload();
  document.getElementById('linkAllVideos').onclick = (e) => { e.preventDefault(); openPath(base, '/videos.php'); };
  document.getElementById('linkAllChannels').onclick = (e) => { e.preventDefault(); openPath(base, '/channels.php'); };
  document.getElementById('actImport').onclick = (e) => { e.preventDefault(); openPath(base, '/video_import.php'); };
  document.getElementById('actChannel').onclick = (e) => { e.preventDefault(); openPath(base, '/new_channel.php'); };
  document.getElementById('actThread').onclick = (e) => { e.preventDefault(); openPath(base, '/forum_new_thread.php'); };
  document.getElementById('q').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.value.trim()) openPath(base, '/search.php?q=' + encodeURIComponent(e.target.value.trim()));
  });
  document.getElementById('offlineRetry').onclick = () => location.reload();

  setTimeout(() => {
    document.getElementById('splash').classList.add('hide');
    document.getElementById('app').style.visibility = 'visible';
  }, 600);
})();
