/** Цветовая гамма от названия проекта */
function brandFromName(name) {
  name = (name || 'StreamLive').toString();
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  const hues = [
    { accent: '#3b82f6', bg: '#0b1220', name: 'blue' },
    { accent: '#a855f7', bg: '#12081f', name: 'purple' },
    { accent: '#22c55e', bg: '#07140c', name: 'green' },
    { accent: '#f59e0b', bg: '#140f05', name: 'amber' },
    { accent: '#ef4444', bg: '#140808', name: 'red' },
    { accent: '#06b6d4', bg: '#06141a', name: 'cyan' },
    { accent: '#c0c7d1', bg: '#0f1115', name: 'silver' }
  ];
  const b = hues[h % hues.length];
  b.title = name;
  return b;
}
if (typeof module !== 'undefined') module.exports = { brandFromName };
