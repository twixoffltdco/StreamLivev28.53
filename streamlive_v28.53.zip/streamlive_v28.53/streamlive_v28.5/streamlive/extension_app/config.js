var STREAMLIVE_BASE_URL = ""; // пусто = авто с текущего origin, если это StreamLive
var STREAMLIVE_APP_NAME = "StreamLive App";
var STREAMLIVE_APP_VERSION = "2.9.2";
