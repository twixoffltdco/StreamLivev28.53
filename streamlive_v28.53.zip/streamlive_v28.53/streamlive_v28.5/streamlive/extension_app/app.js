(async function () {
  function base() {
    var u = (typeof STREAMLIVE_BASE_URL !== 'undefined' && STREAMLIVE_BASE_URL)
      ? String(STREAMLIVE_BASE_URL) : '';
    return u.replace(/\/$/, '');
  }
  function esc(s) {
    return String(s || '').replace(/[&<>"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c];
    });
  }
  function openSite(path) {
    var b = base();
    var join = (path || '/').indexOf('?') >= 0 ? '&' : '?';
    chrome.tabs.create({ url: b + (path || '/') + join + 'from_app=1&ext=1' });
  }

  async function getJson(url) {
    var res = await fetch(url, {
      method: 'GET',
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-store',
      headers: { Accept: 'application/json' }
    });
    var text = await res.text();
    // если PHP отдал HTML с ошибкой
    if (text.charAt(0) === '<' || text.indexOf('<br') >= 0) {
      throw new Error('HTML instead of JSON (' + res.status + ')');
    }
    return JSON.parse(text);
  }

  /** Пробуем /api/... и корневые /ext_*.php */
  async function loadFeed(b) {
    var paths = [
      '/api/ext_app_feed.php',
      '/ext_app_feed.php',
      '/api/native_home.php',
      '/api/ext_app_feed.php?i=1'
    ];
    var lastErr = '';
    for (var i = 0; i < paths.length; i++) {
      try {
        var j = await getJson(b + paths[i]);
        if (j && (j.ok || j.videos)) {
          j._path = paths[i];
          return j;
        }
        lastErr = paths[i] + ' empty';
      } catch (e) {
        lastErr = paths[i] + ': ' + (e.message || e);
      }
    }
    return { ok: false, videos: [], channels: [], threads: [], error: lastErr };
  }

  async function loadMeta(b) {
    var paths = ['/api/ext_app_meta.php', '/ext_app_meta.php'];
    for (var i = 0; i < paths.length; i++) {
      try {
        var j = await getJson(b + paths[i]);
        if (j && j.name) return j;
      } catch (e) {}
    }
    return { ok: true, name: b.replace(/^https?:\/\//, '').split('/')[0] || 'App' };
  }

  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  }
  chrome.storage.local.get({ coins: 0, lastBonus: '' }, function (d) {
    document.getElementById('coins').textContent = '🪙 ' + (d.coins || 0);
  });
  document.getElementById('btnBonus').onclick = function () {
    chrome.storage.local.get({ coins: 0, lastBonus: '' }, function (d) {
      if (d.lastBonus === today()) return;
      var c = (d.coins || 0) + 5;
      chrome.storage.local.set({ coins: c, lastBonus: today() });
      document.getElementById('coins').textContent = '🪙 ' + c;
    });
  };
  document.getElementById('btnReload').onclick = function () { location.reload(); };
  document.getElementById('btnSite').onclick = function () { openSite('/'); };
  document.querySelectorAll('[data-go]').forEach(function (btn) {
    btn.onclick = function () { openSite(btn.getAttribute('data-go')); };
  });

  var b = base();
  if (b) chrome.storage.sync.set({ baseUrl: b });

  document.getElementById('splash').classList.add('hide');

  var meta = await loadMeta(b);
  var name = meta.name || 'App';
  document.getElementById('title').textContent = name;
  document.getElementById('st').textContent = name;
  document.getElementById('logo').textContent = name.charAt(0).toUpperCase();
  document.title = name;

  var feed = await loadFeed(b);
  var status = document.getElementById('status');
  var videos = feed.videos || [];
  var channels = feed.channels || [];

  if (feed.error && !videos.length) {
    status.innerHTML = '<div class="warn"><b>Лента API не ответила</b> — разделы сайта всё равно открываются кнопками ниже.<div class="err">' +
      esc(String(feed.error)) + '\nURL: ' + esc(b) +
      '\nПроверь в браузере: ' + esc(b) + '/api/ext_app_feed.php</div></div>';
  } else if (feed._path) {
    status.innerHTML = '<div style="font-size:12px;opacity:.5;margin-bottom:8px">API: ' + esc(feed._path) +
      ' · видео: ' + videos.length + ' · каналы: ' + channels.length + '</div>';
  }

  // channels row as cards
  var tiles = document.getElementById('tiles');
  tiles.innerHTML = '';
  if (channels.length) {
    channels.slice(0, 4).forEach(function (c, i) {
      var a = document.createElement('a');
      a.className = 'tile';
      a.style.background = i % 2 ? 'linear-gradient(135deg,#7e22ce,#9d174d)' : 'linear-gradient(135deg,#1d4ed8,#312e81)';
      a.href = '#';
      a.textContent = c.title || c.name || 'Канал';
      a.onclick = function (e) {
        e.preventDefault();
        openSite(c.slug ? '/channel.php?slug=' + encodeURIComponent(c.slug) : '/channels.php');
      };
      tiles.appendChild(a);
    });
  } else if (videos[0]) {
    videos.slice(0, 2).forEach(function (v, i) {
      var a = document.createElement('a');
      a.className = 'tile';
      a.style.background = i % 2 ? 'linear-gradient(135deg,#7e22ce,#9d174d)' : 'linear-gradient(135deg,#1d4ed8,#312e81)';
      a.href = '#';
      a.textContent = v.title || 'Видео';
      a.onclick = function (e) {
        e.preventDefault();
        openSite('/video.php?slug=' + encodeURIComponent(v.slug || ''));
      };
      tiles.appendChild(a);
    });
  }

  var list = document.getElementById('list');
  list.innerHTML = '';
  if (!videos.length) {
    list.innerHTML = '<div class="card"><b>Нет видео в API</b><span>Открой «Видео» / «Каналы» кнопками внизу — сайт откроется</span></div>';
  }
  videos.forEach(function (v) {
    var a = document.createElement('a');
    a.className = 'card';
    a.href = '#';
    a.innerHTML = '<b>' + esc(v.title || 'Видео') + '</b><span>видео</span>';
    a.onclick = function (e) {
      e.preventDefault();
      openSite('/video.php?slug=' + encodeURIComponent(v.slug || ''));
    };
    list.appendChild(a);
  });

  // channels list section
  if (channels.length) {
    var h = document.createElement('h3');
    h.style.margin = '16px 0 8px';
    h.textContent = 'Каналы';
    list.parentNode.insertBefore(h, document.getElementById('sections'));
    var box = document.createElement('div');
    channels.forEach(function (c) {
      var a = document.createElement('a');
      a.className = 'card';
      a.href = '#';
      a.innerHTML = '<b>' + esc(c.title || c.name || 'Канал') + '</b><span>канал</span>';
      a.onclick = function (e) {
        e.preventDefault();
        openSite(c.slug ? '/channel.php?slug=' + encodeURIComponent(c.slug) : '/channels.php');
      };
      box.appendChild(a);
    });
    list.parentNode.insertBefore(box, document.getElementById('sections'));
  }

  var sec = document.getElementById('sections');
  sec.innerHTML = '';
  [
    ['Все видео', '/videos.php'],
    ['Каналы', '/channels.php'],
    ['Форум', '/forum.php'],
    ['Студия', '/studio.php'],
    ['Партнёры', '/partners.php'],
    ['Профиль', '/profile.php'],
    ['Импорт видео', '/video_import.php']
  ].forEach(function (x) {
    var a = document.createElement('a');
    a.className = 'card';
    a.href = '#';
    a.innerHTML = '<b>' + x[0] + '</b><span>открыть на сайте</span>';
    a.onclick = function (e) { e.preventDefault(); openSite(x[1]); };
    sec.appendChild(a);
  });
})();
