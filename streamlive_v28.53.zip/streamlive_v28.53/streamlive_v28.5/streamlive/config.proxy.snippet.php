<?php
// В config.php — твой прокси (пример):
// define('NETWORK_PROXY_URL', 'https://secure-272717.tatnet.app');
// если прокси ждёт ?url=
// define('NETWORK_PROXY_URL', 'https://secure-272717.tatnet.app/?url='); // не нужно — код сам добавляет ?url=
// define('NETWORK_PROXY_SECRET', ''); // если есть

// Рекомендуемый формат — URL, к которому можно дописать ?url=ENCODED
define('NETWORK_PROXY_URL', 'https://secure-272717.tatnet.app');
// define('NETWORK_PROXY_SECRET', 'optional');
